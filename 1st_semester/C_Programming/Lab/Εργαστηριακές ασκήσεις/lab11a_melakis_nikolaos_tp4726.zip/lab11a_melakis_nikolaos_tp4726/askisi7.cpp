#include <stdio.h>
#include <conio.h>
#include <string.h>
char words[10];
main( ) {
char wra[10] = "TI WRA";
char *dkt, *ptr = "ENTEKA";
int k;
puts (&wra[1]);
puts (ptr+1);
dkt = strcpy (words+1, ptr);
printf ("%s\n", dkt+3);
printf ("%c\n", *dkt+3);
words[0] = 'A';
puts (words);
for (k=1; k<3; k++)
ptr++;
dkt = strcat (wra, ptr+2);
puts (dkt);
k = strcmp (words+1, ptr-2);
printf ("%d\n", k);
putchar (*strcat (words+4,ptr+2)); }
