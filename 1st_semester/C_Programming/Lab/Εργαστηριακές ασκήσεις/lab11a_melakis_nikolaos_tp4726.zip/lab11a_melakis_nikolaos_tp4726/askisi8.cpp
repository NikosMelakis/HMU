#include<stdio.h>
#include<string.h>
#define N 10

void size(char *, int *);
main()
{
	int m=0;
	char s[N];
	printf("Give a string: ");
	gets(s);
	printf("%s",s);
	size(s, &m);
	printf("\nYour string has %d letters",m);
}
void size(char *s, int *m)
{
	int i=0;
	while(s[i]!='\x0')
	{
		*m=*m+1;
		i++;
	}
}
