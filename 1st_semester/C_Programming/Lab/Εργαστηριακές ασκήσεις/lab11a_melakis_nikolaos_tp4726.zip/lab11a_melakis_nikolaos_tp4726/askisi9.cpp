#include<stdio.h>
#include<string.h>
#define N 20

char *copy(char *);
main()
{
	char s[N];
	char *ch;
	printf("Give a string: ");
	gets(s);
	ch=copy(s);
	printf("%s",ch);	
}
char *copy(char *s)
{
	printf("Give a string: ");
	gets(s);
	return s;
}
