#include <stdio.h> 
#include <conio.h> 
#include <string.h> 
main( ) 
{ 
	char s[80]; 
	char *p; 
	strcpy (s, "ABCABEB"); 
	p = strchr (s, 'D'); 
    if (p==NULL) 
		printf ("Den yparxei D \n"); 
	else 
		printf ("Yparxei D, thesh = %d \n", p-s ); 
	p = strchr (s, 'B'); 
	if (p==NULL) 
		printf ("Den yparxei B \n"); 
	else 
		printf ("Yparxei B, thesh = %d \n", p-s ); 
	p = strchr (s, 'C');
	if (p==NULL) 
		printf("Den yparxei C\n");
	else 
		printf ("Yparxei C, thesh = %d \n", p-s );
	p = strchr (s, 'E'); 
	if (p==NULL) 
		printf ("Den yparxei E\n"); 
	else 
		printf ("Yparxei E, thesh = %d \n", p-s ); 
}
