#include<stdio.h>
#include<string.h>
#define N 20

int match(char *, char *, int );
main()
{
	int m, x;
	char s[N], c[N];
	printf("Give a string: ");
	gets(s);
	m=strlen(s);	
	printf("Give a string to search within the previous string(%s): ",s);
	gets(c);
	x=match(s, c, m);
	if(x==0)
		printf("NULL");
	else
		printf("The string %s exists within the string %s in position %d.", c, s, x);	
}
int match(char *s, char *c, int m)
{
	int i, j=0;
	for(i=0;i<m;i++)
		if(s[i]==c[0])
			return i+1;
	return j;
}
