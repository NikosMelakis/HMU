#include <stdio.h> 
#include <conio.h> 
#include <string.h> 
main( ) 
{ 
	char s[80]; 
	char *p; 
	strcpy (s, "ABCBE"); 
	p = strstr (s, "CD");
	if (p==NULL) 
		printf ("Den yparxei CD\n"); 
	else 
		printf ("Yparxei CD, thesh = %d \n", p-s ); 
	p = strstr (s, "CB"); 
	if (p==NULL) 
		printf ("Den yparxei CB\n"); 
	else 
	printf ("Yparxei CB, thesh = %d \n", p-s ); 
}
