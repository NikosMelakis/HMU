#include<stdio.h>
#include<string.h>
#define N 20

int search(char *, int);

main()
{
	char s[N];
	int x;
	int m=0;
	printf("Give a string: ");
	gets(s);
	m=strlen(s);
	x=search(s, m);
	if(x==0)
		printf("NULL");
	else
		printf("Elenemt found in posotion %d.", x);
}
int search(char *s, int m)
{
	int i, j=0; 
	char c;
	printf("Enter element to search: ");
	c=getchar();
	for(i=0;i<m;i++)
		if(s[i]==c)
			return i+1;
	return j; 
			
		

		
	
}
	
