#include <stdio.h> 
#include <conio.h> 
#include <string.h> 
main( ) 
{ 
	char s[80], t[80]; 
	char *p; 
	printf ("give t -> "); 
	gets (t); 
	p = strcpy (s,t); 
	printf ("s = %s \n", s ); 
	printf ("%c\n", *p); 
}
