#include<stdio.h>
#include<string.h>
#define N 20

void strcat(char *);

main()
{
	char s[N];
	char *ch;
	printf("Give a string: ");
	gets(s);
	strcat(s);
	printf("%s",s);
}
void strcat(char *s)
{
	int i, m;
	m=strlen(s);
	printf("Give a string: ");
	gets(s+m);
}
