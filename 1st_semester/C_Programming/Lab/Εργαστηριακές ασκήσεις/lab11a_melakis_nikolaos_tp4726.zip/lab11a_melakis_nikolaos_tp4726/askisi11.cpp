#include<stdio.h>
#include<string.h>
#define N 20

int comparsion(char *, char *);

main()
{
	char s[N], t[N];
	int x;
	printf("Give a string: ");
	gets(s);
	printf("Give a string: ");
	gets(t);
	x=comparsion(s, t);
	printf("%d",x);
}
int comparsion(char *s, char *t)
{
	if(s[0]==t[0])
		return 0;
	else
	if(s[0]>t[0])
		return 1;
	else
		return -1;
}
	
	
