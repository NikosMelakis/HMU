#include<stdio.h>
#include<string.h>
#define N 20

char *strsrch(char *, char *, char *, int);

main()
{
	int k; 
	char symb[N], syn[N];
	char *ch, *xar;
	printf("Give string symb: ");
	gets(symb);
	printf("Give string syn: ");
	gets(syn);
	printf("Give an integer: ");
	scanf("%d",&k);
	xar=symb;
	ch=strsrch(symb, syn, xar, k);
	if(ch==NULL)
		printf("NULL");
	else
		printf("The copied is %s",ch);
	
}
char *strsrch(char *symb, char *syn, char *xar, int k)
{
	int m, n;
	char *p;
	m=strlen(symb);
	n=strlen(syn);
	if(((m+k)+n)<N)
	{
		p=strcat(symb+k,syn);
		return p;
	}
	else
		return NULL;
}
