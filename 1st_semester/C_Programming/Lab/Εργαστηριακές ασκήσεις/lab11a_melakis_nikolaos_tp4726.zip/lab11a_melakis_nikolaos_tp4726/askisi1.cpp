#include <stdio.h>
#include <conio.h>
#include <string.h> 
main( ) 
{
	char s[80], t[80];
	int i;
	printf ("give s -> ");
	gets (s);
	printf ("give t -> ");
	gets (t); 
	i = strcmp (s,t); 
	printf ("strcmp = %d \n", i ); 
	if (i<0) 
		printf (" s<t \n"); 
	if (i==0) 
		printf (" s=t \n"); 
	if (i>0) 
		printf (" s>t \n"); 
}
