#include<stdio.h>
main(void)
{
	float x = 67.1256;
	printf ("x=%12.4f\n",x);
	printf ("x=%9.3f\n",x);
	printf ("x=%8.5f\n",x);
	printf ("x=%0.2f\n",x);
	printf ("x=%0.0f\n",x);
}
