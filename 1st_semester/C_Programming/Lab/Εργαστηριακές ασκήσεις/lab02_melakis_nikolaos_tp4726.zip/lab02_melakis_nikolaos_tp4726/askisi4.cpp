#include<stdio.h>
main(void)
{
	int i;
	printf ("Give a number -> ");
	scanf ("%d", &i); 
	printf ("Your number is %d\n", i);
}
