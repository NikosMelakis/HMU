#include<stdio.h>
main(void)
{
	char c, d;
	c = 'A';
	d = '$'; printf("\n");
	printf("%c\n", c);
	printf("%c\n", d);
	printf("%d\n", c);
	printf("%d\n", d);
	printf("%c\n", c+d);
	printf("%d\n", c+d);	
}
