#include <stdio.h>
#define PI 3.14159
#define DOL 1.17
main(void)
{
printf ("pi = %f \n",PI);
printf ("euro = %f dollaria.\n", DOL);
}
