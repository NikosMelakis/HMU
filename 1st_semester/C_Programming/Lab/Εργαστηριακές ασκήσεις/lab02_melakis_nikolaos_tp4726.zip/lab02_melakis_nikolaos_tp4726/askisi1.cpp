#include<stdio.h>
main(void)
{
char c, d, ch = 'd';
c = '!';
d = c; printf("\n");
printf("%c\n", ch);
printf("%c\n", c);
printf("%c\n", d);
}
