#include<stdio.h>
main(void)
{
	int F,c,ftemp;
	
	printf("Give a temperature in Fahrenheit: ");
	scanf("%d",&ftemp);
	c=(ftemp-32)*5/9;
	printf("The temprature in celsius is   %d\b\b\b\b\b\b",c );
}
