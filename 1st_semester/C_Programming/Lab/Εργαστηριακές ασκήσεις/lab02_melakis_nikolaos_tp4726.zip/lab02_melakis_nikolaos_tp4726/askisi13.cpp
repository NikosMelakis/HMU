#include<stdio.h>
#define N 5
main(void)

{
	int x,y;
	y=0;
	float pin[N];
	printf("Give a float: ");
	scanf("%f",&pin[0]);
	printf("Give a float: ");
	scanf("%f",&pin[1]);
	printf("Give a float: ");
	scanf("%f",&pin[2]);
	printf("Give a float: ");
	scanf("%f",&pin[3]);
	printf("Give a float: ");
	scanf("%f",&pin[4]);
	
	
	printf("%.2f    %.3f",pin[0],pin[0]);
	
}

