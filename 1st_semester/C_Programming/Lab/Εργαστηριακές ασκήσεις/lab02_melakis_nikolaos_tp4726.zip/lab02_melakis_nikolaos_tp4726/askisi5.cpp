#include<stdio.h> 
main(void)
{
	float salary;
	printf ("TI MISTHO THELETE? ");
	printf ("SYMPLHRWSTE _________(EYRW) \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
	scanf ("%f", &salary);
	printf ("\n%5.0f EYRW TO MHNA EINAI %7.0f EYRW TON XRONO\n",
	salary, 12*salary );
}

