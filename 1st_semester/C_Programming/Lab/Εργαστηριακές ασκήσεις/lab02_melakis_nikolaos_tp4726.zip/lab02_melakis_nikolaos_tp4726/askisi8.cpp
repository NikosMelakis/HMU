#include<stdio.h>
#define FPA 0.23

main(void)

{
	
	float tv,dvd,washer,fridge;
	
	printf("Give a price for tv: ");
	scanf("%f",&tv);
	printf("Give a price for dvd: ");
	scanf("%f",&dvd);
	printf("Give a price for washer: ");
	scanf("%f",&washer);	
	printf("Give a price for fridge: ");
	scanf("%f",&fridge);
	
	tv=tv+tv*FPA;
	dvd=dvd+dvd*FPA;
	washer=washer+washer*FPA;
	fridge=fridge+fridge*FPA;
	
	printf("The price list with FPA is");
	printf("\nTV: %1.2f$\b\b\b",tv);
	printf("\nDVD: %1.2f$\b\b\b",dvd);
	printf("\nWASHER: %1.2f$\b\b\b",washer);
	printf("\nFRIDGE: %1.2f$\b\b\b",fridge);
		
}
