#include<stdio.h>


main(void)
{
	float x,y,e;
	
	printf("Dwse tin 1h pleura: ");
	scanf("%f",&x);

	printf("\nDwse tin 2h pleura: ");
	scanf("%f",&y);
	e=(x*y)/2;
	printf("\nTo embadon tou trigonou einai: %6.2f",e);
	
}
