#include<stdio.h>
main(void)

{
	int pin[3];
	pin[0] = 22;
	pin[1] = 33;
	pin[2] = 18;

	printf ("give pin2 -> ");
	scanf("%d", &pin[2]);
	printf ("pin2 = %d \n", pin[2]);

}

