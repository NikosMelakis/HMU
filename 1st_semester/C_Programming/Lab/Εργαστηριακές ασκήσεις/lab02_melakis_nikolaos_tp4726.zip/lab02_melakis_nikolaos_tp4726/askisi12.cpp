#include<stdio.h>
#define tax 0.10
main(void)

{
	float mis,exd,inc,exp,fp,final;
	printf("Dwsw mistho se euro: ");
	scanf("%f",&mis);
	inc=mis*12;
	printf("Dwse ta exoda se euro: ");
	scanf("%f",&exd);
	exp=exd*12;
	fp=inc-exp;
	final=fp*tax;
	printf("O etisios foros einai se euro: %8.2f",final);
}
