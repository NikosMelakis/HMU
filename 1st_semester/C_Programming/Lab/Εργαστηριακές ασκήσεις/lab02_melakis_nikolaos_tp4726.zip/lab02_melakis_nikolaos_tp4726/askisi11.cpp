#include<stdio.h>
#define pi 3.141592

main(void)

{
	int x;
	float rad;
	printf("Dwse moires: ");
	scanf("%d",&x);
	rad=(x*pi)/180;
	printf("Oi moires pou dwsate se aktinia einai: %4.6f",(x*pi)/180);
	
}
