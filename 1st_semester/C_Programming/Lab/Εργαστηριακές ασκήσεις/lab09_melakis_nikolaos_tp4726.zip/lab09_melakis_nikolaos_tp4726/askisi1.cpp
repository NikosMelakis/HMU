#include<stdio.h>
main( )
{
	int a, b, *p;
	p = &a;
	*p = 5;
	p = &b;
	*p = 6;
	printf("a=%d, b=%d, p=%p\n", a, b, p );
}
