#include<stdio.h>

float triangle(float *, float, float *);

main()
{
	float bs, yps, emb;
	printf("Give bs:");
	scanf("%f",&bs);
	printf("Give yps:");
	scanf("%f",&yps);
	printf("Give emb: ");
	scanf("%f",&emb);
	float area=triangle(&bs, yps, &emb);
	printf("\nFunction value is %.2f\n",area);
	printf("bs=%.2f\nemb=%.2f",bs, emb);
}
float triangle(float *bs, float yps, float *emb)
{
	float emv;
	emv=(*bs*yps)/2;
	while(emv>*emb)
	{
		if(*bs>0)
			*bs=*bs-0.1;
		else 
			break;
	}
	
	if(emv<*emb)
	{
		*emb=emv;
		return 1;
	}
	else
		return 0;
}	
