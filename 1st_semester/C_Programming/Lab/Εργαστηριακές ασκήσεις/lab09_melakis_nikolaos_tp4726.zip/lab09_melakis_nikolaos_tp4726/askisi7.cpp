#include<stdio.h>

int kostos(int *);
main()
{
	int kwh;
	printf("Give kwh: ");
	scanf("%d",&kwh);
	int price=kostos(&kwh);
	printf("The total cost is: %d$, and the taxes are: %d$",price,kwh);
	

		
		
}
int kostos(int *kwh)
{
	int temp, var, mid;
	int price;
	if(*kwh<=100)
		price=*kwh*0.1;
	else
	if(*kwh>100&&*kwh<=200)
	{
		temp=*kwh-100;
		var	=*kwh-temp;
		temp=temp*0.15;
		var=var*0.1;
		price=temp+var;		
	}
	else
	{
		temp=*kwh-200;
		var=*kwh-100-temp;
		mid=100;
		temp=temp*0.2;
		var=var*0.15;
		mid=mid*0.1;
		price=temp+var+mid;	
	}
	if(price-100>100)
		*kwh=(price-100)*0.10;
	else
		*kwh=0;
	return price;
}
