#include<stdio.h>

void trade(int *, int *);
main()
{
	int a, b;
	printf("Give integer for a: ");
	scanf("%d",&a);
	printf("Give integer for b: ");
	scanf("%d",&b);
	trade(&a, &b);
	printf("The values are a:%d and b:%d",a,b);
}
void trade(int *a, int *b)
{
	int temp;
	temp=*a;
	*a=*b;
	*b=temp;
}
