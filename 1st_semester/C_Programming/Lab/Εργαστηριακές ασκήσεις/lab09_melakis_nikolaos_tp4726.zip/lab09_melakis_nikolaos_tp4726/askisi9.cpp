#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int guess(int , int *, int *);
main()
{
	int num, mik=0, meg=0; 
	int min=-100, max=100;
	srand(time(NULL));
	num=min+rand()%(max+1-min);
	printf("--%d--\n\n",num);
	int gs=guess(num, &mik, &meg);
	printf("\nCongratulations!! The number %d was the correct answer.",gs);
	printf("\nYou entered %d times higher and %d times lower number from the target",mik,meg);
	
}
int guess(int num, int *mik, int *meg)
{
	int gs;
	
jmp:
	printf("\nGive an integer: ");
	scanf("%d",&gs);
	if(gs>num)
	{
		printf("\nGive a lower integer.\n");
		*mik=*mik+1;
		goto jmp;
	}
	else
	if (gs<num)
	{
		printf("\nGive a higher integer.\n");
		*meg=*meg+1;
		goto jmp;	
	}
	return gs;
}
