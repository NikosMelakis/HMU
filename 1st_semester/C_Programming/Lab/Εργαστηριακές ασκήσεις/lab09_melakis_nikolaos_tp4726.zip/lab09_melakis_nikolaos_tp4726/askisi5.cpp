#include<stdio.h>
float thermo(int *);

main()
{
	int akc;
	printf("Give tempreture in celcius:  C\b\b\b");
	scanf("%d",&akc);
	float fahr=thermo(&akc);
	printf("The tempreture in Fahrenheit is %.2fF and in Kelvin is %.2dK",fahr, akc);
}
float thermo(int *akc)
{
	float fahr;
	fahr=(9.0**akc)/5+32;
	*akc=*akc+273;
	return fahr;
}
