#include<stdio.h>
#include<math.h>
float stddev(float, int *);
main(void)
{
    int count=0;
    float fp;
    printf("Give the limit:");
    scanf("%f",&fp);
    float result=stddev(fp, &count);
    printf("\nStandard Deviation=%.6f",result);
}
float stddev(float fp, int *count)
{
    int i, n;
	n=(int)fp;
    float sum,mo,sd=0.0, data[n], result=0;
    printf("Enter %d floats: ",n);
    for(i=0;i<fp;i++)
    {
		*count+=1;
		scanf("%f",&data[i]);
		sum+=data[i];
	}   
    mo=sum/10;
    for (i=0;i<10;++i)
        sd+=pow(data[i]-mo,2);
    result=sqrt(sd/n);

    return result;
}

