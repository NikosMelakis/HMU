#include<stdio.h>

int praxeis(int *, int *);

main()
{
	int a, b;
	printf("Give integer for a: ");
	scanf("%d",&a);
	printf("Give integer for b: ");
	scanf("%d",&b);
	printf("You typed a=%d and b=%d\n",a,b);
	int mult=praxeis(&a, &b);
	printf("a*b=%d\n",mult);	
	printf("After the trabe. a=%d and b=%d",a,b);
}
int praxeis(int *a, int *b)
{
	int mult, sum, sub;
	mult=*a**b;
	sum=*a+*b;
	sub=*a-*b;
	*a=sum;
	*b=sub;
	return mult;
}
