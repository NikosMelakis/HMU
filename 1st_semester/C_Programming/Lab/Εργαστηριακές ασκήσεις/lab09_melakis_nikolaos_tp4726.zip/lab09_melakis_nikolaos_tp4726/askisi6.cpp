#include<stdio.h>
void reader(int *, int *, float *, int *, float *);
main()
{
	int ak, cp=0,cn=0;
	float sump=0, sumn=0;
	printf("Give an integer:");
	scanf("%d",&ak);
	reader(&ak, &cp, &sump, &cn, &sumn);
	printf("cp=%d\nsump=%f\ncn=%d\nsumn=%f",cp, sump ,cn, sumn);
}
void reader(int *ak, int *cp, float *sump, int *cn, float *sumn)
{
	int i;
	float fp;
	for(i=0;i<*ak;i++)
	{
		printf("Give a float: ");
		scanf("%f",&fp);
		if(fp>=0)
		{
			*cp=*cp+1;
			*sump=*sump+fp;
		}
		else
		{
			*cn=*cn+1;
			*sumn=*sumn+fp;
		}
	}
}
