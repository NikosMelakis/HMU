  
#include<stdio.h>
main(void)
{
    int i, j, rows,columns;
    printf("Give rows:");
    scanf("%d",&rows);
    printf("Give columns:");
    scanf("%d",&columns);
    
	for(i=1;i<=20;i++)
	{
		printf("\n\xDB");
		for(j=1;j<=40;j++)
		printf("\xDB");
	}
}
