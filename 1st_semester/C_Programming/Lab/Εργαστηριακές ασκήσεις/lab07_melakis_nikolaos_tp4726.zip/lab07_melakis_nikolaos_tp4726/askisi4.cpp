#include<stdio.h>
#define N 10

main(void)
{
	int i, pin[N];
	for(i=0;i<N;i++)
	{
		printf("Give an integer: ");
		scanf("%d",&pin[i]);
	}
	printf("Your array is: ");
	for(i=0;i<N;i++)
        printf("%d, ",pin[i]);

	int sum=0, sump=0, sumn=0;
	for(i=0;i<N;i++)
	{
		if(sum>=100)
        {
	       if(pin[i]>0)
            sump=sump+pin[i];
           else
            sumn=sumn+pin[i];
        }
        else
         sum=sum+pin[i];
	}
	printf("The sum is: %d",sum);
	printf("\nThe sump is: %d\nThe sumn is:%d",sump,sumn);
}


