#include<stdio.h>
main(void)
{

	printf("\n\n");
	int i, j;
	for(i=1;i<=5;i++)
	{
		for(j=i;j<=9;j++)
		{
			printf("%d",j);
		}
	printf("\n");
}
}

	

