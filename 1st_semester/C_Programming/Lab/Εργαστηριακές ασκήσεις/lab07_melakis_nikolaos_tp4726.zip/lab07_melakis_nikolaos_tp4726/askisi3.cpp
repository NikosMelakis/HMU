#include<stdio.h>
main(void)
{
	int i, j;
	for(i=1;i<=20;i++)
	{
		printf("\n\xDB");
		for(j=1;j<=40;j++)
		printf("\xDB");
	}
}
