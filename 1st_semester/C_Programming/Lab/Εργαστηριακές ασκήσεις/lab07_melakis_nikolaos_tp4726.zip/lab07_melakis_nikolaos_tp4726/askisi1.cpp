#include<stdio.h>
main(void)
{
	int x,y,z,i,j;
	for(x=0;x<5;++x)
	{
		printf("123456789\n");
	}
}


	

