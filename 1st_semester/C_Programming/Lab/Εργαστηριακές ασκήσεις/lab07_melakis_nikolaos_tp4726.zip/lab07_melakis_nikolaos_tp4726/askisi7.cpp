#include <stdio.h>
main(void)
{
   int j,i, n=10;

   for(i=1;i<=10;i++)
   {
     for(j=1;j<=10;j++)

     {
        if (j<=n-1)
            printf(" %4d ", i*j);
        else
            printf(" %4d", i*j);
      }
     printf("\n");

   }
}
