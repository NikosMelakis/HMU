#include<stdio.h>
main(void)

{
	printf("5/4 dinei %d\n",5/4);
	printf("35/7 dinei %d\n",24/7);
	printf("3/6 dinei %d\n",6/3);
	printf("7./4 dinei %f8.2\n",7./4);
	printf("To ypoloipo tis akeraias doieresis 39/6 dinei %d\n",39%6);
}
