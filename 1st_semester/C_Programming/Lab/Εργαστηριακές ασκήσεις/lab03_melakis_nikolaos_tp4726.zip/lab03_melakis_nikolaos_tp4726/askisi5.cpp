#include<stdio.h>
main(void)
{
	float fl; 
	int ak;
	printf("Give a float: "); 
	scanf("%f", &fl);
	ak=(int)fl; 
	printf("\nThe integer is: %5c\n", ak);
}
