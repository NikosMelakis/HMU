#include<stdio.h> 
main(void)

{
	char name[80];
	printf ("Enter your name -> ");
	scanf ("%s", name);
	printf ("Hello %s \n", name);
}
