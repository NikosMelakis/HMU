#include<stdio.h> 
#include<string.h>
main(void)

{
	char name[80]; 
	int m;
	printf("Give your name: ");
	scanf ("%s", name); 
	m=strlen(name);
	printf("Your name has %d letters. \n", m);
}
