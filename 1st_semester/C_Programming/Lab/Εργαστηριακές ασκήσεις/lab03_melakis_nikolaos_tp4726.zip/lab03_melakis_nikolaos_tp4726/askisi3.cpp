#include<stdio.h> 
main(void) 

{
	int i=1, j=1, k1=10, k2=20, k3=30, k4=40, k5=50, k, h;
	float a=7.0, b=6.0, c=5.0, d=4.0, e, x, y, z ;
	printf ("ARXIKES TIMES i, j, i=%3d, j=%3d\n", i, j); k = i++;
	h = ++j;
	printf ("META TIS AYKSHSEIS, i=%3d, j=%3d\n" " i=%3d, j=%3d\n", i, j, k, h);
	printf ("ARXIKES TIMES, k1=%3d, k2=%3d, k3=%3d, " "k4=%3d, k5=%3d\n", k1, k2, k3, k4, k5); 
	k1 += 2;
	k2 -= i;
	k3 *= (8/4); k4 /= 2;
	k5 %= 2;
	printf ("META TIS PRAKSEIS, k1=%3d, k2=%3d, k3=%3d, " "k4=%3d, k5=%3d\n", k1, k2, k3, k4, k5);
	printf ("ARXIKES TIMES, a=%3.0f, b=%3.0f, c=%3.2f, d=%3.2f\n",
	a, b, c, d);
	e = 2.0;
	x=a+b-c/d*e;
	y=a+(b-c)/d*e;
	z=((a+b)-c/d)*e;
	printf ("META TIS PRAKSEIS, e=%10.1f\nx=%10.2f\ny=%10.3f" "\nz=%10.4fn", e, x, y, z);
}
