#include<stdio.h>
#include<string.h>

main(void)

{
	char mat[30],pin[30];
	int m,n;
	printf("Give a string: ");
	scanf("%s",mat);
	printf("Give a string: ");
	fflush(stdin);
	scanf("%s",pin);
	printf("The strings are: \n1)%s \n2)%s",mat,pin);
	m=strlen(mat);
	n=strlen(pin);
	
	if(m>n)
	{	
		strcpy(mat,pin);
		printf("\n\nThe smaller string is: %s",mat);
	}
	else 
	if(m<n)
	{
		strcpy(pin,mat);
		printf("\n\nThe smaller string is: %s",pin);
	}
	else 
	printf("\n\nThe strings have the same size");
}
