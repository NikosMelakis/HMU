#include<stdio.h>
#define GOOD "You have a nice name" 

main(void)
{
	char onoma[80];
	printf ("What's your name? : ");
	scanf ("%s", onoma);
	printf ("Hello %s, %s\n", onoma, GOOD);
}
