#include<stdio.h> 
main(void)
{
	int top, score;
	top = score = -(2 + 5) * 6 + (4 + 3 * (2 + 3)); 
	printf("top = <%8d>\n", top); 
	printf("score = <%-7d>\n", score);
}
