#include<stdio.h>
main(void)
{
	int sec,min,left;
	printf("Give a number for seconds: ");
	scanf("%d",&sec);
	min=sec/60;
	left=sec%60;
	printf("In minitues is: %3dmins\n",min);
	printf("The left overs are: %3.3f",&left);
	
	
}
