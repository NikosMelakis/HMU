#include<stdio.h>
main(void)
{
	int a=2,b=3,c,d;
	printf("a=%d b=%d\n",a,b);
	c=a;
	d=b;
	printf("Meta tin enallagi\n");
	printf("a=%d b=%d",d,c);
	

}
