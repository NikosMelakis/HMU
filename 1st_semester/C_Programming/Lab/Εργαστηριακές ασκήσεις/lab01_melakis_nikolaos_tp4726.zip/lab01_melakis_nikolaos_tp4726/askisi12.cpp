#include<stdio.h>
main(void)
{
	int age;
	printf("Enter your age: ");
	scanf("%d",&age);
	printf("You're age in months is: %d",age*12);
	
}
