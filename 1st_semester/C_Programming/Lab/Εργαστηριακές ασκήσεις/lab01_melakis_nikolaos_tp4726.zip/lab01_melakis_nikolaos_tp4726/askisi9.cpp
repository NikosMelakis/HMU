#include<stdio.h>
main(void)
{
int k;
k=60;
printf("SE ENA ETOS YPARXOYN KAI EBDOMADES");
}

