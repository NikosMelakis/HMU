#include<stdio.h>
#include <stdlib.h>
main( )
{
printf ("\n\n Game over! \n\n");
printf ("\t That\'s all folks! \n");
printf ("\a Beep! \a Beep! \n");
printf (" \" in double quotes \" \n");
printf ("file c:\\new\\melody.mp3 \n");
printf ("ena \r"); printf("dyo \n");
printf ("xxx \b\b\b yyy \n");
printf ("visible \0 invisible ");
printf ("Students are 99%% good \n");
system("pause");

}
