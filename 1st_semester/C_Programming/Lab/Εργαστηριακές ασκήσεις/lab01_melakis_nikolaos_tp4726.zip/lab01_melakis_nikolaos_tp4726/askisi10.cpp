#include<stdio.h>
main(void)
{
	printf("MELAKIS NIKOLAOS\nEYAGGELIAS FRAGKAKI 9");
}
