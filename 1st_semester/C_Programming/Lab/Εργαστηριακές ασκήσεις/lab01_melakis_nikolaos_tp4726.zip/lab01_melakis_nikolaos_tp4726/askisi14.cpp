#include<stdio.h>
main(void)
{
	int a,b;
	printf("Give an integer for a: ");
	scanf("%d",&a);
	printf("Give an integer for b: ");
	scanf("%d",&b);
	printf("a=%d b=%d",a,b);
	a=a+b;
	b=a-b;
	a=a-b;
	printf("\nMeta tin enallagi \na=%d b=%d",a,b);
}
