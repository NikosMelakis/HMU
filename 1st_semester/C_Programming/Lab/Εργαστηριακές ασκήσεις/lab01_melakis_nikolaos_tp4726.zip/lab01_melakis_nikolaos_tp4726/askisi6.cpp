#include<stdio.h> 
#include <stdlib.h>
main( )
{
int dek = 395;
printf ("O arithmos sto dekadiko? %d\n",dek);
printf ("O idios sto oktadiko ? %o\n", dek);
printf ("kai sto dekaexadiko %x\n", dek);
system("pause");
}

