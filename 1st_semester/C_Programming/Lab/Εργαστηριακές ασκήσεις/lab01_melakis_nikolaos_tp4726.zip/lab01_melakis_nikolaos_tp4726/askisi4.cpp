#include <stdio.h>


main(void)
{
	printf ("\n\t\t\t\"");
	printf ("\n\t\t\t\"\"\"");
	printf ("\n\t\t\t\"\"\"\"\n");
	printf ("\t\t\t\"\"\"\"\"\"\n");
	printf ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    \"\"\"\"\"\"\"\"\n");
	printf ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    \"\"\"\"\"\"\"\"\"\"\n");
	printf ("\t\t\t\"\"\"\"\"\"\"\"\n");
	printf ("\t\t\t\"\"\"\"\"\"\n");
	printf ("\t\t\t\"\"\"\"\n");
	printf ("\t\t\t\"\"\"");
	printf ("\n\t\t\t\"");
}

