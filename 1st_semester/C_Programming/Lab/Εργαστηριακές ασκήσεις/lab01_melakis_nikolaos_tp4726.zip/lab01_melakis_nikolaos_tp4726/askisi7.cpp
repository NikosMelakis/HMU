#include<stdio.h>
main(void)
{
	int nik=3, nak=5, atr=nik+nak, gin=nik*nak;
	printf("VALUES\n*****\n");
	printf("%d %d\n\n\n",nik,nak);
	printf("Atroisma %d Ginomeno %d",atr,gin);
	
		
}
