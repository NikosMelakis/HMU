#include<stdio.h>
main(void)
{
	printf("MELAKIS NIKOLAOS\n");
	printf("\nMELAKIS\nNIKOLAOS\n");
	printf("\nMELAKIS");
	printf(" NIKOLAOS");
}
