#include <stdio.h>
#include <stdlib.h>
main( )
{
printf ("\nTEI KRHTHS\n");
printf ("SXOLH TEXNOLOGIKWN\n EFARMOGWN\n");
system ("pause");
}
