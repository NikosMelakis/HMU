#include <stdio.h>
#include <stdlib.h>
main( )
{
int ak = 2147483647;
printf ("%d %d %d\n", ak, ak+1, ak+2);
system("pause");
}

