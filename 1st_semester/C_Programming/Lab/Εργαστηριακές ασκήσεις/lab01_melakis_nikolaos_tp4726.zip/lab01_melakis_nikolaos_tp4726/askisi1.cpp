#include <stdio.h>
#include <stdlib.h>
main( )
{
printf ("Hello world! \n");
system ("pause");
}
