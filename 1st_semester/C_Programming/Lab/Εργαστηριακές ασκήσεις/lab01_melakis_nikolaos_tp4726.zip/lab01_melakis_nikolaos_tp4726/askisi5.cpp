#include <stdio.h>
#include <stdlib.h>
main()
{
int num, art;
num = 1;
printf ("O ARITHMOS ISOYTAI ME %d\n", num);
art = num + 1;
printf ("AN PROSTHESOYME 1 PAIRNOYME %d\n", art);
printf ("ATHROISMA = %d. DIAFORA = %d\n", num+art, num-art); 
system("pause");
}

