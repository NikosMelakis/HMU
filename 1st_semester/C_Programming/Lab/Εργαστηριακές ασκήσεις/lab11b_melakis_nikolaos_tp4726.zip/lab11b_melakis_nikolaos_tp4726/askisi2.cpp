#include<stdio.h>
#include<math.h>
main()
{
	float x;
	for(x=-1;x<=1;x+=0.1)	
		printf("sin(%.f)=%.2f\ncos(%.f)=%.2f\n", x, sin(x), x, cos(x));
}	
