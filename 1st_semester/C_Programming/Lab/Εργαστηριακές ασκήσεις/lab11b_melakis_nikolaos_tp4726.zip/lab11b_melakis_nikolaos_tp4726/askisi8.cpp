#include<stdio.h>

struct color 
{
	int r, g, b; 
}; 

struct pixel
{
	int x, y; 
	struct color c; 
};

main()
{
	struct pixel p;
	struct color blue;
	blue.r=blue.g=0; 
	blue.b=255; 
	p.x=12; 
	p.y=50;
	p.c=blue; 
	p.c.r=50; 
	printf("x=%d, y=%d, r=%d, g=%d, b=%d \n", p.x, p.y, p.c.r, p.c.g, p.c.b );
}
