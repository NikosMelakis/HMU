#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define N 2
main()
{
	int x, y;
	float fp, fd;
	long a, b;
	char ch[N];
	printf("Give an integer: ");
	gets(ch);
	x=atoi(ch);
	printf("Give an integer: ");
	gets(ch);
	y=atoi(ch);
	printf("Give a float: ");
	gets(ch);
	fp=atof(ch);
	printf("Give a float: ");
	gets(ch);
	fd=atof(ch);
	printf("Give a long integer: ");
	gets(ch);
	a=atol(ch);
	printf("Give a long integer: ");
	gets(ch);
	b=atol(ch);
	printf("x=%d, y=%d\nfp=%.2f, fd=%.2f\na=%d, b=%d", x, y, fp, fd, a, b);		
}
