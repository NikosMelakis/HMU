#include<stdio.h>
#include<math.h>
#define N 10
main()
{
	int i, x;
	float y;
	for(i=0;i<N;i++)
	{
		printf("Give an integer: \n");
		scanf("%d",&x);
		printf("Give a float: ");
		scanf("%f",&y);
		printf("|x|=%d, |y|=%.2f",abs(x), fabs(y));
	}
}
