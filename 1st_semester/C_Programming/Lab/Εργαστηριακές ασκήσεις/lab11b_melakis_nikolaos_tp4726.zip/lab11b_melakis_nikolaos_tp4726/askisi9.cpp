 #include<stdio.h>
 #include<string.h>
 #define N 5
 struct one
 {
 	int ak;
 	char pin[30];
 };
 struct two
 {
 	int data, mat[5];
 	struct one item;
 	struct one melos;
 };
 
 
 main()
 {
 	struct one person;
 	struct two memb;
 	int i, size;
 	
//a)
 	printf("Give person.ak: ");
 	scanf("%d",&person.ak);
 	printf("Give person.pin: ");
	scanf("%s",person.pin);
	
	
	printf("Give memb.data: ");
	scanf("%s",&memb.data);
	printf("Give memb.mat[%d]: ",N);
	for(i=0;i<N;i++)
		scanf("%d",memb.mat+i);
	printf("Give memb.item.ak: ");
	scanf("%d",&memb.item.ak);
	printf("Give memb.item.pin: ");
	scanf("%s",memb.item.pin);
	
	printf("Give memb.melos.ak: ");
	scanf("%d",&memb.melos.ak);
	printf("Give memb.melos.pin: ");
	scanf("%s",memb.melos.pin);
	
	
//b)	
	strcpy(memb.melos.pin, person.pin);
	puts(memb.melos.pin);
	
//c)
	size=strlen(memb.melos.pin);
	printf("The size of the string is: %d\n",size);
	
//d)
	strcat(person.pin, memb.melos.pin);
	puts(person.pin);
	
//e)
	memb.melos=memb.item;
}
