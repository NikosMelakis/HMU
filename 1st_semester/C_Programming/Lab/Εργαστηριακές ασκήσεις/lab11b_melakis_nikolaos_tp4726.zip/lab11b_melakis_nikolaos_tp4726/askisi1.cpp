#include<stdio.h>
#include<math.h>
main()
{
	float x=10, y;
	for(y=0;y<10;y++)
		printf("%.2f ",pow(x,y));
}
