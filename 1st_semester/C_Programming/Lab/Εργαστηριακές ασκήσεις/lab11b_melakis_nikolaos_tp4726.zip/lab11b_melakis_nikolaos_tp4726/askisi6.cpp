#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

struct complex
{ 
	float re; 
};

main()
{
	struct complex z1, z2;
	char ch;
	
	printf("Give a char: ");
	ch=getchar();
	
	printf("Give z1.re: ");
	scanf("%f", &z1.re );
	printf("%.2f",z1.re);
	
	printf("\nGive z2.re: ");
	scanf("%f", &z2.re);
	printf("%.2f\n\n",z2.re);
	 
	
	if(ch=='+')
		printf("z1.re+z2.re=%.2f",z1.re+z2.re);
	else
	if(ch=='-')
		printf("z1.re-z2.re=%.2f",z1.re-z2.re);
	else
	if(ch=='*')
		printf("z1.re*z2.re=%.2f",z1.re*z2.re);
	else
	if(ch=='/')
		printf("z1.re/z2.re=%.2f",z1.re/z2.re);
	else
		printf("\nWrong entry!");
		
	system("pause");
}
	
