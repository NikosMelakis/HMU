#include <stdio.h>
struct complex 
{ 
float re, im; 
};

main()
{
	struct complex z1, z2;
	printf("give z1.re -> ");
	scanf("%f", &z1.re ); 
	z1.im=55;
	z2=z1; 
	printf("z2=%.2f+i*%.2f\n", z2.re, z2.im);
}
