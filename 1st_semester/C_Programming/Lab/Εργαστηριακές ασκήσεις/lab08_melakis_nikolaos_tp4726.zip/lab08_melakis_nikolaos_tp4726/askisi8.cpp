#include<stdio.h>
int transf(int, int, int);
main(void)
{
    int hour, mi, sec;
    printf("Give hours:");
    scanf("%d",&hour);
    printf("Give minutes:");
    scanf("%d",&mi);
    printf("Give seconds:");
    scanf("%d",&sec);
    printf("The time you typed is %d:%d:%d",hour,mi,sec);
    int s=transf(hour, mi, sec);
    printf("The time in seconds is: %d",s);

}
int transf(int hour, int mi, int sec)
{
    int s=((hour*60)*60)+(mi*60)+(sec);
    return s;
}
