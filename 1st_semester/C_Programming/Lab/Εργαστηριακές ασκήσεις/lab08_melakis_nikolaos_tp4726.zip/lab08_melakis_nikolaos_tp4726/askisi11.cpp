#include<stdio.h>
float one(int);
float two(int);
main(void)
{
	int x;
	int N;
	printf("Give the limit: ");
	scanf("%d",&N);
    float res1=one(N);
    float res2=two(N);
    printf("\nThe results are\nFirst row:%.2f\nSecond row:%.2f",res1,res2);
}
 float one(int N)
 {
     float res1=0;
     for(int x=1;x<=N;x++)
        res1+=1.0/x;
     return res1;
 }
float two(int N)
{
    float res2=0;
    for(int x=1;x<=N;x++)
        if(x%2)
            res2+=1.0/x;
        else
            res2-=1.0/x;

    return res2;
}
