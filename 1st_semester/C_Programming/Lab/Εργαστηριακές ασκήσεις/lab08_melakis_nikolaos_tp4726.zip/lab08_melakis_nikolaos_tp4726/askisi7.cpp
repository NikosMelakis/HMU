#include<stdio.h>
#include<conio.h>

void plot(int, int, char, char);

main(void)
{
    int row, cols;
    char ch, xar;
    printf("Give rows: ");
    scanf("%d",&row);
    printf("Give columns: ");
    scanf("%d",&cols);
    printf("Give 1st character: ");
    ch=getche();
    printf("\nGive 2nd character: ");
    xar=getche();
    plot(row, cols, ch, xar);
    printf("\n\nThe end!");

}

void plot(int row, int cols, char ch, char xar)
{
    printf("\n");
    int i,j=0;
    while(j<row)
    {
        for(i=1;i<=cols;i++)
            printf("%c",ch);
        printf("\n");
        for(i=1;i<=cols;i++)
            printf("%c",xar);
        printf("\n");
        j++;
    }
}
