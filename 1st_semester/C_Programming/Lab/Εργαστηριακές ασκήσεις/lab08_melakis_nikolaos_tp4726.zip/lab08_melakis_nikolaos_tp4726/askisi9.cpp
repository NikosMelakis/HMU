#include<stdio.h>
int summary(int);
main(void)
{
    int ak;
    printf("Give the limit:");
    scanf("%d",&ak);
    int sum=summary(ak);
    printf("The result is:%d",sum);
}
int summary(int ak)
{
    int i, sum=0;
    while(i<=ak)
    {
        sum+=i;
        i++;
    }
    return sum;
}
