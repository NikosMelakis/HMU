#include<stdio.h>

float power(int, float);

main(void)
{
    int ak;
    float bs;
    printf("Give the power(integer):");
    scanf("%d",&ak);
    printf("Give the base(float):");
    scanf("%f",&bs);
    float c=power(ak, bs);
    printf("The power of %d with base %.2f is %.2f",ak, bs, c);
}
float power(int ak ,float bs)
{
    float c=1;
    for(int i=1;i<=ak;i++)
        c=c*bs;
    return c;
}
