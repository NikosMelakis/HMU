#include<stdio.h>
#include<math.h>

int emvadon(int, int, int);

main(void)
{
    int a, b, c;
    printf("Give side a:");
    scanf("%d",&a);
    printf("Give side b:");
    scanf("%d",&b);
    printf("Give side c:");
    scanf("%d",&c);
    int result=emvadon(a, b, c);
    if(result!=0)
        printf("The triangle exists, and the area is %d.",result);
    else
        printf("The triangle doesn't exists.");
}
int emvadon(int a, int b, int c)
{
    int t, e;
    if(a+b>c&&a+c>b&&b+c>a)
    {
        t=(a+b+c)/2;
        e=sqrt(t*(t-a)*(t-b)*(t-c));
        return e;
    }
    else
        return 0;
}
