#include<stdio.h>
#include<conio.h>

int computeraki( int, int, char);

int main(void)
{
    int a, b;
    char ch;
    printf("Give integer a: ");
    scanf("%d",&a);
    printf("Give integer b: ");
    scanf("%d",&b);
L1: printf("Pick a symbol(+ - * /):");
    ch=getche();
    if(ch!='+'&&ch!='-'&&ch!='*'&&ch!='/')
    {
        printf("\nWrong input! Try again.\n");
        goto L1;
    }
    int c=computeraki(a, b, ch);
    printf("\nYou selected to do: a%cb=%d",ch,c);
}
int computeraki(int a, int b, char ch)
{
    switch(ch)
    {
    case '+':
        return a+b;
    case '-':
        return a-b;
    case '*':
        return a*b;
    case '/':
        return a/b;
    default:
        printf("Wrong input!;");
}
}


