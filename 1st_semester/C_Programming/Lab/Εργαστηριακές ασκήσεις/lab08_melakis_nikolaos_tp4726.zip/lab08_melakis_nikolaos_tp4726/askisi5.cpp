#include<stdio.h>
void test (int);
main(void)
{
    test (5);
}
void test (int n)
{
    printf ("Starting test with n = %d \n", n);
    if (n>0)
        test (n-1);
    printf ("Ending test with n = %d \n", n);
}
