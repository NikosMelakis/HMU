#include<stdio.h>
int possfloat(int);
main(void)
{
    int ak;
    printf("Give an integer:");
    scanf("%d",&ak);
    int sum=possfloat(ak);
    printf("The summary of the positive floats is: %d",sum);

}
int possfloat(int ak)
{
    int i=0;
    float fp, sum=0;

    while(i<ak)
    {
        printf("Give a float: ");
        scanf("%f",&fp);
        if(fp>=0)
            sum+=fp;
        i++;
    }
    return sum;
}
