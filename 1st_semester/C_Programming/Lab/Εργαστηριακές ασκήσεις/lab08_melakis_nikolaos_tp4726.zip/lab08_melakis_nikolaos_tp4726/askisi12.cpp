#include<stdio.h>
#include<math.h>
float StandDevia(int);
main(void)
{
    int n;
    printf("Give the limit:");
    scanf("%d",&n);
    float result=StandDevia(n);
    printf("\nStandard Deviation=%.6f",result);
}
float StandDevia(int n)
{
    int i;
    float sum,mo,sd=0.0, data[n], result=0;
    printf("Enter floats: ");
    for(i=0;i<n;++i)
        scanf("%f", &data[i]);
    for (i=0;i< 10;++i)
        sum+=data[i];

    mo=sum/10;
    for (i=0;i<10;++i)
        sd+=pow(data[i]-mo,2);
    result=sqrt(sd/10);

    return result;
}

