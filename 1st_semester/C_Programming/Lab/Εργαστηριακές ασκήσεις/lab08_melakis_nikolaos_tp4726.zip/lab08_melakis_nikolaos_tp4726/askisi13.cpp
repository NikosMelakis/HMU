#include<stdio.h>
#include<conio.h>
int counter(char);
main(void)
{
    char ch;
    printf("Give a character: ");
    ch=getchar();
    int cnt=counter(ch);
    printf("\n\nYou entered %d characters.",cnt);
}
int counter(char ch)
{
    printf("Function begins\n");
    int cnt=0;
    char xar;
    printf("Give a character: ");
    xar=getchar();
    while(xar!=ch)
    {
        printf("\nGive a new character:");
        xar=getche();
        cnt++;
    }
    return cnt;
}
