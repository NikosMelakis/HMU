#include<stdio.h>
main(void)
{
	char ch='z';
	while(ch>='#')
	{
		printf("For the char %c the num is %5d.\n",ch,ch);
		ch--;
	}
}

