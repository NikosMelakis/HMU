#include<stdio.h>
#include<string.h>

using namespace std;

main(void)
{
	char str[30];
	printf("Type your first name:");
	scanf("%s",&str);
	printf("\nYou typed: %s.",str);
	strrev(str);
	printf("\nAfter the reverse, the name you typed is: %s.",str);
	return 0;
}
	
	

