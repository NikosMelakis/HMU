#include<stdio.h>
main(void)

{
	int x,sum=0,count=0,mat[10];
	printf("Type 10 integers:");
	for(x=0;x<10;x++)
	{	
		scanf("%d",&mat[x]);
		if(mat[x]>0)
		count++;
		
	}
	for(x=0;x<10;x++)
	{
		sum+=mat[x];		
	}
	printf("\nThe sum of the array is: %d",sum);
	printf("\nThe possitive integers were %d",count);
	return 0;	
}
