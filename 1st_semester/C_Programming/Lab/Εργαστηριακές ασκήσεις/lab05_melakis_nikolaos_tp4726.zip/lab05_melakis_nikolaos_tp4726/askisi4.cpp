#include<stdio.h>
main(void)
{
	int temp=0;
	while(temp<=255)
	{
		printf("ASCII value of %c is %d.\n",temp,temp);
		temp++;
	}
}
