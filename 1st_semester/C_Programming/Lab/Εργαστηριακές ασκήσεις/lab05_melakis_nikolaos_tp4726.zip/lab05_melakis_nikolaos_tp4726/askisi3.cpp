#include<stdio.h>
main(void)

{
	int ak=1, sum=0;
	while(ak<=100)
	{
		sum=sum+ak;
		ak++;
	}
	printf("The sum is: %d",sum);
}
