#include<stdio.h>
#include<conio.h> 
main(void)

{
	char ch;
	printf ("Menu :\n");
	printf ("A-Play \n");
	printf ("B-Work \n");
	printf ("C-EXIT \n");
	printf ("\n Your choice -> ");
	ch = getche( );
	printf ("\n\n"); 
	switch (ch)
	{
		case 'A' : printf ("Now playing ... \n"); 
		break; 
		case 'B' : printf ("Now working ... \n"); 
		break; 
		case 'C' : printf ("Bye ... \n"); 
		break;
		default : printf ("Bad choice\n"); break;
	}
}

