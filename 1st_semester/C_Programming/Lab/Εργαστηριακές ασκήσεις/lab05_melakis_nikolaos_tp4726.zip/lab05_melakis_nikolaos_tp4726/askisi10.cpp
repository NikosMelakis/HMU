#include<stdio.h>
#include<math.h>

main(void) 
{
    int i;
    float sum,mo,sd=0.0,data[10];
    printf("Enter 10 floats: ");
    
    for(i=0;i<10;++i)
        scanf("%f", &data[i]);
    for (i=0;i< 10;++i) 
        sum+=data[i];
        
    mo=sum/10;
    for (i=0;i<10;++i)
        sd+=pow(data[i]-mo,2);
    printf("\nStandard Deviation=%.6f",sqrt(sd/10));
    return 0;
}

