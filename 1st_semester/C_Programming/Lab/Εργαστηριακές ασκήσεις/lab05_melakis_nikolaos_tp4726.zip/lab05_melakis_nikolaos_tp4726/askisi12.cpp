#include<stdio.h>

main(void)
{
	int x,y=0,pin[10],mat[10];
	printf("Enter integers:");
	for(x=0;x<10;x++)
	scanf("%d",&pin[x]);
	printf("\nThe initial array is:");
	for(x=0;x<10;x++)
	printf(" %1d,",pin[x]);
	
	for(x=9;x>=0;x--)
	{
		mat[y]=pin[x];
		y++;
	}
	printf("\n\n----- After the inverted copy paste -----");
	printf("\n\nThe first array is");
	for(x=0;x<10;x++)
	printf(" %1d,",pin[x]);
	printf("\n\nThe second array is");
	for(x=0;x<10;x++)
	printf(" %1d,",mat[x]);
	
	return 0;	
}
