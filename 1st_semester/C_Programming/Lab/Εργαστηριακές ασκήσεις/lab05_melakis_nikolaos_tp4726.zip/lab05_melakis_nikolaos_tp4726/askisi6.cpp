#include<stdio.h>
main(void)
{
	float fp,sum=0.0;
	int x=0,y=0;

	for(y=0;y<=10;y++)
	{
		printf("Give a float: ");
		scanf("%f",&fp);
		
		if(fp>=0)
		{
			x++;
			sum=sum+fp;
		}
		else
		{
			y++;
		}
	}
	
	printf("%d float(s) was(were) >0\n",x); 
	printf("The sum of the positive floats is: %5.2f",sum);
	

}
