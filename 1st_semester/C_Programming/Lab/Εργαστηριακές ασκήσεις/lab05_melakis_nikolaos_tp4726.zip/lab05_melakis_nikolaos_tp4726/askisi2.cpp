#include<stdio.h>
main(void)

{
	int ak;
	for(ak=1;ak<=100;ak++)
	printf("%5d",ak);
}
