#include <stdio.h>
#define N 10   

int main()
{
    int arr[N];
    int i, max, min, size;
   
    printf("Enter integers: ");
    for(i=0; i<N; i++)
    {
        scanf("%d", &arr[i]);
    }

    max = arr[0];
    min = arr[0];
    for(i=1; i<N; i++)
    {
      if(arr[i]>max)
        {
            max=arr[i];
        }
		else if(arr[i]<min)
        {
            min = arr[i];
        }
    }

    printf("Maximum integer = %d\nMinimum integer = %d",max,min);
    return 0;
}
