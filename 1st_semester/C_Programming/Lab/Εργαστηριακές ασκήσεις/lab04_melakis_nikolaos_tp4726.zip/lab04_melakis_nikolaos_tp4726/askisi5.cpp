#include<stdio.h>
#include<conio.h>
main(void)

{
	int the;
	printf("Give an integer: ");
	scanf("%d",&the);
	
	if(the<-30||the>50)
	printf("\nWrong input!");
	
	else if(the>40&&the<50)
	printf("\nVery worm");

	else if(the>10&&the<40)
	printf("\nGood weather");

	else if(the<10)
	printf("\nCold");

	else
	printf("Terminated");

	
}
