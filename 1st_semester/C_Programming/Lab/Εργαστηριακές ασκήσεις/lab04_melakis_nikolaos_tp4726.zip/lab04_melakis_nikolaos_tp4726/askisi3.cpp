#include<stdio.h>
#include<conio.h>


main(void)
{
	char c,h,a;
	printf("Type your pin: ");
	c=getch();
	putchar('*');
	h=getch();
	putchar('*');
	a=getch();
	putchar('*');
	
	printf("\nYour pin is:%c%c%c",c,h,a);
	
	
}
