#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
main(void)
{
	char ch;
	float pr,tel,bm,erg,olikos;
	printf("Give midterm and final exam degree: ");
	scanf("%f%f",&pr,&tel);
	bm=pr*0.4+tel*0.6;
	printf("\nDid you had lab exams?: ");
	ch=getche();
	
	if(ch=='n')
	{
	printf("\nGive lab degree: ");
	scanf("%f",&erg);
	olikos=bm*0.5+erg*0.5;
	printf("\n\nThe final result is: %4.1f",olikos);
	}
	else 
	printf("\n\nThe final result is: %4.1f",bm);
	
	
	
}
