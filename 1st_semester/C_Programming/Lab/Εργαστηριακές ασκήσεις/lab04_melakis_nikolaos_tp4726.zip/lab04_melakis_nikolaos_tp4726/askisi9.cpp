#include <stdio.h>
main()
{
	float mis,en,ex,fp;
	printf("Dwse mistho ypallilou.");
	scanf("%f",&mis);
	printf("Dwse enoikio ypallilou.");
	scanf("%f",&en);
	printf("Dwse eksoda diaviwshs ypallilou.");
	scanf("%f",&ex);
	fp=14*mis-12*en-ex;
	if (fp<0)
	{
		fp=0;
		printf("ANEILIKRINHS DHLWSH.");
		fp=7*mis;
	}
	if ((fp<10001)&&(fp>999))
		fp=fp*10/100;
	if ((fp>10000)&&(fp<20001))
		fp=(10000*10/100)+((fp-10000)*15/100);
	if ((fp>20000)&&(fp<30001))
		fp=(10000*10/100)+(10000*15/100)+((fp-20000)*20/100);
	if ((fp<1000)||(fp>30000))
		printf("AKRAIA EISODHMATA.");
	printf("O FOROS EINAI: %8.2f",fp);
}
