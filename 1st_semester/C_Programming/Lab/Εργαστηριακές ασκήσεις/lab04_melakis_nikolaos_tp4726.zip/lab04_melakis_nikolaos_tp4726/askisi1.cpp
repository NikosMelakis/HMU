#include<stdio.h> 
main(void)
{
	char ch;
	printf ("DWSTE XARAKTHRA KAI META<enter> -> ");
	ch = getchar( );
	printf ("DWSATE %c \n", ch); putchar ('B');
	putchar ('Y');
	putchar ('E');
	putchar('\n');
}
