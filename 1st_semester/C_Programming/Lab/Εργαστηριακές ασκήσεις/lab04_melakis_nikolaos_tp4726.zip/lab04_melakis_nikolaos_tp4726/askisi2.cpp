#include<stdio.h> 
#include<conio.h>
main(void)
{
	char ch;
	printf("Type some letter -> "); 
	ch = getche( );
	printf("\n");
	printf("You typed %c \n", ch);
}
