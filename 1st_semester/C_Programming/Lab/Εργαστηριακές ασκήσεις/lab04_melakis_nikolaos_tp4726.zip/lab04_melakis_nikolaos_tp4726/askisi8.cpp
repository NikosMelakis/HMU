#include<stdio.h>
#include<conio.h>
#include<math.h>

main(void)

{ 
	printf("H exiswsh einai: ax^2+bx+c");
	float a, b, c;
	float D, x, y;
	
	
	printf("\nDwse times gia to a,b,c: ");
	scanf("%f%f%f",&a,&b,&c);
	
	if(a==0&&b==0)
	printf("\nDen uparxei exiswsh");
	
	else if(a==0&&b!=0)
	printf("\nMia riza %f",-c/b);
	
	else if(a==0&&b!=0)
	{
		if(c=0);
		printf("\nOi rizes einai 0, %f",-b/a);
	}
	else if(a!=0&&b!=0)
	{
		if(c!=0);
			if(b*b-4*a*c>0)
			{
				x=(-b+sqrt(D))/2*a;
				y=(-b-sqrt(D))/2*a;
				printf("\nDuo pragmatikes rizers: x1=%.2f, x2=%.2f",x,y);					
			}
			else if(b*b-4*a*c<0)
			{
				x=(-b/2*a);
				y=(fabs(D)/2*a);
				printf("Migadikes rizes: x1=%.2f+jx2=%.2f  KAI x1=%.2f-jx2=%.2f",x,y,x,y);	
			}
			
	}
	else
	printf("error 404");
}

	
