#include<stdio.h>
#include<conio.h>
#include<math.h>
main(void)

{
	int a,b,c;
	printf("Give an integer for a,b,c: ");
	scanf("%d%d%d",&a,&b,&c);
	if(c=sqrt(a*a+b*b))
	printf("\n\nRectangle, a and b are vertical to c");
	else if(a=sqrt(b*b+c*c))
	printf("\n\nRecntagle, b and c are verticla to a");
	else if(b=sqrt(a*a+b*b))
	printf("\n\nRenctagle, a and c are vertical to b");
	else
	printf("\n\nWrong imput!");

}
