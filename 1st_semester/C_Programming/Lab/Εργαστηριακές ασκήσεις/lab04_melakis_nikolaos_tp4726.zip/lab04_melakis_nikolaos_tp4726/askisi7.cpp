#include<stdio.h>
#include<conio.h>
main(void)
{
	int gwn, mod;
	
	printf("Give degrees: ");
	scanf("%d",&gwn);
	
	while(gwn/360!=0)
	{
		mod=gwn%360;
		gwn=gwn/360;
	}
	
	if(mod>90)
	printf("\nH gwnia einai amvlia");
	else if(mod<90)
	printf("\nH gwnia einai oskeia");
	else
	printf("H gwnia einai orthi");
	
}
