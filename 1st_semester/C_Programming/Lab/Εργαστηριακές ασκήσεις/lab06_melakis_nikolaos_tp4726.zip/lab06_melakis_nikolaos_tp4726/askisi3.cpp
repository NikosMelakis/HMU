#include<stdio.h>
#include<conio.h>

#define MHN "WORK IN PROGRESS"


main(void)

{
	int count=0;
	char ch;
	printf("%s",MHN);
	printf("\nDo you wish to continue?(Y/N): ");
	ch=getche();

newtry:
	while(ch=='Y')
	{	
		printf("\n%s",MHN);
		printf("\nDo you wish to continue?(Y/N): ");
		ch=getche();
		count++;	
	}
	if(ch!='Y'&&ch!='N')
	{
		printf("\nWrong input! Try again");
		printf("\nDo you wish to continue?(Y/N): ");
		ch=getche();
		goto newtry;
			
	}
	else if(ch=='N')
		printf("\nThe end!");
	
		
	printf("\n\nYou typed Y %d times.",count);
	
	return 0;
}
