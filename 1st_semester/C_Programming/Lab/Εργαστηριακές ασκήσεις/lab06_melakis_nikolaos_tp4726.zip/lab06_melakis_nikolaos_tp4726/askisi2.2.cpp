#include<stdio.h>
#include<string.h>


main(void)

{
	char wrd[30];
	int m=0, i=0;
	printf("Give a string: ");
	scanf("%s",&wrd);
	do
	{
		i++;
		m++;
	}
	while(wrd[i]!='\x0');
	
	printf("The string lenght is %d\n",m);
}
