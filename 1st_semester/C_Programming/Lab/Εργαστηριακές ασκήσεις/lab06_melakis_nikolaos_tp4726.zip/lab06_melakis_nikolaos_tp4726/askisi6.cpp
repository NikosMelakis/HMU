#include<stdio.h>
#include<conio.h>

main(void)
{
	int i=1;
	int upper=0, lower=0;
	char ch;
	do
	{
		printf("\nType character number(%d): ",i);
		ch=getche();
		if(ch=='.')
		break;
		if(ch=='B'||ch=='b')
		continue;
		if(ch>='A'&&ch<='Z')
			upper++;
		if(ch>='a'&&ch<='z')
			lower++;
		i++;
	}while(i<=15);
	printf("\n\nUpper case letters: %d \nLower case letters:%d",upper,lower);
}
