#include<stdio.h>
#include<conio.h>

main(void)
{
	int i=1;
	int upper=0, lower=0;
	char ch;
	while(i<=15)
	{
		printf("\nType character number(%d): ",i);
		ch=getche();
		if(ch=='.')
		break;
		if(ch>='A'&&ch<='Z')
			upper++;
		if(ch>='a'&&ch<='z')
			lower++;
		i++;
	}
	printf("\n\nUpper case letters: %d \nLower case letters:%d",upper,lower);
}
