#include <stdio.h> 
main( )
{
	int i; i = 5;
	while (i<5) 
	{ 
		i++; 
	} 
	i = 5;
	do 
	{	
		i++; 
	} 
	while (i<5); 
		for (i=1; i<=10; i++) 
		{
			printf ("%d\n", i);	
			if (i==5) 
			break;
		}		
	for (i=-5;i<=5;i++) 
	{
		if (i==0) continue;
			printf ("%f\n", 1.0/i);
	}
	for (i=1;i<10;i+=2)
		printf ("%d\n", i); 
	for (i=10;i>0;i-=3)
		printf ("%d\n", i); 
}
