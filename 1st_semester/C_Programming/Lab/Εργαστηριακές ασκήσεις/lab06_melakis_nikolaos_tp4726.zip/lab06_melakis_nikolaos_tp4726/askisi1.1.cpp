#include<stdio.h>
#include<conio.h>

main(void)
{
	int count=0;
	char ch;
	while(ch!='A')
	{
	printf("\nType a character(A to quit): ");
	ch=getche();
	
	count++;
	}
	printf("\n\nYou tuped %d characters",count);
}


