#include<stdio.h>

#define N 10

main(void)

{
    int i, sum=0, mat[N];
    
    for(i=0; i<N; i++)
    {
    	printf("Enter an integer: ");
        scanf("%d", &mat[i]);
    }
    printf("The array is: ");
    for(i=0;i<10;i++)
    {
	    printf("%d, ",mat[i]);
    	if(mat[i]>0)
    		sum=sum+mat[i];
    }
    
    printf("\n\nThe sum of the positive integers you typed is: %d.", sum);
		
    
    return 0;
    
}
