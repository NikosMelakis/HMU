import 'dart:html';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/main.dart';
import 'package:sqflite/sqflite.dart';
import 'package:lab03/widgets/nav-drawer.dart';
import 'package:lab03/widgets/demographics.dart';

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.indigo[900],
        title: Text('SQFlite app'),
      ),
      body: Center(
        child: Text('Database functions'),
      ),
    );
  }
}
