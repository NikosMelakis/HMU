import 'package:flutter/material.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/widgets/demographics.dart';

class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: Text(
              'Menu',
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 25),
            ),
            decoration: BoxDecoration(
              color: Colors.indigo[900],
            ),
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Demographics'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Demographics()));
            },
          ),
        ],
      ),
    );
  }
}
