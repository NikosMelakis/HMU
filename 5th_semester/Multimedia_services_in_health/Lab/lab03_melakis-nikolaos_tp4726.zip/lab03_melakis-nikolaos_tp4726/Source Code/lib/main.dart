import 'dart:html';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:sqflite/sqflite.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginDemo(),
    );
  }
}

class LoginDemo extends StatefulWidget {
  @override
  _LoginDemoState createState() => _LoginDemoState();
  Future<void> fetchAndSetData() async {
    final datalist = await DBHelper.getData("members");
    print(datalist);
  }
}

FetchAndSetData() {
  DBHelper.insert('members', {
    'title': 'members',
    'text': 'name',
  });
}

class _LoginDemoState extends State<LoginDemo> {
  final _text1 = TextEditingController();
  final _text2 = TextEditingController();
  bool _validate = false;

  @override
  void dispose() {
    _text1.dispose();
    _text2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: Center(
                child: Container(
                  height: 150,
                  child: Text(
                    'Login',
                    style: TextStyle(color: Colors.black, fontSize: 35),
                  ),
                ),
              ),
            ),
            Padding(
              //padding: const EdgeInsets.only(left:15.0,right: 15.0,top:0,bottom: 0),
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                controller: _text1,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Email',
                    errorText: _validate ? 'Please enter a valid email.' : null,
                    hintText: 'e.g. john@doe.com'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                obscureText: true,
                controller: _text2,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Password',
                    errorText:
                        _validate ? 'Please enter a valid passoword.' : null,
                    hintText: 'Enter a secure password'),
              ),
            ),
            Container(
              height: 40,
              width: 250,
              decoration: BoxDecoration(
                  color: Colors.indigo[900],
                  borderRadius: BorderRadius.circular(20)),
              child: FlatButton(
                onPressed: () {
                  FetchAndSetData();
                  setState(() {
                    _text2.text.isEmpty
                        ? _validate = true
                        : Navigator.push(context,
                            MaterialPageRoute(builder: (_) => MyHomePage()));
                    _validate = false;
                    _text1.text.isEmpty ? _validate = true : _validate = false;
                  });
                },
                child: Text(
                  'Login',
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
            ),
            Padding(padding: const EdgeInsets.all(20.0)),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: SizedBox(
                child: Text(
                  'Don΄t have an account?',
                  style: TextStyle(color: Colors.black, fontSize: 15),
                ),
              ),
            ),
            FlatButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => SingUpDemo()));
              },
              child: Text(
                'Sing up.',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold),
              ),
            )
          ],
        ),
      ),
    );
  }
}
