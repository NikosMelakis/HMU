import 'package:covid_app/core/flutter_icons.dart';
import 'package:flutter/material.dart';

class CustomAppBarWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        IconButton(
          onPressed: null,
          icon: Icon(FlutterIcons.label),
        ),
        Container(
          width: 5,
          height: 5,
          margin: EdgeInsets.all(6),
        ),
      ],
    );
  }
}
