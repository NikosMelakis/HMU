import 'dart:html';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/main.dart';
import 'package:sqflite/sqflite.dart';
import 'package:lab03/widgets/nav-drawer.dart';
import 'package:lab03/widgets/demographics.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

class MyHomePage extends StatelessWidget {
  Widget myItems(IconData icon, String heading, Color color) {
    return Material(
      color: Colors.white,
      elevation: 14.0,
      shadowColor: Colors.grey,
      borderRadius: BorderRadius.circular(24.0),
      child: Center(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      heading,
                      style: TextStyle(color: color, fontSize: 25.0),
                    ),
                  ),
                  Material(
                    color: color,
                    borderRadius: BorderRadius.circular(24.0),
                    child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Icon(icon, color: Colors.white, size: 50.0)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.indigo[900],
        title: Text('Personal Health Record'),
      ),
      body: StaggeredGridView.count(
        crossAxisCount:
            2, //ο αριθμος των στηλων που θελουμε να καλυπτει το grid
        crossAxisSpacing:
            12.0, //η αποσταση μεταξυ των κουτιων στον οριζοντιο αξονα
        mainAxisSpacing: 12.0, //η αποσταση μεταξυ των κουτιων στον καθετο αξονα
        padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        children: [
          myItems(Icons.pie_chart_rounded, "Steps", Colors.indigo[900]),
          myItems(Icons.account_circle, "Demographics", Colors.indigo[900]),
          myItems(Icons.blur_on_outlined, "Problems", Colors.indigo[900]),
          myItems(Icons.pan_tool_outlined, "Allergies", Colors.indigo[900]),
          myItems(Icons.insights, "Heartrate", Colors.indigo[900]),
        ],
        staggeredTiles: [
          //οσα αντικειμενα βαλαμε στο children τοσα πρεπει να βαλουμε και εδω
          StaggeredTile.extent(1, 250.0),
          StaggeredTile.extent(1,
              150.0), //η πρωτη παραμετρος λεει ποσες στηλες να καλυπτει το tile/κουτι
          StaggeredTile.extent(
              1, 250.0), //δευτερη παραμετρος λεει το υψος τους tile/κουτιου
          StaggeredTile.extent(1, 150.0),
          StaggeredTile.extent(2, 240.0),
        ],
      ),
    );
  }
}
