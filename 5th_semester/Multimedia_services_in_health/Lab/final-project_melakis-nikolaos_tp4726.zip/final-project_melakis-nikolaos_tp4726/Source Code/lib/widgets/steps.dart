import 'dart:convert';

import 'package:date_field/date_field.dart';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/main.dart';
import 'package:lab03/widgets/allergies.dart';
import 'package:lab03/widgets/nav-drawer.dart';
import 'package:lab03/widgets/demographics.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:syncfusion_flutter_charts/charts.dart';

class Steps extends StatefulWidget {
  const Steps({key}) : super(key: key);

  @override
  _StepsState createState() => _StepsState();
}

class _StepsState extends State<Steps> {
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.indigo[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Steps",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Container(
        child: Column(children: <Widget>[
          Text(
            'Activity Duration: 1200000',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Activity Name: Walk',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Activity TypeId: 9001',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Calories: 220',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Distance Unit: Kilometer',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Duration: 7000',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Last Modified: 2020-12-12 | 10:36:33.000Z',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Log ID: 36232955350',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Log Type: Manual',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Original Duration: 2020-10-11 | 13:00:00.000+03:00',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Original Start Time:2020-10-11T13:00:00.000+03:00',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Pace: 0.5',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Source: Id:227G5L\nName:Fitbit Explorer\nType: App\nURL:http://swagger.io/swagger-ui/',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Speed: 7200',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Start Time: 2020-10-11T13:00:00.000+03:00',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
          Text(
            'Step: 2353',
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
        ]),
      ),
    );
  }
}
