import 'package:date_field/date_field.dart';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/main.dart';
import 'package:lab03/widgets/allergies.dart';
import 'package:lab03/widgets/nav-drawer.dart';
import 'package:lab03/widgets/demographics.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:syncfusion_flutter_charts/charts.dart';

class Heartrate extends StatefulWidget {
  const Heartrate({key}) : super(key: key);

  @override
  _HeartrateState createState() => _HeartrateState();
}

class _HeartrateState extends State<Heartrate> {
  List<SalesDataClass> _chartData;
  TooltipBehavior _tooltipBehavior;

  @override
  void initState() {
    _chartData =
        getChartData(); //αρχικοποιηση μεταβλητης που θα εχει τα δεδομενα
    _tooltipBehavior = TooltipBehavior(enable: true); //αρχικοποιω το tooltip
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.indigo[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Heartrate",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Center(
          child: SfCartesianChart(
              tooltipBehavior: _tooltipBehavior, //χρηση tooltip
              primaryXAxis: DateTimeAxis(),
              series: <ChartSeries>[
            // Renders scatter chart
            ScatterSeries<SalesDataClass, DateTime>(
                dataSource: _chartData,
                xValueMapper: (SalesDataClass sales, _) =>
                    sales.x, //datetime (ημερομηνια)
                yValueMapper: (SalesDataClass sales, _) =>
                    sales.y //αριθμητικη τιμη
                )
          ])),
    );
  }
} //εδω κλεινει η κλαση _MyAppState

List<SalesDataClass> getChartData() {
  //φτιαχνουμε μια συναρτηση για να επιστρεφουμε τα δεδομενα
  final List<SalesDataClass> chartData = [
    //μια λιστα απο SalesDataClass (το αντικειμενο που δημιουργησαμε παρακατω)
    SalesDataClass(
        DateTime.parse("2020-10-10"), 0), //παραδειγματα πως περναμε ημερομηνια
    SalesDataClass(DateTime(2020, 10, 11), 93), //χωρις parse με ετος,μηνα,ημερα
    SalesDataClass(DateTime(2020, 10, 12), 93),
    SalesDataClass(DateTime(2020, 10, 13), 93),
    SalesDataClass(DateTime(2020, 10, 14), 120),
    SalesDataClass(DateTime(2020, 10, 15), 101),
    SalesDataClass(DateTime(2020, 10, 16), 99),
    SalesDataClass(DateTime(2020, 10, 17), 130),
    SalesDataClass(DateTime(2020, 10, 18), 0),
  ];
  return chartData; //επιστροφη λιστασ δεδομενων
}

class SalesDataClass {
  //η κλαση για τα δεδομενα
  SalesDataClass(this.x,
      this.y); //o contructor για την κλαση παιρνει σαν ορισμα μια ημερομηνια datetime και ενα Integer
  final DateTime x;
  final int y;
}
