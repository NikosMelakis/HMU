import 'package:date_field/date_field.dart';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/main.dart';
import 'package:lab03/widgets/allergies.dart';
import 'package:lab03/widgets/nav-drawer.dart';
import 'package:lab03/widgets/demographics.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart' as syspath;

class AddAllergie extends StatefulWidget {
  const AddAllergie({key}) : super(key: key);

  @override
  _AddAllergieState createState() => _AddAllergieState();
}

class _AddAllergieState extends State<AddAllergie> {
  File _storedImage;
  var image;
  bool imagefile = false;

  //ειναι ασυγχρονη συναρτηση που επιστρεφει ενα future γιαυτο δηλωνουμε οτι ειναι και async
  Future<void> _takePicture() async {
    final picker = ImagePicker();
    final imageFile = await picker.pickImage(
        //ImageSource.camera δηλωνει οτι θελουμε να παρουμε φωτογραφια απο την καμερα
        source: ImageSource.camera,
        maxWidth: 600,
        maxHeight: 600);
    final appDir = await syspath
        .getApplicationDocumentsDirectory(); //ο φακελος που αποθηκευονται οι εικονες(οχι προσωρινα)
    if (imageFile != null) {
      print("inside");
      final fileName = path.basename(
          imageFile.path); //το path που αποθηκευεται η εικονα προσωρινα
      File file = File(imageFile.path);
      final savedImage = await file.copy(
          '${appDir.path}/$fileName'); //ετσι περναμε σαν string τις τιμες των μεταβλητων ( με το $)
      print(savedImage.path); //τυπωνω το path που αποθηκευτηκε στην συσκευη
      setState(() {
        _storedImage = File(imageFile.path);
        imagefile = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo[900],
        title: Text("Add Gallery"),
      ),
      body: Row(
        //παρομοιο με το column απλα η στοιχιση ειναι το ενα widget διπλα στο αλλο
        children: <Widget>[
          Container(
            width: 150,
            height: 100,
            decoration: BoxDecoration(
              border: Border.all(width: 1, color: Colors.grey),
            ),
            child: imagefile !=
                    false //αν η εικονα απο την καμερα εχει δημιουργηθει
                ? Image.file(
                    //εμφανισε τη στο κουτι
                    _storedImage,
                    fit: BoxFit.cover,
                    width: double.infinity,
                  )
                : Text(
                    //διαφορετικα εμφανισε ενα κειμενο
                    'No Image Taken',
                    textAlign: TextAlign.center,
                  ),
            alignment: Alignment.center,
          ),
          SizedBox(
            width: 10,
          ),
          Expanded(
            child: TextButton.icon(
              //χρησιμοποιουμε ενα κουμπι με εικονιδιο
              icon: Icon(Icons.camera), //το εικονιδιο της καμερας
              label:
                  Text('Take Picture'), // το κειμενο που θα φαινεται στο κουμπι
              onPressed:
                  _takePicture, //η future συναρτηση _takePicture που δηλωσαμε παραπανω
            ),
          ),
          Container(
            height: 40,
            width: 120,
            decoration: BoxDecoration(
                color: Colors.indigo[900],
                borderRadius: BorderRadius.circular(20)),
            child: FlatButton(
              onPressed: () {
                setState(() {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => MyHomePage()));
                });
              },
              child: Text(
                'Submit',
                style: TextStyle(color: Colors.white, fontSize: 25),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
