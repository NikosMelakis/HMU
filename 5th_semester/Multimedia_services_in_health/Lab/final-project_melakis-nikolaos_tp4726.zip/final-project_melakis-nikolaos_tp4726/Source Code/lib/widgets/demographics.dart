import 'dart:html';
import 'package:date_field/date_field.dart';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/main.dart';
import 'package:sqflite/sqflite.dart';
import 'package:lab03/widgets/nav-drawer.dart';
import 'package:lab03/widgets/demographics.dart';

class Demographics extends StatefulWidget {
  @override
  _DemographicsState createState() => _DemographicsState();
}

class _DemographicsState extends State<Demographics> {
  Future<void> fetchAndSetData() async {
    final datalist = await DBHelper.getData("members");
    print(datalist);
  }

  FetchAndSetData() {
    DBHelper.insert('members', {
      'title': 'Members',
      'text1': 'Name',
      'text2': 'Surname',
      'hintText': 'Birthdate',
      'items': 'Gender',
      'text5': 'Weight',
      'text6': 'Username',
      'text7': 'Password',
      'text8': 'Email',
    });
  }

  final _text1 = TextEditingController();
  final _text2 = TextEditingController();
  final _text3 = TextEditingController();
  final _text4 = TextEditingController();
  final _text5 = TextEditingController();
  final _text6 = TextEditingController();
  final _text7 = TextEditingController();
  final _text8 = TextEditingController();
  bool _validate = false;

  @override
  void dispose() {
    _text1.dispose();
    _text2.dispose();
    _text3.dispose();
    _text4.dispose();
    _text5.dispose();
    _text6.dispose();
    _text7.dispose();
    _text8.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: Center(
                child: Container(
                  height: 100,
                  child: Text(
                    'User Information',
                    style: TextStyle(color: Colors.black, fontSize: 35),
                  ),
                ),
              ),
            ),
            Padding(
              //padding: const EdgeInsets.only(left:15.0,right: 15.0,top:0,bottom: 0),
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 15),
              child: TextField(
                controller: _text1,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Name',
                    errorText: _validate ? 'Please enter a valid name.' : null,
                    hintText: 'e.g. John'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                controller: _text2,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Surname',
                    errorText:
                        _validate ? 'Please enter a valid surname.' : null,
                    hintText: 'e.g. Doe'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: DateTimeFormField(
                decoration: InputDecoration(
                  labelText: 'Birtdate',
                  hintText: 'DD/MM/YYYY - HH/MM',
                  errorText: _validate ? 'Please enter a valid date.' : null,
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.event_note),
                ),
                onDateSelected: (DateTime value) {},
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: DropdownButtonFormField(
                decoration: InputDecoration(
                  hintText: 'Gender',
                  errorText: _validate ? 'Please enter a valid gender.' : null,
                  border: OutlineInputBorder(),
                ),
                items: <String>['Male', 'Female', 'Do not want to declare']
                    .map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (_) {},
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                controller: _text5,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Weight',
                    errorText:
                        _validate ? 'Please enter a valid amount.' : null,
                    hintText: 'e.g. 70kg'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                controller: _text6,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Username',
                    errorText:
                        _validate ? 'Please enter a valid username.' : null,
                    hintText: 'e.g. JohnDoe'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                obscureText: true,
                controller: _text7,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Password',
                    errorText:
                        _validate ? 'Please enter a valid password.' : null,
                    hintText: 'Enter a secure password'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 20),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                controller: _text8,
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Email',
                    errorText: _validate ? 'Please enter a valid email.' : null,
                    hintText: 'e.g john@doe.com'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 15, bottom: 40),
            ),
            Container(
              height: 40,
              width: 250,
              decoration: BoxDecoration(
                  color: Colors.indigo[900],
                  borderRadius: BorderRadius.circular(20)),
              child: FlatButton(
                onPressed: () {
                  FetchAndSetData();
                  setState(() {
                    _text8.text.isEmpty
                        ? _validate = true
                        : Navigator.push(context,
                            MaterialPageRoute(builder: (_) => LoginDemo()));
                    _validate = false;
                    _text1.text.isEmpty ? _validate = true : _validate = false;
                    _text2.text.isEmpty ? _validate = true : _validate = false;
                    _text3.text.isEmpty ? _validate = true : _validate = false;
                    _text4.text.isEmpty ? _validate = true : _validate = false;
                    _text5.text.isEmpty ? _validate = true : _validate = false;
                    _text6.text.isEmpty ? _validate = true : _validate = false;
                    _text7.text.isEmpty ? _validate = true : _validate = false;
                  });
                },
                child: Text(
                  "Apply Changes",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
            ),
          ],
        ),
      ),
    );
  }
}
