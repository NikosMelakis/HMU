import 'package:flutter/material.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/widgets/allergies.dart';
import 'package:lab03/widgets/demographics.dart';
import 'package:lab03/widgets/heartrate.dart';
import 'package:lab03/widgets/problems.dart';
import 'package:lab03/widgets/steps.dart';

class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: Text(
              'PHR',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 25),
            ),
            decoration: BoxDecoration(
              color: Colors.indigo[900],
            ),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Home'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => MyHomePage()));
            },
          ),
          ListTile(
            leading: Icon(Icons.favorite),
            title: Text('Heartrate'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Heartrate()));
            },
          ),
          ListTile(
            leading: Icon(Icons.directions_walk_rounded),
            title: Text('Steps'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Steps()));
            },
          ),
          ListTile(
            leading: Icon(Icons.bed_rounded),
            title: Text('Problems'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Problems()));
            },
          ),
          ListTile(
            leading: Icon(Icons.enhanced_encryption),
            title: Text('Allergies'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Allergies()));
            },
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Demographics'),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Demographics()));
            },
          ),
        ],
      ),
    );
  }
}
