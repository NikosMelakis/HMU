import 'dart:html';
import 'package:date_field/date_field.dart';
import 'package:lab03/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:lab03/SingUpDemo.dart';
import 'package:lab03/HomePage.dart';
import 'package:lab03/main.dart';
import 'package:lab03/widgets/addallergie.dart';
import 'package:lab03/widgets/addproblem.dart';
import 'package:sqflite/sqflite.dart';
import 'package:lab03/widgets/nav-drawer.dart';
import 'package:lab03/widgets/demographics.dart';

class Problems extends StatefulWidget {
  const Problems({key}) : super(key: key);

  @override
  _ProblemsState createState() => _ProblemsState();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}

class _ProblemsState extends State<Problems> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          "Problems",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: Center(),
            ),
            Container(
              height: 40,
              width: 250,
              decoration: BoxDecoration(
                  color: Colors.indigo[900],
                  borderRadius: BorderRadius.circular(20)),
              child: FlatButton(
                onPressed: () {
                  FetchAndSetData();
                  setState(() {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => AddProblem()));
                  });
                },
                child: Text(
                  'Add Problem',
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
