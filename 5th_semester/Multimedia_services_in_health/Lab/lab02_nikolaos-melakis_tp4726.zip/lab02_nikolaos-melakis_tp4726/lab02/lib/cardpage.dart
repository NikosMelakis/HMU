import 'package:flutter/material.dart';

class Article1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("What is depression?"),
          backgroundColor: Colors.blueAccent,
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(10),
            ),
            Container(
              child: Text(
                '\nSome of these comments may be well-intentioned but they show a lack of understanding of the nature of depression.'
                'The problem is rooted in the use of the word <depression> as a diagnosis. The reason this is a problem is due to the word <depression>'
                'also being used by the public to describe a mood such as Im feeling depressed today. However, a temporary mood and a diagnosable illness are two very different things.'
                '\n\nSo the use of the same term to describe apples and oranges creates a great deal of confusion and misunderstanding.'
                'It certainly would make sense if we could change the name of the diagnosis to something else: “XYZ Disorder” that'
                'wouldnt have any other association in the publics mind. However, this was tried by the mental health profession'
                'in the past when they changed the diagnostic term manic-depression to bipolar disorder. At the same time they changed major depression to unipolar disorder but it wasnt accepted in either the publics mind or the professions.'
                'Therefore, the best we can do at this ',
                textAlign: TextAlign.left,
                overflow: TextOverflow.ellipsis,
                maxLines: 100,
              ),
            ),
          ],
        ));
  }
}

class Article2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Why is this problem?"),
          backgroundColor: Colors.blueAccent,
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(10),
            ),
            Container(
              child: Text(
                '\nIf the public calls this temporary mood state “depression” they will '
                'erroneously believe that they know what it feels like to be depressed in the clinical '
                'sense of the word. However, they will be wrong! \n\nEven though they are wrong, it wont '
                'stop them from making certain assumptions and comments that can be very detrimental to people who have a diagnosable condition.',
                textAlign: TextAlign.left,
                overflow: TextOverflow.ellipsis,
                maxLines: 100,
              ),
            ),
          ],
        ));
  }
}

class Article3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("When is depression cuased byt stress?"),
          backgroundColor: Colors.blueAccent,
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(10),
            ),
            Container(
              child: Text(
                '\nAn adjustment disorder may involve the depressive symptoms but the symptoms can be traced to a single '
                'event or a period of stress in a persons life. In addition, an adjustment disorder is not likely to be recurrent '
                'unless triggered by other events or periods of stress. \n\nHowever, this condition should not be confused with a depressive '
                'illness which has an underlying biological cause as we understand it today.An adjustment disorder, in particular, '
                'can be very receptive to CBT methods since these methods directly impact the ability to cope with stress. '
                'In addition, practicing stress management methods and addressing daily stress is likely to be helpful in preventing the occurrence of an adjustment disorder.',
                textAlign: TextAlign.left,
                overflow: TextOverflow.ellipsis,
                maxLines: 100,
              ),
            ),
          ],
        ));
  }
}

class Article4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Why does it seem that depression is caused by stress?"),
          backgroundColor: Colors.blueAccent,
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(10),
            ),
            Container(
              child: Text(
                '\nThe problem is that we only have so much in terms of physiological resources.'
                ' In addition, the psychological impact of stress is that a person finds it more difficult '
                'to do the necessary self-care. With a common cold, for example, it may be hard to obtain '
                'the necessary rest. As a result of the physiological and psychological factors, it becomes '
                'more difficult to recover from the common cold.This same process occurs with clinical depression. '
                '\n\nThe more stressors in a persons life, the more difficult it becomes to recover from the depression. '
                'Therefore, many people will tend to associate the presence of these stressors as the cause of the depression. '
                'However, that is not the case. The stressors may impact the depression and make it worse or more difficult to '
                'recover, but they are not typically the cause. In fact, if a stressor is the cause, it is likely a different '
                'condition known as an adjustment disorder rather than depression which we will discuss later. However, those '
                'sorts of suggestions and comments without a full understanding of clinical depression become detrimental rather'
                ' than helpful because they can be seen as an attack which is just another stressor for the depressed individual.',
                textAlign: TextAlign.left,
                overflow: TextOverflow.ellipsis,
                maxLines: 100,
              ),
            ),
          ],
        ));
  }
}
