import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/rendering.dart';

class End extends StatefulWidget {
  const End({Key? key}) : super(key: key);

  @override
  _EndState createState() => _EndState();
}

class _EndState extends State<End> {
  var closingText = "Congratulations! You finished the questionaire";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text(''), backgroundColor: Colors.blueAccent),
        body: Container(
            child: ListView(children: <Widget>[
          Container(
            color: Colors.grey.shade50,
            child: Center(
                child: Text(
              closingText,
              style: TextStyle(fontSize: 18),
            )),
          ),
          Container(
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed('/homepage');
              },
              style: ElevatedButton.styleFrom(
                  fixedSize: const Size(180, 20),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50)),
                  primary: Colors.blueAccent),
              child: Text("Homepage"),
            ),
          ),
        ])));
  }
}
