import 'dart:js';

import 'package:flutter/material.dart';
import 'package:lab02/cardpage.dart';
import 'package:lab02/cardpageqna.dart';
import './splashscreen.dart';
import './home.dart';
import './cardpagesuggest.dart';
import './cardpageqna.dart';
import './cardpage.dart';
import './end.dart';

void main() {
  runApp(MaterialApp(
    title: 'Depression CBT',
    initialRoute: '/splashscreen',
    routes: {
      '/': (context) => MyApp(), //οριζουμε τα μονοπατια NamedRoutes
      '/splashscreen': (context) => SplashScreen(),
      '/homepage': (context) => HomePage(),
      '/cardpagesuggest': (context) => CardPageSuggest(),
      '/cardpageqna': (context) => CardPageQna(),
      '/article1': (context) => Article1(),
      '/end': (context) => End(),
      '/article2': (context) => Article2(),
      '/article3': (context) => Article3(),
      '/article4': (context) => Article4(),
    },
  ));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text(''),
    );
  }
}
