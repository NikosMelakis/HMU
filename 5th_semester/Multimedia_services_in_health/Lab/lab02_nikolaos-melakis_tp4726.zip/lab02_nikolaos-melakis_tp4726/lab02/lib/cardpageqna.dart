import 'dart:convert';
import 'package:flutter/material.dart';
import './end.dart';
import './cardpage.dart';

class CardPageQna extends StatefulWidget {
  const CardPageQna({Key? key}) : super(key: key);

  @override
  _CardPageQnaState createState() => _CardPageQnaState();
}

class _CardPageQnaState extends State<CardPageQna> {
  var index = 0;
  var leadingText =
      "Over the last 2 weeks, how often have you been bothered by any of the following problems?";
  void incrementCounter() {
    if (index == 8) {
      Navigator.of(context).pushNamed('/end');
    } else {
      setState(() {
        index++;
      });
    }
  }

  Widget customcard(
      String text, String imagepath, String shortDescription, String route) {
    return Padding(
      padding: EdgeInsets.all(10.0),
      child: InkWell(
        onTap: () {
          Navigator.of(context).pushNamed(route);

          print(
              'card tapped'); //τυπωνεται οταν πατιεται η καρτα λογω του InkWell
        },
        child: Card(
          elevation: 10.0, //η σκια που θελουμε να φαινεται

          child: Wrap(
            children: [
              Image.network(imagepath),
              ListTile(
                title: Text(text),
                subtitle: Text(shortDescription),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text('Questionnaire'), backgroundColor: Colors.blueAccent),
        body: Container(
          child: ListView(children: <Widget>[
            Container(
              color: Colors.grey.shade50,
              child: Center(
                  child: Text(
                leadingText,
                style: TextStyle(fontSize: 15),
              )),
            ),
            // Χρησιμοποιουμε το FutureBuilder και το Future για να κανουμε load το Json
            Container(
                child: FutureBuilder(
              future:
                  DefaultAssetBundle // το future μπορει να παρει στο μελλον τιμη
                          .of(context)
                      .loadString('data/questionnaire.json'),
              builder: (context, snapshot) {
                //κραταει ενα snapshot της τωρινης καταστασης του future
                // Decode the JSON
                var newData = json.decode(snapshot.data
                    .toString()); //το snapshot.data μας το δινει το flutter και παινρουμε τα δεδομενα της καταστασης
                //του future εδω δηλαδη τα data του json αρχειου.
                return Card(
                  color: Colors.grey.shade50,
                  child: Column(
                    children: <Widget>[
                      Center(
                        child: Text(newData[index]['questionText'],
                            style: TextStyle(
                                fontSize: 22, color: Colors.grey.shade700)),
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 35),
                        child: ElevatedButton(
                          onPressed: () {
                            incrementCounter();
                          },
                          style: ElevatedButton.styleFrom(
                              fixedSize: const Size(180, 20),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50)),
                              primary: Colors.blueAccent),
                          child: Text(
                            newData[index]['answers'][0].toString(),
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 25),
                        child: ElevatedButton(
                          onPressed: () {
                            incrementCounter();
                          },
                          style: ElevatedButton.styleFrom(
                              fixedSize: const Size(180, 20),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50)),
                              primary: Colors.blueAccent),
                          child: Text(
                            newData[index]['answers'][1].toString(),
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 25),
                        child: ElevatedButton(
                          onPressed: () {
                            incrementCounter();
                          },
                          style: ElevatedButton.styleFrom(
                              fixedSize: const Size(180, 20),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50)),
                              primary: Colors.blueAccent),
                          child: Text(
                            newData[index]['answers'][2].toString(),
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 25),
                        child: ElevatedButton(
                          onPressed: () {
                            incrementCounter();
                          },
                          style: ElevatedButton.styleFrom(
                              fixedSize: const Size(180, 20),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50)),
                              primary: Colors.blueAccent),
                          child: Text(
                            newData[index]['answers'][3].toString(),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ))
          ]),
        ));
  }
}
