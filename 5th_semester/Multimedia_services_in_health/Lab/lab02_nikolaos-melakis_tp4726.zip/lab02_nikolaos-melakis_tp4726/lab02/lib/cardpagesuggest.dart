import 'package:flutter/material.dart';
import './cardpage.dart';

class CardPageSuggest extends StatefulWidget {
  const CardPageSuggest({Key? key}) : super(key: key);

  @override
  _CardPageSuggest createState() => _CardPageSuggest();
}

class _CardPageSuggest extends State<CardPageSuggest> {
  var text = [
    'What is depression?',
    'Why is this a problem?',
    'When is depression caused by stress?',
    'Why does it seem that depression is causedby stress?'
  ];
  var shortDescription = [
    'How often does a depressed person hear comments such as these?',
    'The misunderstanding occurs because just about everyone has experienced sadness or “feeling down.”',
    'Although the above conditions appear to be biological ...',
    'The fact is that the depressive disorders, as is true of most ...'
  ];
  List<String> images = [
    "https://images.pexels.com/photos/6249824/pexels-photo-6249824.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/4038984/pexels-photo-4038984.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/4913371/pexels-photo-4913371.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    "https://images.pexels.com/photos/4947569/pexels-photo-4947569.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  ];
  Widget customcard(
      String text, String imagepath, String shortDescription, String route) {
    return Padding(
      padding: EdgeInsets.all(10.0),
      child: InkWell(
        onTap: () {
          Navigator.of(context).pushNamed(route);

          print(
              'card tapped'); //τυπωνεται οταν πατιεται η καρτα λογω του InkWell
        },
        child: Card(
          elevation: 10.0, //η σκια που θελουμε να φαινεται

          child: Wrap(
            children: [
              Image.network(imagepath),
              ListTile(
                title: Text(text),
                subtitle: Text(shortDescription),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Suggestions'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Container(
        margin: EdgeInsets.symmetric(vertical: 20.0),
        height: 400.0,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            Container(
              width: 160,
              child: customcard(
                  text[0], images[0], shortDescription[0], '/article1'),
            ),
            Container(
              width: 160,
              child: customcard(
                  text[1], images[1], shortDescription[1], '/article2'),
            ),
            Container(
              width: 160,
              child: customcard(
                  text[2], images[2], shortDescription[2], '/article3'),
            ),
            Container(
              width: 160,
              child: customcard(
                  text[3], images[3], shortDescription[3], '/article4'),
            ),
          ],
        ),
      ),
    );
  }
}
