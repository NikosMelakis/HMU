package com.example.lab02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
