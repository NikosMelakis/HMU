package gr.hmu.nile.oop.java2.design_patterns;

import gr.hmu.nile.oop.java2.design_patterns.dao.Student;
import gr.hmu.nile.oop.java2.design_patterns.dao.StudentDao;
import gr.hmu.nile.oop.java2.design_patterns.dao.StudentDaoImplementation;
import gr.hmu.nile.oop.java2.design_patterns.factory.Shape;
import gr.hmu.nile.oop.java2.design_patterns.factory.ShapeFactory;
import gr.hmu.nile.oop.java2.design_patterns.factory.Square;
import gr.hmu.nile.oop.java2.design_patterns.observer.FirstObserver;
import gr.hmu.nile.oop.java2.design_patterns.observer.SecondObserver;
import gr.hmu.nile.oop.java2.design_patterns.observer.Subject;
import gr.hmu.nile.oop.java2.design_patterns.singleton.DBController;
import gr.hmu.nile.oop.java2.design_patterns.singleton.SingleDBConnection;
import gr.hmu.nile.oop.java2.design_patterns.singleton.SingleGameFrame;
import gr.hmu.nile.oop.java2.design_patterns.without_singleton.DBConnection;
import gr.hmu.nile.oop.java2.design_patterns.without_singleton.GameFrame;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws SQLException {

        Subject subject = new Subject(100);

        new FirstObserver(subject);
        new SecondObserver(subject);

        System.out.println("Score is: " + subject.getScore());

        subject.notifyAllObservers();

        System.out.println("<==========>");
        subject.setScore(500);

//        String shapeType;
//        Scanner console = new Scanner(System.in);
//        System.out.println("Enter shape type: ");
//        shapeType = console.nextLine();
//
//        ShapeFactory shapeFactory = new ShapeFactory();
//
//        Shape shape = shapeFactory.getShape(shapeType);
//        shape.draw();

//        Shape square = shapeFactory.getShape("square");
//        square.draw();
//
//        Shape rectangle = shapeFactory.getShape("rectangle");
//        rectangle.draw();

//        SingleDBConnection singleDBConnection = SingleDBConnection.getInstance("root", "", "student");
//
//        DBController dbController = new DBController(singleDBConnection);
//
//        StudentDao studentDao = new StudentDaoImplementation(dbController.retrieveAllUsers());
//
//        for (Student student : studentDao.getAllStudents()) {
//            System.out.println("Student: " + student.getName() + " am: " + student.getAm());
//        }

//        System.out.println("<==========>");
//        Student student1 = studentDao.getStudent(0);
//        System.out.println("Student: " + student1.getName() + " am: " + student1.getAm());

//        System.out.println("<==========>");
//        Student student2 = studentDao.getSpecificStudent(12345);
//        System.out.println("Student: " + student2.getName() + " am: " + student2.getAm());
//        student2.setName("Apostolis Marios");
//        studentDao.updateStudent(student2);

//        System.out.println("<==========>");
//        Student student3 = new Student("Nikos", 123);
//        String response = studentDao.addStudent(student3);
//        System.out.println(response);
//
//        System.out.println("<==========>");
//        for (Student student : studentDao.getAllStudents()) {
//            System.out.println("Student: " + student.getName() + " am: " + student.getAm());
//        }
//
//        System.out.println("<==========>");
//        String res = studentDao.deleteStudent(123);
//        System.out.println(res);
//
//        System.out.println("<==========>");
//        for (Student student : studentDao.getAllStudents()) {
//            System.out.println("Student: " + student.getName() + " am: " + student.getAm());
//        }
//

        //Class instance without using singleton design pattern
//        GameFrame gmFrame = new GameFrame("Game Frame");
//        GameFrame gmFrame2 = new GameFrame("Game Frame");

        //Class instance using singleton design pattern
//        SingleGameFrame gameFrame = SingleGameFrame.getInstance("Single Game Frame");

    }
}
