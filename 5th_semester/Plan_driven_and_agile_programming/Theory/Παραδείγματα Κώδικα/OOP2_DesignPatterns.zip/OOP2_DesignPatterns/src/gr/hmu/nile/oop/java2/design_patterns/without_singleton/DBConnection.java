package gr.hmu.nile.oop.java2.design_patterns.without_singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private final String username;
    private final String password;
    private final String databaseName;
    private Connection connection;

    public DBConnection(String username, String password, String dbname) {
        this.username = username;
        this.password = password;
        this.databaseName = dbname;
        this.initConnection();
    }

    private void initConnection() {
        String url = "jdbc:mysql://localhost/" + this.databaseName + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(url, this.username, this.password);
            System.out.println("Connection established!!!");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        return this.connection;
    }
}
