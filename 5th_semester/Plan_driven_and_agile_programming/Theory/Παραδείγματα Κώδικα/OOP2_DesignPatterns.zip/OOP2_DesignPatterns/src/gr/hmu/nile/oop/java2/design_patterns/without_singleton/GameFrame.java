package gr.hmu.nile.oop.java2.design_patterns.without_singleton;

import gr.hmu.nile.oop.java2.design_patterns.singleton.ConnectionListener;

import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame {

    private static int numberOfFrames = 1;

    public GameFrame(String frameTitle) {
        super(frameTitle + " with number: " + numberOfFrames++);
        this.initComponents();
    }

    private void initComponents() {
        this.setSize(600, 600);
        this.setLayout(new BorderLayout());
        Button connectBuuton = new Button("Connect to database");
        connectBuuton.addActionListener(new ButtonConnectionListener());
        this.add(connectBuuton, BorderLayout.NORTH);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

}
