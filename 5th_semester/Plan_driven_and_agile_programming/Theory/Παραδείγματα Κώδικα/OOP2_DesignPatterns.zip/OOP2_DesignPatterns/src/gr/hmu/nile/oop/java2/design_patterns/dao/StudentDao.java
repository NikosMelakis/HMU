package gr.hmu.nile.oop.java2.design_patterns.dao;

import java.util.List;

public interface StudentDao {

    public List<Student> getAllStudents();

    public Student getStudent(int index);

    public Student getSpecificStudent(int am);

    public String addStudent(Student student);

    public String deleteStudent(int am);

    public String updateStudent(Student student);

}
