package gr.hmu.nile.oop.java2.design_patterns.dao;

public class Student {

    private String name;
    private int am;
    private int id;

    public Student(String name, int am, int id) {
        this.name = name;
        this.am = am;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAm() {
        return am;
    }

    public void setAm(int am) {
        this.am = am;
    }
}
