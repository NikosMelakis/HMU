package gr.hmu.nile.oop.java2.design_patterns.singleton;

import gr.hmu.nile.oop.java2.design_patterns.dao.Student;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;

public class DBController {

    private final SingleDBConnection singleDbConnection;

    public DBController(SingleDBConnection connection) {
        this.singleDbConnection = connection;
    }

    public String insertUser() throws SQLException {
        PreparedStatement statement = this.singleDbConnection.getConnection().prepareStatement(
                "INSERT INTO user (id, username, email) VALUES (? ,?, ?)"
        );
        statement.setInt(1, 2);
        statement.setString(2, "apostolis");
        statement.setString(3, "apostolis@apostolis");
        statement.executeUpdate();
        statement.close();
        return "User inserted!!!";
    }

    public List<Student> retrieveAllUsers() throws SQLException {
        List<Student> studentsList = new ArrayList<Student>();
        Statement statement = this.singleDbConnection.getConnection().createStatement();
        ResultSet rs = statement.executeQuery("SELECT *  FROM student");
        while (rs.next()) {
            studentsList.add(new Student(rs.getString("name"), rs.getInt("am"), rs.getInt("id")));
        }
        statement.close();
        return studentsList;
    }


}
