package gr.hmu.nile.oop.java2.design_patterns.factory;

public class Square implements Shape {

    @Override
    public void draw() {
        System.out.println("Square");
    }
}
