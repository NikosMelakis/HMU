package gr.hmu.nile.oop.java2.design_patterns.dao;

import gr.hmu.nile.oop.java2.design_patterns.singleton.DBController;

import java.util.ArrayList;
import java.util.List;

public class StudentDaoImplementation implements StudentDao {

    private List<Student> students;

    public StudentDaoImplementation(List<Student> students) {
        this.students = students;
    }

    @Override
    public List<Student> getAllStudents() {
        return this.students;
    }

    @Override
    public Student getStudent(int index) {
        return this.students.get(index);
    }

    @Override
    public Student getSpecificStudent(int am) {
        for (Student student : students) {
            if (am == student.getAm()) {
                return student;
            }
        }
        return null;
    }

    @Override
    public String addStudent(Student student) {
        this.students.add(student);
        return "Added";
    }


    @Override
    public String deleteStudent(int am) {
        for (Student student : students) {
            if (am == student.getAm()) {
                students.remove(student);
                return "Deleted";
            }
        }
        return null;
    }

    @Override
    public String updateStudent(Student student) {
        for (Student std : students) {
            if (student.getAm() == std.getAm()) {
                std.setName(student.getName());
                return "Updated";
            }
        }
        return null;
    }
}
