package gr.hmu.nile.oop.java2.design_patterns.singleton;

import javax.swing.*;
import java.awt.*;

public class SingleGameFrame extends JFrame {

    private static SingleGameFrame instance;

    private SingleGameFrame(String frameTitle) {
        super(frameTitle);
        this.initComponents();
    }

    private void initComponents() {
        this.setSize(600, 600);
        this.setLayout(new BorderLayout());
        Button connectBuuton = new Button("Connect to database");
        connectBuuton.addActionListener(new ConnectionListener());
        this.add(connectBuuton, BorderLayout.NORTH);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static SingleGameFrame getInstance(String frameTitle) {
        if (instance != null) {
            System.out.println("I am a singleton class and I can create only one game frame!!!");
            return instance;
        }
        instance = new SingleGameFrame(frameTitle);
        return instance;
    }
}
