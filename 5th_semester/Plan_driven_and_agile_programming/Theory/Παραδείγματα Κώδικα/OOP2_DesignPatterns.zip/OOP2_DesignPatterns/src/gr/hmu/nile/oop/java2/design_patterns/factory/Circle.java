package gr.hmu.nile.oop.java2.design_patterns.factory;

public class Circle implements Shape {

    @Override
    public void draw() {
        System.out.println("Circle");
    }
}
