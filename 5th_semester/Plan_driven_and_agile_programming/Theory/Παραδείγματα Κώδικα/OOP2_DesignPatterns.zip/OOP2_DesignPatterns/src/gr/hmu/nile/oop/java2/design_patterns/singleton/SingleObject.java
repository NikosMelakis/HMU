package gr.hmu.nile.oop.java2.design_patterns.singleton;


public class SingleObject {

    private static SingleObject instance;

    private SingleObject() {
    }

    public static SingleObject getInstance() {
        if (instance != null) {
            System.out.println("I am a singleton class and I can create only one object!!!");
            return instance;
        }
        instance = new SingleObject();
        return instance;
    }

    public void showMessage() {
        System.out.println("something");
    }

}
