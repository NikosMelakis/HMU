package gr.hmu.nile.oop.java2.design_patterns.singleton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConnectionListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        //Στις παραμέτρους χρησιμοποιείτε το δικό σας usernmae, password kai database name
        SingleDBConnection singleDbConnection = SingleDBConnection.getInstance("root", "", "singelton_db");
    }
}
