package gr.hmu.nile.oop.java2.design_patterns.factory;

public interface Shape {
    public void draw();
}
