package gr.hmu.nile.oop.java2.design_patterns.without_singleton;

import gr.hmu.nile.oop.java2.design_patterns.singleton.SingleDBConnection;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonConnectionListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        //Στις παραμέτρους χρησιμοποιείτε το δικό σας usernmae, password kai database name
        DBConnection singleDbConnection = new DBConnection("root", "", "singelton_db");
    }
}
