package gr.hmu.nile.oop.java2.design_patterns.observer;

public class SecondObserver extends Observer {

    public SecondObserver(Subject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }

    @Override
    public void update() {
        System.out.println("Score in second observer is: " + this.subject.getScore());

        System.out.println("Octal String: " +
                Integer.toOctalString(subject.getScore()));
    }
}
