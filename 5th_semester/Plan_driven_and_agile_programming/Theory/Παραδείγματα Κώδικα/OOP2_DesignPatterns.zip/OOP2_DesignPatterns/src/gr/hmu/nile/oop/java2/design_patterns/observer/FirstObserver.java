package gr.hmu.nile.oop.java2.design_patterns.observer;

public class FirstObserver extends Observer {

    public FirstObserver(Subject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }

    @Override
    public void update() {
        System.out.println("Score in first observer is: " +this. subject.getScore());
        System.out.println("Binary String: "
                + Integer.toBinaryString(subject.getScore()));
    }
}
