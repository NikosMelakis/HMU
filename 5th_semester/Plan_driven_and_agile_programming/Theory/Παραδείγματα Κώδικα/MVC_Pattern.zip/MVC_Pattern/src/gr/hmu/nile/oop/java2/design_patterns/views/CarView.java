package gr.hmu.nile.oop.java2.design_patterns.views;

import gr.hmu.nile.oop.java2.design_patterns.models.CarModel;

import javax.swing.*;
import java.awt.*;

public class CarView extends JFrame {

    private JLabel jLabel;
    private JButton button;

    public CarView() {
        super("Cars Table");
        this.initComponents();
    }

    private void initComponents() {
        this.jLabel = new JLabel();
        this.button = new JButton("Update Model");
        this.add(this.jLabel, BorderLayout.NORTH);
        this.add(this.button, BorderLayout.SOUTH);
        this.setSize(500, 500);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public JButton getButton() {
        return this.button;
    }

    public void showCarData(CarModel carModel) {
        this.jLabel.setText("Car id: " + carModel.getId() + " brand: " + carModel.getBrand());
    }

}
