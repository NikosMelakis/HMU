package gr.hmu.nile.oop.java2.design_patterns;

import gr.hmu.nile.oop.java2.design_patterns.controllers.CarController;
import gr.hmu.nile.oop.java2.design_patterns.models.CarModel;
import gr.hmu.nile.oop.java2.design_patterns.views.CarView;

public class Main {

    public static void main(String[] args) {
        CarModel carModel = new CarModel(1, "Ford", "Black", "ABC1234", 1600);
        CarView carTableView = new CarView();

        CarController carController = new CarController(carModel, carTableView);
        carTableView.getButton().addActionListener(carController);
        carController.updateView();
    }
}
