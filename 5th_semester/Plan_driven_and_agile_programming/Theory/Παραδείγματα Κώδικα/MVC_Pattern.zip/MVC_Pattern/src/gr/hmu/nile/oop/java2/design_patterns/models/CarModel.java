package gr.hmu.nile.oop.java2.design_patterns.models;

public class CarModel {

    private int id;
    private String brand;
    private String color;
    private String license;
    private int cc;

    public CarModel(int id, String brand, String color, String license, int cc) {
        this.id = id;
        this.brand = brand;
        this.color = color;
        this.license = license;
        this.cc = cc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }
}
