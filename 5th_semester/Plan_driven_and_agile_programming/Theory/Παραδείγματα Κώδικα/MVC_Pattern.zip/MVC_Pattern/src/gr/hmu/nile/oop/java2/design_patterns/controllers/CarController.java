package gr.hmu.nile.oop.java2.design_patterns.controllers;

import gr.hmu.nile.oop.java2.design_patterns.models.CarModel;
import gr.hmu.nile.oop.java2.design_patterns.views.CarView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CarController implements ActionListener {

    private CarModel carModel;
    private CarView carView;

    public CarController(CarModel carModel, CarView carView) {
        this.carModel = carModel;
        this.carView = carView;
    }

    public void setCarModelBrand(String brand) {
        this.carModel.setBrand(brand);
    }

    public void setCarModelColor(String color) {
        this.carModel.setColor(color);
    }

    public void setCarModelLicense(String license) {
        this.carModel.setLicense(license);
    }

    public void setCarModelCc(int cc) {
        this.carModel.setCc(cc);
    }

    public void updateView() {
        this.carView.showCarData(this.carModel);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        this.setCarModelBrand("Fiat");
        this.carView.showCarData(carModel);
    }
}
