import java.util.Scanner;

public class Askhsh1{
    public static void main(String[] args){

        System.out.println("TP 4726"); //Prints my tp number
        
        Scanner in = new Scanner(System.in); // Define System input using a Scanner.
        int[] nums = new int[5];
        int sum=0, cnt=0;

        System.out.print("Enter a number: "); // Define a new array of 5 integers
        for(int i = 0; i < nums.length; i++) { // Loop 5 times
            nums[i] = in.nextInt(); // Read the next int from the cmd/console.
            sum+=nums[i];
            cnt++; //Does the sum for every int we type
        }

        if (cnt==5){
            System.out.println("The sum up of the integers you entered is: "+sum); //Prints the sum of the int we entered
        }
        else{
            System.out.println("The user didn't entered 5 integers");// Error message if user dint entered 5 ints
        }
    }
}
