public class Askhsh2{

    public static void main(String[] args) {
        Car car[] = new Car[10]; //Creating the array
        int j = 1;
        for (int i = 0; i < 10; i++) {
            car[i] = new Car("Brand " + (i), +(i + j) * 500);
        } //Loop to insert car(s) and cc(s)

        for (int i = 0; i < 10; i++) {
            System.out.println(car[i].toString() + "  " + car[i].getCc() + "cc");
        }//Loop to print the car(s) and the cc(s)

        // for (int i = 0; i < 10; i++) {

        // }
    }

}


class Car{
    //Parameters
    private String brand;
    private int cc;

    //Contructor(s)\

    public Car(){
    }

    public Car(String brand, int cc){
        this.brand=brand;
        this.cc=cc;
    }

    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public int getCc() {
        return cc;
    }
    public void setCc(int cc) {
        this.cc = cc;
    }

    //Method
    public String toString(){
        return(""+brand);
    }

    @Override
    public boolean equals(Object cc) {
        // TODO Auto-generated method stub
        return super.equals(cc);
    }
}