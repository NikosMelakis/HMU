public class Askhsh3{

    public static void main(String[] args) {
        Vehicle vehicle[] = new Vehicle[10]; //Creating the array

        Car c1= new Car();
        Motorcycle m1= new Motorcycle();

        for (int i = 0; i < 10; i++) {
            vehicle[i] = new Vehicle("Brand " + (i), +((i+1)*400));
        } //Loop to insert Vehicle(s) and cc(s)


        for (int i = 0; i < 3; i++) {
            System.out.println("Type Motorcycle "+vehicle[i].toString() + " " + vehicle[i].getCc() + "cc");
        }


        for (int i = 3; i < 6; i++) {
            System.out.println("Type Car "+vehicle[i].toString() + " " + vehicle[i].getCc() + "cc" +c1.toString());
        }//Loop to print the Vehicle(s) and the cc(s)

        for (int i = 6; i < 10; i++) {
            System.out.println("Type Vehicle "+vehicle[i].toString() + " " + vehicle[i].getCc() + "cc" +m1.toString());
        }

    }

}


class Vehicle{

    //Parameters
    private String brand;
    private int cc;

    //Contructor(s)\

    public Vehicle(){
        super();
    }

    public Vehicle(String brand, int cc){
        this.brand=brand;
        this.cc=cc;
    }

    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public int getCc() {
        return cc;
    }
    public void setCc(int cc) {
        this.cc = cc;
    }

    //Method
    public String toString(){
        return(""+brand);
    }

    @Override
    public boolean equals(Object cc) {
        // TODO Auto-generated method stub
        return super.equals(cc);
    }
}

class Car extends Vehicle{
    private int tires1;

    //Constructor(s)

    public Car(){
        tires1=4;
    }
    public Car(int tires1){
    this.tires1=tires1;
    }

    

    //Methods
    public String toString(){
        return (" No of tires: "+tires1);
    }

}

class Motorcycle extends Vehicle{
    private int tires2;

    //Constructor(s)

    public Motorcycle(){
        tires2=2;
    }
    public Motorcycle(int tires2){
        this.tires2=tires2;
    }
    //Methods
    public String toString(){
        return (" No of tires: "+tires2);
    }
}