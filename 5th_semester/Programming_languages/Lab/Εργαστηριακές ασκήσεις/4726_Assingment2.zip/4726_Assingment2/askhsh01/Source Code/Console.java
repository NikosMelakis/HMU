package VehicleSystem;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

public class Console {
	
	private static Scanner scan;
	private static int userOption;
	private static Vector<Vehicle> listOfVehicles; 
	
	public Console() {                           	
		scan = new Scanner(System.in);
		userOption = 5;
		listOfVehicles = new Vector<Vehicle>();
	}

	public static void main(String[] args) {
		
		Console console = new Console();
		
		while (userOption != 0) {               	               
			console.printMenu();                                   
			System.out.println("What would you like to do?");      
			String userInput = scan.nextLine();                   
			if (userInput == null) {                               
                continue;
            } else {
                try {
                    userOption = Integer.parseInt(userInput);      
                } catch (NumberFormatException ex) {              
                    userOption = 5;
                }
            }
			switch (userOption) {
            case 5:
                continue;
            case 0:
             	break;
            case 1:
            	userOption = 5;
            	while (!(userOption >= 1 && userOption <= 3)) {
            	console.printTypes();                            							
            	System.out.println("What type of vehicle would you like to create?");
            	userInput = scan.nextLine();                                                
            	if (userInput == null) {        
                    continue;
                } else {
                    try {
                        userOption = Integer.parseInt(userInput);
                    } catch (NumberFormatException ex) {                  
                        userOption = 5;
                    }
                }
    			switch (userOption) {
    			case 5:
    				continue;
    			case 1:
    				console.createNewCar();                
    				break;
    			case 2:
    				console.createNewTruck();            
    				break;
    			case 3:
    				console.createNewMot();               
    				break;
    			}
			}
            	break;
            case 2:
            	Vehicle v = console.findVehicle();
            	console.deleteExistingVehicle(v);         
                break;
            case 3:
            	v = console.findVehicle();
            	console.printVehicle(v);                 
            	break;
            case 4:
            	console.printAllVehicles();                  
            	break;
			}
		}		
	}
	
	public void printMenu(){			
		System.out.println("0: Exit");
		System.out.println("1: Create New Vehicle");
		System.out.println("2: Delete Existing Vehicle");
		System.out.println("3: Search for Existing Vehicle and Print its Info");
		System.out.println("4: Print all Vehicles");
	}
	
	public void printTypes() {
		System.out.println("1: Car");
		System.out.println("2: Truck");
		System.out.println("3: Motorcycle");
	}
	
	public void createNewCar() {                                        
		System.out.println("Give the car's model: ");
		String model = scan.nextLine();
		System.out.println("Give the car's registration number: ");
		String regNum = scan.nextLine();
		System.out.println("Give the car's cubic capacity: ");
		int cc;
		do {
			try {
				cc = scan.nextInt();
				break;
			} catch (InputMismatchException e) {
				System.out.println("Please give an integer.");        
				scan.nextLine();
			}
		}while(true);
		System.out.println("Is the car electrical?(true/false) ");
		boolean electric;
		do {
			try {
				electric = scan.nextBoolean();
				break;
			} catch (InputMismatchException e) {
				System.out.println("Please write true or false.");    
				scan.nextLine();
			} 
		}while(true);
		scan.nextLine();
		Car c = new Car("Car", model, regNum, cc, electric);
		listOfVehicles.add(c);
	}
	
	public void createNewTruck() {                                     
		System.out.println("Give the truck's model: ");
		String model = scan.nextLine();
		System.out.println("Give the truck's registration number: ");
		String regNum = scan.nextLine();
		System.out.println("Give the truck's cubic capacity: ");
		int cc;
		do {
			try {
				cc = scan.nextInt();
				break;
			} catch (InputMismatchException e) {
				System.out.println("Please give an integer.");          
				scan.nextLine();
			}
		}while(true);
		System.out.println("Give the truck's year of construction: ");
		int yoc;
		do {
			try {
				yoc = scan.nextInt();
				break;
			} catch (InputMismatchException e) {
				System.out.println("Please give an integer.");           
				scan.nextLine();
			}
		}while(true);
		scan.nextLine();
		Truck t = new Truck("Truck", model, regNum, cc, yoc);
		listOfVehicles.add(t);
	}
	
	public void createNewMot() {                                        
		System.out.println("Give the motorcycle's model: ");
		String model = scan.nextLine();
		System.out.println("Give the motorcycle's registration number: ");
		String regNum = scan.nextLine();
		System.out.println("Give the motorcycle's cubic capacity: ");
		int cc;
		do {
			try {
				cc = scan.nextInt();
				break;
			} catch (InputMismatchException e) {
				System.out.println("Please give an integer.");         
				scan.nextLine();
			}
		}while(true);
		scan.nextLine();
		Motorcycle m = new Motorcycle("Motorcycle", model, regNum, cc);
		listOfVehicles.add(m);
	}
	
	public Vehicle findVehicle() {   
		System.out.println("Give the vehicle's registration number: ");
    	String regNum = scan.nextLine();
		for (int i = 0; i < listOfVehicles.size(); i++) {
			Vehicle v = listOfVehicles.get(i);
			if (v.getRegNumber().equals(regNum)) 
				return v;
		}
		return null;
	}
	
	public void deleteExistingVehicle(Vehicle v) {        		                                
    	if (v == null)
    		System.out.println("Couldn't find the vehicle.");
    	else
    		for (int i = 0; i < listOfVehicles.size(); i++) {
    		    if (v.equals(listOfVehicles.get(i))) 
    		    	listOfVehicles.remove(i);
    		}
    		v = null;                                             
	}
	
	public void printVehicle(Vehicle v) {                
		if (v == null)
			System.out.println("Couldn't find the vehicle.");
		else
			System.out.println(v.toString());
	}
	
	public void printAllVehicles() {                                 
		for (int i = 0; i < listOfVehicles.size(); i++) {
			System.out.println(listOfVehicles.get(i).toString());
		}
	}
}
