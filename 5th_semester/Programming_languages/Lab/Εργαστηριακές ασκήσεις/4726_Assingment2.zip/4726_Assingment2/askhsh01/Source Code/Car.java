package VehicleSystem;

public class Car extends Vehicle implements Road_tax{

	private boolean electric;

	public Car() {                    
	}

	public Car(String type, String model, String regNumber, int cc, boolean electric) {      
		super(type, model, regNumber, cc);                                    			     
		this.electric = electric;
		calculateTax();
	}
	
	public boolean isElectric() {
		return electric;
	}

	public void setElectric(boolean electric) {
		this.electric = electric;
	}

	@Override
	public String toString(){                                 
		return super.toString() +", Electric: " +electric +", Road Tax: " +getTax()+"\n";   
	}

	@Override
	public void calculateTax() {         
		int tax = 0;
		if(getCc() < 1000) 
			tax = 100; 
		else if(getCc() < 1500)
			tax = 200; 
		else if(getCc() < 1800)
			tax = 250; 
		else
			tax = 300;
		if(isElectric())            
			setTax(tax/2);
		else
			setTax(tax);
	}	
}