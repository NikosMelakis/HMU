package VehicleSystem;
public interface Road_tax {
	public void calculateTax();        
}
