package VehicleSystem;

public class Motorcycle extends Vehicle implements Road_tax{
	
	public Motorcycle() {         
	}

	public Motorcycle(String type, String model, String regNumber, int cc) {          
		super(type, model, regNumber, cc);                                            
		calculateTax();
	}
	
	@Override
	public String toString(){                                 
		return super.toString() +", Road Tax: " +getTax()+"\n";   
	}

	@Override
	public void calculateTax() {        
		if(getCc() < 125) 
			setTax(20); 
		else if(getCc() < 400)
			setTax(40);
		else if(getCc() < 600)
			setTax(60);
		else
			setTax(80);
	}
}