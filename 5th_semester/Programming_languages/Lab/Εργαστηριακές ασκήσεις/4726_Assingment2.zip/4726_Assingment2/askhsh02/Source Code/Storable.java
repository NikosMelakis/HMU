package VehicleSystem;
public interface Storable {      
	String marshal();
	void unMarshal(String data);
}
