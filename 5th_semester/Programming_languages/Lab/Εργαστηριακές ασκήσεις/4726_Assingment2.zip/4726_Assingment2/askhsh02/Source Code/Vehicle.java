package VehicleSystem;

public abstract class Vehicle implements Storable {

	private String type, model, regNumber;
	private int cc;
	private long tax;
	
	public Vehicle() {                              							
	}
	
	public Vehicle(String type, String model, String regNumber, int cc) {       
		this.type = type;
		this.model = model;
		this.regNumber = regNumber;
		this.cc = cc;
	}

	public String getModel() {                   
		return model;
	}

	public void setModel(String model) {         
		this.model = model;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}

	public int getCc() {
		return cc;
	}

	public void setCc(int cc) {
		this.cc = cc;
	}

	public long getTax() {
		return tax;
	}

	public void setTax(long tax) {
		this.tax = tax;
	}

	@Override
	public String toString(){
		return "Type: " +type +", Model: " +model +", Registration number: " +regNumber +", CC: " +cc;      
	}
	
	public String marshal() {                                     
		return type +" " +model +" " +regNumber +" " +cc;
	}
	
	public void unMarshal(String data) {                         
		type = data.substring(0, data.indexOf(" "));
		data = data.substring(data.indexOf(" ")+1);
		model = data.substring(0, data.indexOf(" "));
		data = data.substring(data.indexOf(" ")+1);
		regNumber = data.substring(0, data.indexOf(" "));
		data = data.substring(data.indexOf(" ")+1);
		cc = Integer.parseInt(data.substring(0, data.indexOf(" ")));
	}
}