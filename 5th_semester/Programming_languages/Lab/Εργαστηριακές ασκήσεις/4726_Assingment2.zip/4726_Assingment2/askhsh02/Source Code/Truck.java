package VehicleSystem;

public class Truck extends Vehicle implements Road_tax{

	private int yearOfConstruction;
	
	public Truck() {                       
	}

	public Truck(String type, String model, String regNumber, int cc, int yearOfConstruction) {        
		super(type, model, regNumber, cc);                                                            
		this.yearOfConstruction = yearOfConstruction;
		calculateTax();
	}

	public int getYearOfConstruction() {
		return yearOfConstruction;
	}

	public void setYearOfConstruction(int yearOfConstruction) {
		this.yearOfConstruction = yearOfConstruction;
	}

	@Override
	public String toString(){
		return super.toString() +", Year of construction: " +yearOfConstruction +", Road tax: " +getTax() +"\n";     
	}

	@Override
	public void calculateTax() {                                
		int tax = 0;
		int ageIn5years = (2021-yearOfConstruction)/5;
		if(getCc() < 1500) 
			tax = 300; 
		else if(getCc() < 2500)
			tax = 400; 
		else
			tax = 450;
		for(int i = 0; i <ageIn5years; i++) {
			tax += 0.2*tax;
		}
		setTax(tax);
	}
	
	@Override
	public String marshal() {                                               
		return super.marshal() +" " +yearOfConstruction +" " +getTax();
	}
	
	@Override
	public void unMarshal(String data) {								   
		super.unMarshal(data);
		for (int i = 0; i <4; i++) {
			data = data.substring(data.indexOf(" ")+1);
		}
		yearOfConstruction = Integer.parseInt(data.substring(0, data.indexOf(" ")));
		data = data.substring(data.indexOf(" ")+1);
		setTax(Long.parseLong(data));
	}
}