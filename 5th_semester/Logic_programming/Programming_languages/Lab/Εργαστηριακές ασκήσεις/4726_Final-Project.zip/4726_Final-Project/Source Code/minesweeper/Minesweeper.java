package minesweeper;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Minesweeper extends JFrame {

    private JLabel statusbar;

    public Minesweeper() {

        Scanner sc= new Scanner(System.in);
        System.out.println("Select level[1:Beginner 2:Intermediate 3:Expert]: ");
        int input= Integer.parseInt(sc.nextLine());

        if(input == 1){
            initUI1();
        }
        else
            if(input == 2){
                initUI2();
            }
        else
            if(input == 3) {
                initUI3();
            }
        else
            System.out.println("Wrong input!");




    }

    private void initUI1() {

        statusbar = new JLabel("");
        add(statusbar, BorderLayout.SOUTH);

        add(new Board1(statusbar));

        setResizable(false);
        pack();

        setTitle("Minesweeper");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void initUI2() {

        statusbar = new JLabel("");
        add(statusbar, BorderLayout.SOUTH);

        add(new Board2(statusbar));

        setResizable(false);
        pack();

        setTitle("Minesweeper");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void initUI3() {

        statusbar = new JLabel("");
        add(statusbar, BorderLayout.SOUTH);

        add(new Board3(statusbar));

        setResizable(false);
        pack();

        setTitle("Minesweeper");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {

            var ex = new Minesweeper();
            ex.setVisible(true);
        });
    }
}