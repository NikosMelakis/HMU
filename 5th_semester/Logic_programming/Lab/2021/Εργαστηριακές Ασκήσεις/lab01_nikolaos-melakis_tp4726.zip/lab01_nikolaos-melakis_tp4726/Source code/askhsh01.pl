%GEGONOTA

student(12345,onomatepwnimo(nikos,melakis),dieuthinsi(fragkaki,9,71303,hraklio),
spoudes(hmu,stef,plhroforikh,logismikou)).

student(24689,onomatepwnimo(giorgos,sarris),dieuthinsi(patisia,126,73070,athens),
spoudes(uoa,architecture,arxitektonikh,interior_design)).

student(00001,onomatepwnimo(giannhs,aikaterinhs),dieuthinsi(koundourou,82,77500,lasithi),
spoudes(uoc,sdo,logistikis,xrimatooikonomika)).

student(32510,onomatepwnimo(eirinaios,galanakis),dieuthinsi(larisas,51,10555,xania),
spoudes(uoa,stya,ikarwn,iptamenoi)).

student(00001,onomatepwnimo(ioanna,kapsampeli),dieuthinsi(miliaraki,24,72444,rethymno),
spoudes(hmu,steg,dimosia_ygeia,noshleytikh)).

%STOXOI

%A
%student(AM,onomatepwnimo(Onoma,Epwnimo),dieuthinsi(Odos,Arithmo,TK,Poli),
spoudes(Onoma_AEI,Sxoli,plhroforikh,Katefthinsi)).

%B
%student(AM,onomatepwnimo(Onoma,Epwnimo),dieuthinsi(Odos,Arithmo,TK,hraklio),
spoudes(Onoma_AEI,Sxoli,Tmima,Katefthinsi)).

%C
%student(00001,onomatepwnimo(Onoma,Epwnimo),dieuthinsi(Odos,Arithmo,TK,Poli),
spoudes(Onoma_AEI,Sxoli,Tmima,Katefthinsi)).


