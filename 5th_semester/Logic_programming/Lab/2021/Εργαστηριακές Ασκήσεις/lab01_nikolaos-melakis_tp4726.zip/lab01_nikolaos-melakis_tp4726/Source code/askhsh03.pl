%a 
connected(X,X).

%b 
connected(X,Y):- edge(X,Y).
connected(X,Y):- connected(X,Z), edge(Z,Y).