stackDs:-
        empty_stack(St),
        read_names(St).

read_names(St):-
        write('Give a name: '),
        read(Name),
        \+Name='exit',
        push(St, Name, St1),
        read_names(St1).

read_names(St):-
        print_names(St).

print_names(St):-
        \+empty_stack(St),
        top(St, Elem),
        write(Elem), nl,
        pop(St, St1),
        print_names(St1).

print_names(St):-
        write('--Programm ended--').



empty_stack([]).
top([H|T], H).
pop([H|T], T).
push(Q, X, [X|Q]).


empty_stack([]).
top([H|T], H).
pop([H|T], T).
push(Q, X, [X|Q]).

begin:-
    empty_stack(S),
    readNames(S).

readNames(S):-
    write('Type a name: {type end to close}'), nl,
    read(Name),
    \+Name='end',
    push([S], Name, S1),
    readNames(S1).

readNames(S):-
    printNames(S).

printNames(S):-
    \+empty_stack(S),
    top(S, Elem),
    write(Elem), nl,
    pop(S, S1),
    printNames(S1).

printNames(S):-
    nl,
    write('Program Closed!').
