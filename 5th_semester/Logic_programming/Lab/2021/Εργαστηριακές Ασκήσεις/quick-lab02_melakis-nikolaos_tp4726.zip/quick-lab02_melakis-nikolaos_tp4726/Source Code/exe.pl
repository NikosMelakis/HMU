%Melakis Nikolaos TP4726
%2h ergasia sth taxh

%Data
didaskei(kostas,lp). 
didaskei(kostas,ai).
didaskei(nikos,maths).

mathima(maths). 
mathima(ai). 
mathima(lp). 

didaskon(nikos).
didaskon(kostas).

%Accusations
den_didaskei(X, Y):-
    didaskon(X),
    mathima(Y),
    \+ didaskei(X, Y).

%Targets
%den_didaskei(X, Y).
%Output
%| ?- den_didaskei(X, Y).                                     
%X = nikos,
%Y = ai ? ;
%X = nikos,
%Y = lp ? ;
%X = kostas,
%Y = maths ? ;
%no