teaches(ioannou,logic). 
teaches(ioannou,statistics). 
teaches(ioannou,algebra).
teaches(andreou,programming).
teaches(andreou,compilers).

print_teaches_courses(X):-
                        teaches(X, Y),
                        write('Professor '), write(X),
                        write(' teaches '), write(Y),
                        nl, fail.