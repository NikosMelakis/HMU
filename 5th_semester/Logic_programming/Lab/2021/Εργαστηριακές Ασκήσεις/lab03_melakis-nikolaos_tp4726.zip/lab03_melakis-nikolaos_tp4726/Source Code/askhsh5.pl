p(b).
p(X) :- 
    q(X,Y), r(Y).
q(c,b).
q(a,a).
r(b).
r(a).