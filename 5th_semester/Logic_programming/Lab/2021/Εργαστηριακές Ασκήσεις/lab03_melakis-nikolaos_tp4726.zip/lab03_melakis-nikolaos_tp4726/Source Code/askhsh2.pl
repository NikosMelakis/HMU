f(X):- 
    X<0, !, write(0).
f(X):- 
    X>=0, X=<1, !, write(X).
f(X):- 
    X>1, !,write(1).