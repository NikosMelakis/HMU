empty_stack([]).           

parenthesis_LR_same(S):-           
    name(S, [H|T]),
    check(T, [H]).

check([], S):-        
    empty_stack(S).

check([H|T], [H|T1]):-    
    push([H|T1], H, R),  
    check(T, R).       

check([H|T], [H1|T1]):-    
    H \= H1,     
    pop([H1|T1], R),
    check(T, R).
    
push(Q,S, [S|Q]).            

pop([H|T], T).  