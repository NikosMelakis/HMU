empty_seq([]).
empty_seq([]).

merge_sort(S1, S2):- 
    empty_set(S1), 
    empty_seq(S2). 
merge_sort(S1, S2):-
    \+ empty_set(S1), 
    member_set(Elem,S1), 
    delete_elem_set(Elem, S1, RestS1),
    merge_sort(RestS1, RestS2), 
    ins_elem(Elem,RestS2,S2). 
    
ins_elem(E,Q1, Q):- 
    empty_seq(Q1), 
    seq_cons(Q1,E, Q). 

ins_elem(E,Q1, Q):-
    head(Q1, V1), 
    E @=< V1, 
    seq_cons(Q1, E, Q). 

ins_elem(E,Q1, Q):-
    head(Q1,V),
    E @> V, 
    tail(Q1,Q1a),
    ins_elem(E,Q1a, Qa), 
    seq_cons(Qa,V, Q). 