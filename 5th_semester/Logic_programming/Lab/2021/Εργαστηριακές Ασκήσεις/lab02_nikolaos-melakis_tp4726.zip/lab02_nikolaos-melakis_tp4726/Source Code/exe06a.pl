maxElement([H], Max) :- 
                        Max = H. 

maxElement([H|T], Max) :- 
                        maxElement(T, Max2), 
                        H >= Max2,          
                        Max = H.            

maxElement([H|T], Max) :- 
                        maxElement(T, Max2),
                        H < Max2,          
                        Max = Max2.