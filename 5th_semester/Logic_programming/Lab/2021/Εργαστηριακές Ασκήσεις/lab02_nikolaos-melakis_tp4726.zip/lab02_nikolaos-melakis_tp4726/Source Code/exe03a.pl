one_oc([], []).
one_oc([X|L1], L2) :- 
                    member(X, L1), 
                    one_oc(L1, L2).

one_oc([X|L1], [X|L2]) :- 
                    \+member(X, L1), 
                    one_oc(L1, L2).
