maxElement([H|T], Max) :- 
                        maxElement_1([H|T], Max, H). 

maxElement_1([], Max, M) Max = M.

maxElement_1([H|T], Max, Max2) :- 
                                H >= Max2, 
                                Max3 is H, 
                                maxElement_1(T, Max, Max3).

maxElement_1([H|T], Max, Max2) :- 
                                H < Max2, 
                                maxElement_1(T, Max, Max2).