evenNumbers(L1, L2) :- 
                    evenNumbers_1(L1, L2, []). 

evenNumbers_1([], L2, L3) :-
                            L2 = L3.

evenNumbers_1([H1|T1], L2, L3) :- 
                                (H1 mod 2) =:= 0,    
                                append(L3, [H1], L4),
                                evenNumbers_1(T1, L2, L4).

evenNumbers_1([H1|T1], L2, L3) :- 
                                (H1 mod 2) =:= 1, 
                                evenNumbers_1(T1, L2, L3).