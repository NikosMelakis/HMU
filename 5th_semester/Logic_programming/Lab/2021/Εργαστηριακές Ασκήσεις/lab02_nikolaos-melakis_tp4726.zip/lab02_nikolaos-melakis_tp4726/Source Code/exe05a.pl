evenNumbers([], []).

evenNumbers([H1|T1], L2) :- 
                        (H1 mod 2) =:= 0,  
                        evenNumbers(T1, T2),
                        L2 = [H1|T2].           

evenNumbers([H1|T1], L2) :- 
                        (H1 mod 2) =:= 1, 
                        evenNumbers(T1, L2).