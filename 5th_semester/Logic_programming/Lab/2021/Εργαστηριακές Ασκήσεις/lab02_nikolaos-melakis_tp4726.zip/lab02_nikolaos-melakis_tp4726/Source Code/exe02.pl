taxinomemene( []  ) .
taxinomemene( [_] ) .
taxinomemene( [X,Y|Z] ) :- 
                    X =< Y , 
                    taxinomemene([Y|Z]) .