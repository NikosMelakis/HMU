aMember(X,L):-
            append(L1, [X|T], L).

adjacent(X, Y, L):-
            append(L1, [X, Y| T], L).

last(X,L):-
            append(L1, [X], L).