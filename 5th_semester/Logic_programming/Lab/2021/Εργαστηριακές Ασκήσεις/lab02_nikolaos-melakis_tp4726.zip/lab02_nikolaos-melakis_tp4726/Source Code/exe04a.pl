occur([], X, 0).
occur([H|T], X, N) :-
                    occur(T, X, M),
                    N is M+1.

occur([X|T], H, N) :-
                    occur(T, X, N).
