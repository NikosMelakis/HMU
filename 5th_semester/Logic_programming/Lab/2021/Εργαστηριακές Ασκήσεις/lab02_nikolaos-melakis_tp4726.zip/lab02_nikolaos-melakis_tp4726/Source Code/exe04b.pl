occur(L, X, N) :- 
                occur_1(L, X, N, 0). 

occur_1([], X, N, N).

occur_1([H|T], X, N, N2) :-       
                            N3 is N2+1,
                            occur_1(T, X, N, N3).

occur_1([H|T], X, N, N2) :- 
                            occur_1(T, X, N, N2).