stackDs:-
        empty_stack(St),
        read_names(St).

read_names(St):-
        write('Give a name: '),
        read(Name),
        \+Name='exit',
        push(St, Name, St1),
        read_names(St1).

read_names(St):-
        print_names(St).

print_names(St):-
        \+empty_stack(St),
        top(St, Elem),
        write(Elem), nl,
        pop(St, St1),
        print_names(St1).

print_names(St):-
        write('--Programm ended--').



empty_stack([]).
top([H], H).
top([H|T], Last) :- 
    top(T, Last).
pop([H], []).
pop([H|T], [H|Rest]) :- 
    pop(T, Rest). 
push(Q, X, [X|Q]).