enoseTaxinList([Kef1|List1], [Kef2|List2], [Kef1|List3]):-
                                                        Kef1<Kef2, !,
                                                        enoseTaxinList(List1, [Kef2|List2], List3).

enoseTaxinList([Kef1|List1], [Kef2|List2], [Kef1, Kef2|List3]):-
                                                        Kef1=Kef2, !,
                                                        enoseTaxinList(List1, List2, List3).

enoseTaxinList([Kef1|List1], [Kef2|List2], [Kef2|List3]):-
                                                        Kef1>Kef2,
                                                        enoseTaxinList([Kef1|List1], List2, List3).

enoseTaxinList(List1, [], List1).
enoseTaxinList([], List2, List2).


