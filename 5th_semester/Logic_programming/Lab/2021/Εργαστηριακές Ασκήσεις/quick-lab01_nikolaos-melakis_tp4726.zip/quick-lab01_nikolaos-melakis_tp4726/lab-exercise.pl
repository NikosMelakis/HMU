find_polution(OMP):-
    write('Are there lab values? -Give Yes or No-'), nl,
    read(Lab_val),  find_omp(Lab_val, OMP).
find_omp(yes, OMP):-
    write('Give the values for BOD'), nl,   read(BOD),  bod(BOD, OMP).
find_omp(no, ANS):-
    write('Is the water cloudy? -Give Yes or No-'), nl,   read(CLOUDY),    cloudy(CLOUDY, ANS).

    bod(BOD, Ans_bod):-
        (BOD =< 5, Ans_bod = 'BOD: No Problem OMP');
        (BOD > 5, BOD =< 7, Ans_bod = 'BOD: Moderate OMP');
        (BOD > 7, BOD =< 15, Ans_bod = 'BOD: Severe OMP');
        (BOD > 15, Ans_bod = 'BOD: Very Severe OMP').

    cloudy(yes,ANS):-
        write('What color is the water? -Give Grey or Brown-?'), nl, read(WATER_COLOR),
        (WATER_COLOR = 'grey', write('Very Severe O.M.P.'));
        (WATER_COLOR = 'brown', write('No Problem O.M.P.')).
        
    cloudy(no,ANS):-
        (WATER_COLOR = 'brown',write('NO Problem O.M.P.'));
        (WATER_COLOR = 'gray', write('NO Problem O.M.P.'));
        (WATER_COLOR = no,     write('NO Problem O.M.P.')).