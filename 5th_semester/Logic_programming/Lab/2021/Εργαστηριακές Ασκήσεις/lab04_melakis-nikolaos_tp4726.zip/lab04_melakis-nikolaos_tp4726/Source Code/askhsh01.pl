kb('Giannis', likes,maths). 
kb('Giannis',likes,physics). 
kb('Giannis',plays,voleyball). 
kb('Giannis',plays,chess). 
kb('Giannis',plays,backetball). 
kb('Maria',likes,maths). 
kb('Maria',likes,geography). 
kb('Maria',plays,chess). 
kb('Maria',plays,tennis). 
kb('Eleni',likes,physics). 
kb('Eleni',likes,informatics). 
kb('Eleni',plays,voleyball). 
kb('Eleni', plays, tennis).


menu:-nl,                    
	write('Menu'),nl,
	write('Option 1:Read Name.'),nl,
	write('Option 2:Read Lesson.'),nl,
	write('Option 3:Read Game.'),nl,
	write('Option 4:Read Action.'),nl,
	write('Option 5:Exit.'),nl,
	read(Choice),
	choice(Choice).

choice(1):-write('Give Name with ''''.'),nl,
		read(Na),ch1(Na).
choice(2):-write('Give Lesson.'),nl,
		read(Maths),ch2(Maths).
choice(3):-write('Give Game.'),nl,
		read(G),ch3(G).
choice(4):-write('Give action: ( likes or plays).'),nl,
		read(V),ch4(V).
choice(5):-write('exit').


ch1(Na):-
		findall((Na,Y,Z),kb(Na,Y,Z),L),
		write(L), menu, nl.

ch2(Maths):-
		Y=likes,
		findall((X,Y,Maths),kb(X,Y,Maths),L),
		write(L), nl.

ch3(G):-	
		Y=plays,
		Z=G,
		findall((X,Y,Z),kb(X,Y,Z),L),
		write(L), nl.

ch4(V):-
		findall((X,V,Z),kb(X,V,Z),L),
		write(L), nl.