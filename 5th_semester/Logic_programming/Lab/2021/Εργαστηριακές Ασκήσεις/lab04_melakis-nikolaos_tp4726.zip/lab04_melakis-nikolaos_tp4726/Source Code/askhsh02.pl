
test:-
	see('C:/Users/Melakis/Desktop/kb_old.pl'),  
	tell('C:/Users/Melakis/Desktop/kb1.pl'),
	int_division,
	seen,
	told.
int_division:- 
	read(X),\+(X=end_of_file),   %read_each_row
	write(X),
	write('.'),nl,
	int_division.
	
int_division.