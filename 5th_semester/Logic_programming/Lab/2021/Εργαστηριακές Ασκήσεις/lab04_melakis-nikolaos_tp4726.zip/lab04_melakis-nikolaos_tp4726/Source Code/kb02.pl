student(1, [m_markakis,ie,2810379747,[ai,maths]]).
student(3, [s_petrou,ie,2810379727,[ai,maths,progr]]).
student(4, [v_fragou,ie,2810379768,[ai,maths,physics]]).
student(2, [n_melakis,ie,6973415131,[it,software]]).

students([1,2,3,4]).

