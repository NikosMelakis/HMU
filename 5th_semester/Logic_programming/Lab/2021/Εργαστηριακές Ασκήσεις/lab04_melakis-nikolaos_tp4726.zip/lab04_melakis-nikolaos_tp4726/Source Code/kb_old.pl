:- dynamic max_student_id/1, students/1, student/2.
max_student_id(4).
students([1,2,3,4]).
student(1, [m_markakis, ie, 2810379747,[ai,maths] ]).
student(2, [p_papadakis, ie, 2810379719,[ai,maths] ]).
student(3, [s_petrou, ie, 2810379727,[ai,maths,progr] ]).
student(4, [v_fragou, ie, 2810379768,[ai,maths,physics] ]).