:- use_module(library(lists)).
:-dynamic max_student_id/1,students/1,student/2.
max_student_id(4).
students([1,2,3,4]).
student(1,[m_markakis,ie,2810379747,[ai,maths]]).
student(2,[p_papadakis,ie,2810379719,[ai,maths]]).
student(3,[s_petrou,ie,2810379727,[ai,maths,progr]]).
student(4,[v_fragou,ie,2810379768,[ai,maths,physics]]).

update_KB:- 
    write('Menu'),nl,                      
	write('Select 1: Change.'),nl,
	write('Select 2: New.'),nl,
	write('Select 3: Delete.'),nl,
	write('Select other: Exit.'),nl,
    read(Num),nl,
    choice(Num).
    

choice(1) :- change_record_KB.				
choice(2) :- create_record_KB.
choice(3) :- delete_record_KB.
choice(Num) :- write('EXIT').


change_record_KB :- write('Give code'),nl,
    read(Code),nl,
    student(Code,L),
    write(L),nl,
    retract(student(Code,L)),		
    write('Give new changed data'),nl,
    read(Data),
    assert(student(Code,Data)),		
    save,
    update_KB. %again

create_record_KB :-
    write('Give data in [ ]'),
    students(Y),
    last(Y,N),
    retract(students(Y)),			
    T is N+1,
    read(Data1),nl,
    assert(student(T,Data1)),		
    append(Y,[T],Y1),
    tell('C:/Users/Melakis/Desktop/kb02.pl'),  
    assert(students(Y1)),
    told,
    update_KB. %agaim

delete_record_KB :-
    write('Give students number'),nl,
    read(Del_num),nl,
    retract(student(Del_num,S)),     
    save,
    update_KB. %again

save:- tell('C:/Users/Melakis/Desktop/kb02.pl'),
    retractall(student),            
    retractall(students),
    listing(student),				
    listing(students),
    told.

