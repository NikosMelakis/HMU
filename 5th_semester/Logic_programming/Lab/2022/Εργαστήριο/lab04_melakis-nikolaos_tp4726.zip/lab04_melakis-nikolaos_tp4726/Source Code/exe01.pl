%Nikolaos Melakis
%4 ergasthriakh ergasia | Askhsh 1

%Including the Knownledge Base
:- include('exe01KB.pl').

%Main Program
collect_results:-
    write('Main Menu | Type 1/2/3/4 or 5'), nl,
    write('1| Identify a name'), nl,
    write('2| Identify a course'), nl,
    write('3| Identify a game'), nl,
    write('4| Identify an activity'), nl,
    write('5| Terminate program'), nl, 
    read(Option), nl,
    choice(Option).

%Identify Name Option
choice(1):-
    write('Type a name: {between "} '), nl,
    read(Name),
    setof(Z, Y^kb(Name, Y, Z), L), 
    write(Name), write(' intrests and activities are '), write(L), nl, nl,
    collect_results.

%Identify Course Option
choice(2):-
    write('Type a course: '), nl,
    read(Course),
    setof(X, Z^kb(X, likes, Course), L),
    write(L), write(' likes '), write(Course), nl, nl,
    collect_results.

%Identify Game Option
choice(3):-
    write('Type a game: '), nl,
    read(Game),
    setof(X, Z^kb(X, plays, Game), L),
    write(L), write(' plays '), write(Game), nl, nl,
    collect_results.

%Identify an Activity Option
choice(4):-
    write('Type an activity: {likes/play}'), nl,
    read(Activity),
    setof((X, Z), Y^kb(X, Activity, Z), L),
    write(L), nl, nl,
    collect_results.

choice(5):-
    write('Program Terminated!').

%Any other input does not go through and user try's again
choice(X):-
    write("Wrong Input! Try again."), nl, nl,
    collect_results.



%Transcrip below
% ?- collect_results.
% Main Menu | Type 1/2/3/4 or 5
% 1| Identify a name
% 2| Identify a course
% 3| Identify a game
% 4| Identify an activity
% 5| Terminate program
% |: 1.

% Type a name: {between "} 
% |: 'Yannis'.
% Yannis intrests and activities are [basketball,chess,maths,physics,voleyball]

% Main Menu | Type 1/2/3/4 or 5
% 1| Identify a name
% 2| Identify a course
% 3| Identify a game
% 4| Identify an activity
% 5| Terminate program
% |: 2.

% Type a course: 
% |: maths.
% [Maria,Yannis] likes maths

% Main Menu | Type 1/2/3/4 or 5
% 1| Identify a name
% 2| Identify a course
% 3| Identify a game
% 4| Identify an activity
% 5| Terminate program
% |: 3.

% Type a game: 
% |: chess.
% [Maria,Yannis] plays chess

% Main Menu | Type 1/2/3/4 or 5
% 1| Identify a name
% 2| Identify a course
% 3| Identify a game
% 4| Identify an activity
% 5| Terminate program
% |: 4.

% Type an activity: {likes/play}
% |: plays.
% [(Elene,tennis),(Elene,voleyball),(Maria,chess),
%     (Maria,tennis),(Yannis,basketball),
%         (Yannis,chess),(Yannis,voleyball)]

% Main Menu | Type 1/2/3/4 or 5
% 1| Identify a name
% 2| Identify a course
% 3| Identify a game
% 4| Identify an activity
% 5| Terminate program
% |: 5.

% Program Terminated!
% true.