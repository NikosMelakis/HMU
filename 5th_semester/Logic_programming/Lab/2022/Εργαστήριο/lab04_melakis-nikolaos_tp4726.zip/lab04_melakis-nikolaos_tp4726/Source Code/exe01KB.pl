%Knownledge Base | used in exe01

kb('Yannis', likes, maths).
kb('Yannis', likes, physics). 
kb('Yannis', plays, voleyball).
kb('Yannis', plays, chess). 
kb('Yannis', plays, basketball). 
kb('Maria', likes, maths). 
kb('Maria', likes, geography). 
kb('Maria', plays, chess). 
kb('Maria', plays, tennis). 
kb('Elene', likes, physics). 
kb('Elene', likes, informatics). 
kb('Elene', plays, voleyball). 
kb('Elene', plays, tennis).