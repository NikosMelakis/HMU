%Nikolaos Melakis
%4 ergasthriakh ergasia | Askhsh 3

%Including the Knownledge Base 
:- include('exe03KB.pl').

%Main Menu
update_KB:-
    write('Main Menu Options'), nl,
    write('1| Change KB record.'), nl,
    write('2| Create a new record'), nl,
    write('3| Delete a existing record'), nl,
    write('4| Any other input saves actions and terminates the program'), nl,
    read(Option), nl,
    choice(Option).

%Actions depenting on user input
choice(1):-
    change_record_KB.
choice(2):-
    create_record_KB.
choice(3):-
    delete_record_KB.
choice(X):-
    save_KB,
    write('Changes successfully saved on exe03KB.pl'), nl, nl,
    write('Program Terminated!').

change_record_KB:-
    write('Type Id of the record you want to change'), nl,
    read(Id),nl,
    retract(student(Id,L)),		
    write('Type updated info like [FullName, Department, phoneNum, [Course1, Course2, ..]]'), nl,
    read(Info),
    assert(student(Id,Info)),
    write('Student added!'), nl, nl
    update_KB.

create_record_KB:-
    last(Y,N),
    retract(students(Y)),			
    Id is N+1,
    write('Type new info like [FullName, Department, phoneNum, [Course1, Course2, ..]]'), nl,
    read(Info),
    assertz(student(Id,Info)),
    append(Y,[T],Y1), 
    assertz(students(Y1)),
    write('New student added with Id:'), write(Id), nl, nl,
    update_KB.

delete_record_KB:-
    write('Type students Id you want to delete'), nl,
    read(Id),nl,
    retract(student(Id,L)),
    write('Student deleted!'), nl, nl,
    update_KB.

%Saving actions during runtime 
save_KB:-
    tell('/Users/nikos-melakis/Desktop/exe03KB.pl'),  %Path will not work for everyone. This is my path on macOS
    retractall(students),            
    retractall(student),
    listing(students),				
    listing(student),
    told.


%Transcirpt
% ?- update_KB.
% Main Menu Options
% 1| Change KB record.
% 2| Create a new record
% 3| Delete a existing record
% 4| Any other input saves actions and terminates the program
% |: 1.

% Type Id of the record you want to change
% |: 1.

% Type updated info like [FullName, Department, phoneNum, [Course1, Course2, ..]]
% |: [m_markakis,ie,2810379747,[ai,lp,sk]].
% Student added!

% Main Menu Options
% 1| Change KB record.
% 2| Create a new record
% 3| Delete a existing record
% 4| Any other input saves actions and terminates the program
% |: 2.

% Type new info like [FullName, Department, phoneNum, [Course1, Course2, ..]]
% |: [n_melakis,se,6973415131,[ai,lp,sk]].
% New student added with Id:5

% Main Menu Options
% 1| Change KB record.
% 2| Create a new record
% 3| Delete a existing record
% 4| Any other input saves actions and terminates the program
% |: 3.

% Type students Id you want to delete
% |: 4.

% Student retracted!
% Main Menu Options
% 1| Change KB record.
% 2| Create a new record
% 3| Delete a existing record
% 4| Any other input saves actions and terminates the program
% |: 6.

% Changes successfully saved on exe03KB.pl

% Program Terminated!
% true .