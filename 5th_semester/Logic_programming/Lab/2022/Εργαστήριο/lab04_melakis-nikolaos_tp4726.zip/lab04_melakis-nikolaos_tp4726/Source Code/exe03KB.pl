:- dynamic students/0.


:- dynamic students/1.

students([1, 2, 3, 4, _]).

:- dynamic student/0.


:- dynamic student/2.

student(2, [p_papadakis, ie, 2810379719, [ai, maths]]).
student(3, [s_petrou, ie, 2810379727, [ai, maths, progr]]).
student(1, [m_markakis, ie, 2810379747, [ai, lp, sk]]).
student(5, [n_melakis, se, 6973415131, [ai, lp, sk]]).

