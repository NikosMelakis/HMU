%Nikolaos Melakis
%4 ergasthriakh ergasia | Askhsh 2

save_KB:-
	see('/Users/nikos-melakis/Desktop/kb_old.pl'),  %Path will not work for everyone. This is my path on macOS
	tell('/Users/nikos-melakis/Desktop/kb.pl'),
	int_division,
	seen,
	told.

int_division:- 
	read(X),\+(X=end_of_file),   %reading the whole file
	write(X),
	write('.'),nl,
	int_division.

int_division.