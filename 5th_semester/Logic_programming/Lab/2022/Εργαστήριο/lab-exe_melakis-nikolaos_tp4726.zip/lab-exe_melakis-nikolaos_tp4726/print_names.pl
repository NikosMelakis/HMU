empty_stack([]).
top([H|T], H).
pop([H|T], T).
push(Q, X, [X|Q]).

print_names:-
    empty_stack(S),
    read_names(S).

read_names(S):-
    write('Type a name: {type telos to close}'), nl,
    read(Name),
    \+Name='telos',
    push(S, Name, S1),
    read_names(S1).

read_names(S):-
    write('Names in reversed order from inout!'), nl,
    print_names(S).

print_names(S):-
    \+empty_stack(S),
    top(S, Elem),
    write(Elem), nl,
    pop(S, S1),
    print_names(S1).

print_names(S):-
    nl,
    write('--Program Closed!--').


%Transcript | Code output with SWI-Prolog
% ?- print_names.
% Type a name: {type telos to close}
% |: nikos.
% Type a name: {type telos to close}
% |: giorgos.
% Type a name: {type telos to close}
% |: antonis.
% Type a name: {type telos to close}
% |: manolis.
% Type a name: {type telos to close}
% |: telos.
% Names in reversed order from inout!
% manolis
% antonis
% giorgos
% nikos

% --Program Closed!--
% true .