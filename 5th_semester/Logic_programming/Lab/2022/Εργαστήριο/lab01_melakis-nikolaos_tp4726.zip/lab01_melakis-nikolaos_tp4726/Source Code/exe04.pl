father(kostas,anna).
father(kostas,aris).
husband(kostas,soula).
male(kostas).
male(aris).
female(soula).
female(anna).


%if husband(X, Y) then wife(Y, X).
%if father(X, Y) then child(Y, X).
%if father(X, Y) and wife(Z, X) then mother(Z, Y).
%if mother(Y, X) then child(X, Y).
%if father(X, Y) and father(X, Z) and male(Y) and \+(Y==Z) then brother(Y, Z).
%if mother(X, Y) and mother(X, Z) and male(Y) and \+(Y==Z) then brother(Y, Z).
%if father(X, Y) and father(X, Z) and female(Y) and \+(Y==Z) then sister(Y, Z).
%if mother(X, Y) and mother(X, Z) and female(Y) and \+(Y==Z) then sister(Y, Z).

wife(Y, X):-
    husband(X, Y).
child(Y, X):-
    father(X, Y).
mother(Z, Y):-
    father(X, Y),
    wife(Z, X).
child(Y, X):-
    mother(X, Y).
brother(Y, Z):-
    \+(Y==Z),
    father(X, Y),
    father(X, Z),
    male(Y).
brother(Y, Z):-
    \+(Y==Z),
    mother(X, Y),
    mother(X, Z),
    male(Y).
sister(Y, Z):-
    \+(Y==Z),
    father(X, Y),
    father(X, Z),
    female(Y).
sister(Y, Z):-
    \+(Y==Z),
    father(X, Y),
    father(X, Z),
    female(Y).
