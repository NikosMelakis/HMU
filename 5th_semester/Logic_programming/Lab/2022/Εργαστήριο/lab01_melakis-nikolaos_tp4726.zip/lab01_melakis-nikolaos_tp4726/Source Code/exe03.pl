edge(a, b). edge(a, d).
edge(b, c). edge(b, e).
edge(c, d).
edge(d, e).


connected(A, A).
connected(A, B):-
    edge(A, B).
connected(A, B):-
    connected(A, C), edge(C, B).