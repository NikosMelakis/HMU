student(id(00005), name(nikos, melakis), address(somewhere, 10, 70000, heraklion), 
    studies(hmu, engineering, informatics_engineering, software_engineer)).

student(id(00004), name(giorgos, giorgakis), address(somewhere, 20, 70010, chania), 
    studies(tuc, architecture, architecture_engineering, extirior_desing)). 

student(id(00003), name(giannis, giannakis), address(somewhere, 30, 70020, athens), 
    studies(uoc, chemistry, chemistry, organic_chemistry)). 

student(id(00002), name(petros, petrakis), address(somewhere, 40, 70030, patras), 
    studies(uoa, engineering, electrical_engineering, electrician)). 

student(id(00001), name(pavlos, pavlakis), address(somewhere, 50, 70040, heraklion), 
    studies(mit, engineering, space_engineering, remote_engineer)). 