%Melakis Nikolaos tp4726
%Askhsh 2

empty_stack([]).           

parenthesis_LR_same(S):-           
    name(S, [H|T]),
    check(T, [H]).

check([], S):-        
    empty_stack(S).

check([H|T], [H|T1]):-    
    push([H|T1], H, R),  
    check(T, R).       

check([H|T], [H1|T1]):-    
    H \= H1,     
    pop([H1|T1], R),
    check(T, R).
    
push(Q,S, [S|Q]).            

pop([H|T], T).  

%Stoxoi
%parenthesis_LR_same('((()))').
%parenthesis_LR_same('((())').


% Transcript with SWI Prolog
% ?- parenthesis_LR_same('((()))').
% true .

% ?- parenthesis_LR_same('((())').
% false.