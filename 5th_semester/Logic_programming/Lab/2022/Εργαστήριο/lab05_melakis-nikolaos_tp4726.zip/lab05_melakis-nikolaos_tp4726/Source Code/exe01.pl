%Melakis Nikolaos tp4726
%Askhsh 1

%Prakseis Akolouthias
empty_seq([]).
head([H|T], H).
tail([H|T], T).
seq_cons(Q, X, [X|Q]).

%Prakseis Synilon
empty_set([]).
member_set(X, [H|T]):- 
    X = H.
member_set(X, [H|T]):- 
    X \= H, 
    member_set(X, T).

delete_elem_set(X, [X|T1], T1).
delete_elem_set(X, [H1|T1], [H1|T2]):- 
    delete_elem_set(X, T1, T2).

%Source Code
merge_sort(S1, S2) :- 
	empty_set(S1), 
    empty_seq(S2).
	
merge_sort(S1, S2) :-
	\+ empty_set(S1),
	member_set(Elem, S1),
	delete_elem_set(Elem, S1, RestS1),
	merge_sort(RestS1, RestS2), 
    merge_sort(Elem, RestS2, S2).
	
merge_sort(E,Q1, Q) :- 
	empty_seq(Q1),
	seq_cons(Q1, E, Q).
	
merge_sort(E, Q1, Q) :- 
	head(Q1, V1),
	E @=< V1, 
    seq_cons(Q1, E, Q).
	
merge_sort(E, Q1, Q) :- 
	head(Q1, V), E @> V, 
	tail(Q1, Q1a),
	merge_sort(E, Q1a, Qa),
	seq_cons(Qa, V, Q). 

%Stoxos
%merge_sort([-2, -4, 0, 3, 2, -6], S).

%Transcript with SWI Prolog
% ?- merge_sort([-2, -4, 0, 3, 2, -6], S).
% S = [-6, -4, -2, 0, 2, 3].