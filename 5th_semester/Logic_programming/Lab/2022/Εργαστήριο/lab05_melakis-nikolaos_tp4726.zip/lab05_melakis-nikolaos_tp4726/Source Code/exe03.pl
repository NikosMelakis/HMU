%Melakis Nikolaos tp4726
%Askhsh 3

empty_set([]).

queue_element_cardinality([], []).
queue_element_cardinality([H|T], L):- 
	makelist(H, H2), 
	queue_element_cardinality(T, L2), 
	append(H2, L2, L).
		
makelist(L, L2):- 
	divide(L, X, Y), 
	makelist2(X, Y, L2).
	
makelist2(_, N, []):- N =< 0 .

makelist2(X, Y, [X|Result]):- 
	Y > 0, 
	Y1 is Y-1, 
	makelist2(X, Y1, Result).
	
divide2(L, X, Y):- 
	length(X, 1),
	append(X, Y, L).

divide(L, X, Y):-
	divide2(L, [X|_], [Y|_]).

%Stoxos
%queue_element_cardinality([(5,4), (-8,3), (0,2)], Q2).

%Transcript with SWI Prolog
%?-queue_element_cardinality([(5,4), (-8,3), (0,2)], Q2).
%Q2 = [5,5,5,5,-8,-8,-8,0,0].