%Source Code\
teaches(ioannou,logic). 
teaches(ioannou,statistics). 
teaches(ioannou,algebra).
teaches(andreou,programming).
teaches(andreou,compilers).

print_teaches_courses(X):-
    teaches(X, Y),
    write('Professor: '), write(X), write('  '),
    write('Teaches: '), write(Y),
    nl, fail.

%Stoxos 
%| ?- print_teaches_courses(X).
%Professor: ioannou  Teaches: logic
%Professor: ioannou  Teaches: statistics
%Professor: ioannou  Teaches: algebra
%Professor: andreou  Teaches: programming
%Professor: andreou  Teaches: compilers
%no