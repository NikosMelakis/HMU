% Source Code
gonios(yannis, kostas).
gonios(yannis, eleni).
gonios(kostas, manos).
gonios(kostas, anna).
gonios(manos, nikos).

progonos(X, Y):-
    gonios(X, Y).

progonos(X, Y):-
    gonios(X, Z),
    progonos(Z, Y).


% Zhtoumenos stoxos
%| ?- progonos(yannis, nikos).
%yes

% Genikos Stoxos olwn twn dynatwn apotelesmatwn
%| ?- progonos(X, Y).
%X = yannis,
%Y = kostas ? ;
%X = yannis,
%Y = eleni ? ;
%X = kostas,
%Y = manos ? ;
%X = kostas,
%Y = anna ? ;
%X = manos,
%Y = nikos ? ;
%X = yannis,
%Y = manos ? ;
%X = yannis,
%Y = anna ? ;
%X = yannis,
%Y = nikos ? ;
%X = kostas,
%Y = nikos ? ;
%no


