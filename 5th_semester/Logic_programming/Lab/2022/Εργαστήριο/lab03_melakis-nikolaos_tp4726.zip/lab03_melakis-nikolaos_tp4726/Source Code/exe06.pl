%Source Code
likes(yannis,X):- course(X), teaches(yannis,X).
likes(anna,X):- teaches(yannis,X), \+ X = geometry. 
likes(anna, physics). 
teaches(yannis,algebra). 
teaches(yannis,geometry). 
teaches(yannis,logic). 
course(physics). 
course(chemistry). 
course(geometry). 
course(algebra). 
course(logic).

%Stoxoi
% trace
%| ?- likes(anna, X).
%        1      1 Call: likes(anna,_521) ? 
%        2      2 Call: teaches(yannis,_521) ? 
%?       2      2 Exit: teaches(yannis,algebra) ? 
%        3      2 Call: algebra=geometry ? 
%        3      2 Fail: algebra=geometry ? 
%?       1      1 Exit: likes(anna,algebra) ? 
%X = algebra ? ;
%        1      1 Redo: likes(anna,algebra) ? 
%        2      2 Redo: teaches(yannis,algebra) ? 
%?       2      2 Exit: teaches(yannis,geometry) ? 
%        4      2 Call: geometry=geometry ? 
%        4      2 Exit: geometry=geometry ? 
%        2      2 Redo: teaches(yannis,geometry) ? 
%        2      2 Exit: teaches(yannis,logic) ? 
%        5      2 Call: logic=geometry ? 
%        5      2 Fail: logic=geometry ? 
%?       1      1 Exit: likes(anna,logic) ? 
%X = logic ? ;
%        1      1 Redo: likes(anna,logic) ? 
%        1      1 Exit: likes(anna,physics) ? 
%X = physics ? ;
%no
%% trace
%| ?- likes(yannis, X).
%        1      1 Call: likes(yannis,_521) ? 
%        2      2 Call: course(_521) ? 
%?       2      2 Exit: course(physics) ? 
%        3      2 Call: teaches(yannis,physics) ? 
%        3      2 Fail: teaches(yannis,physics) ? 
%        2      2 Redo: course(physics) ? 
%?       2      2 Exit: course(chemistry) ? 
%        4      2 Call: teaches(yannis,chemistry) ? 
%        4      2 Fail: teaches(yannis,chemistry) ? 
%        2      2 Redo: course(chemistry) ? 
%?       2      2 Exit: course(geometry) ? 
%        5      2 Call: teaches(yannis,geometry) ? 
%?       5      2 Exit: teaches(yannis,geometry) ? 
%?       1      1 Exit: likes(yannis,geometry) ? 
%X = geometry ? ;
%        1      1 Redo: likes(yannis,geometry) ? 
%        5      2 Redo: teaches(yannis,geometry) ? 
%        5      2 Fail: teaches(yannis,geometry) ? 
%        2      2 Redo: course(geometry) ? 
%?       2      2 Exit: course(algebra) ? 
%        6      2 Call: teaches(yannis,algebra) ? 
%?       6      2 Exit: teaches(yannis,algebra) ? 
%?       1      1 Exit: likes(yannis,algebra) ? 
%X = algebra ? ;
%        1      1 Redo: likes(yannis,algebra) ? 
%        6      2 Redo: teaches(yannis,algebra) ? 
%        6      2 Fail: teaches(yannis,algebra) ? 
%        2      2 Redo: course(algebra) ? 
%        2      2 Exit: course(logic) ? 
%        7      2 Call: teaches(yannis,logic) ? 
%        7      2 Exit: teaches(yannis,logic) ? 
%        1      1 Exit: likes(yannis,logic) ? 
%X = logic ? ;
%no
%% trace
%| ?- likes(X, logic).
%        1      1 Call: likes(_509,logic) ? 
%        2      2 Call: course(logic) ? 
%        2      2 Exit: course(logic) ? 
%        3      2 Call: teaches(yannis,logic) ? 
%        3      2 Exit: teaches(yannis,logic) ? 
%?       1      1 Exit: likes(yannis,logic) ? 
%X = yannis ? ;
%        1      1 Redo: likes(yannis,logic) ? 
%        4      2 Call: teaches(yannis,logic) ? 
%        4      2 Exit: teaches(yannis,logic) ? 
%        5      2 Call: logic=geometry ? 
%        5      2 Fail: logic=geometry ? 
%?       1      1 Exit: likes(anna,logic) ? 
%X = anna ? ;
%        1      1 Redo: likes(anna,logic) ? 
%        1      1 Fail: likes(_509,logic) ? 
%no