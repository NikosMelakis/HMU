% Source Code
f(X):-
    X<0, !, write(0);
    X>=0, X=<1, !, write(X);
    X>1,!, write(1).

% Stoxos
%| ?- f(-2).
%0
%yes
%| ?- f(1/2).
%1/2
%yes
%| ?- f(3).  
%1
%yes