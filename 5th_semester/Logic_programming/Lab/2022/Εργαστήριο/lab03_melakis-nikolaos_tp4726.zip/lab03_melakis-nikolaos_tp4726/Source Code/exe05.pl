%Source Code
p(b).
p(X):- q(X,Y), r(Y).
q(c,b).
q(a,a).
r(b).
r(a).

%Stoxoi
%| ?- trace.
% The debugger will first creep -- showing everything (trace)
%yes
% trace
%| ?- p(a).
%        1      1 Call: p(a) ? 
%        2      2 Call: q(a,_1120) ? 
%        2      2 Exit: q(a,a) ? 
%        3      2 Call: r(a) ? 
%        3      2 Exit: r(a) ? 
%        1      1 Exit: p(a) ? 
%yes
% trace 
%| ?- p(b).
%        1      1 Call: p(b) ? 
%?       1      1 Exit: p(b) ? 
%yes
% trace
%| ?- p(c).
%        1      1 Call: p(c) ? 
%        2      2 Call: q(c,_1120) ? 
%        2      2 Exit: q(c,b) ? 
%        3      2 Call: r(b) ? 
%        3      2 Exit: r(b) ? 
%        1      1 Exit: p(c) ? 
%yes
% trace
%| ?- p(X).
%        1      1 Call: p(_509) ? 
%?       1      1 Exit: p(b) ? 
%X = b ? ;
%        1      1 Redo: p(b) ? 
%        2      2 Call: q(_509,_1143) ? 
%?       2      2 Exit: q(c,b) ? 
%        3      2 Call: r(b) ? 
%        3      2 Exit: r(b) ? 
%?       1      1 Exit: p(c) ? 
%X = c ? ;
%        1      1 Redo: p(c) ? 
%        2      2 Redo: q(c,b) ? 
%        2      2 Exit: q(a,a) ? 
%        4      2 Call: r(a) ? 
%        4      2 Exit: r(a) ? 
%        1      1 Exit: p(a) ? 
%X = a ? ;
%no