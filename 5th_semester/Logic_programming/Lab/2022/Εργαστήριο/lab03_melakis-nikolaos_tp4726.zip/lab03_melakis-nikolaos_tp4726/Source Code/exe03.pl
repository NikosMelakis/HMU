%Source Code
mkd(X, Y, Z):-
    X=:=Y, !, Z is X;
    X<Y, !, mkd(X, Y-X, Z);
    X>Y, !, mkd(X-Y, Y, Z).

%Stoxoi 
%| ?- mkd(2, 2, Z).
%Z = 2 ? 
%yes
%| ?- mkd(3, 5, Z).
%Z = 1 ? 
%yes
%| ?- mkd(8, 4, Z).
%Z = 4 ? 
%yes