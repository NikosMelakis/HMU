% Melakis Nikolaos TP4726
% Ergasia sth taxh

%Source Code
schoolEng(Dept, Course, Lecturer, Room).
schoolEng(hmmy, lp, kostas, g7).
schoolEng(hmmy, maths, kostas, g6).
schoolEng(hmmy, statistics, nikos, g6).
schoolEng(hmmy, sowEng, nikos, g7).
schoolEng(mechanical, maths, yannis, g7).
schoolEng(mechanical, statistics, yannis, g6).


% Ekfwnhsh
% Έστω η σχολή των μηχανικών έχει μια βάση δεδομένων, για τα μαθήματα ποy διδάσκονται, τους διδάσκοντες και τις αίθουσες που διδάσκοντε. 
% Να γρψετε στόχους σε PROLOG χρησιμοποιώντας την μέθοδο bagof/3, setof/3 οι οποιές να επιστρέφουν τα εξής.

% Erwthseis
% 1) Τα μαθήματα του ΗΜΜΥ, ποιοι είναι οι διδάσκοντες;                                          
% Answer: bagof((hmmy, Course, Lect), schoolEng(hmmy, Course, Lect, _), L). 

% 2) Το μάθημα των maths ποιος το διδάσκει στη σχολή των μηχανικών;                             
% Answer: bagof((Dept, maths, Lect), schoolEng(Dept, maths, Lect, _), L).

% 3) Ποία μαθήματα διδάσκοντε στην αίθουσα g6;                                                  
% Answer: bagof((Course, g6), schoolEng(Dept, Course, Lect, g6), L).

% 4) Ποία μαθήματα διδάσκει ο κώστας και σε ποία αίθουσα;                                       
% Answer: bagof((Course, kostas, Room), schoolEng(Dept, Course, kostas, Room), L).

% 5) Ποιά μαθήματα διδάσκοντε στην αίθουσα g7, σε πιά τμήματα ανήκουν και σε ποιά σχολή;        
% Answer: bagof((Dept, Course, g7), schoolEng(Dept, Course, Lect, g7), L).
