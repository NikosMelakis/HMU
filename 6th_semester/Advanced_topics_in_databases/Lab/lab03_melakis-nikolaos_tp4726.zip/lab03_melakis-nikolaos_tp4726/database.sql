Drop table IF EXISTS USERS cascade;
Drop table IF EXISTS DOCTORS cascade;
Drop table IF EXISTS PELATES cascade;
Drop table IF EXISTS YPALLHLOI cascade;
Drop table IF EXISTS RANTEVOU cascade;


CREATE TABLE USERS(
	AFM BIGINT NOT NULL,
 	ONOMA VARCHAR(60) NOT NULL,
 	EPONYMO VARCHAR(120) NOT NULL,
 	FYLO  VARCHAR(20) NOT NULL,
	BDAY DATE NOT NULL,
	DIEYTHHNSH VARCHAR(40) NOT NULL,
	EMAIL VARCHAR(40) NOT NULL,
	THLEFWNO VARCHAR(20) NOT NULL,
	PRIMARY KEY(AFM));
 
 
CREATE TABLE DOCTORS(
	DAFM BIGINT NOT NULL,
	IDIOTHTA VARCHAR(30) NOT NULL,
	PRIMARY KEY(DAFM),
	FOREIGN KEY (DAFM) REFERENCES USERS(AFM));


CREATE TABLE PELATES(
	PAFM BIGINT NOT NULL,
	ERGASIA VARCHAR(20) NOT NULL,
	PRIMARY KEY(PAFM),
	FOREIGN KEY (PAFM) REFERENCES USERS(AFM));
	
	
CREATE TABLE YPALLHLOI(
	YAFM BIGINT NOT NULL,
	XRON_PROSLHPSHS DATE NOT NULL,
	MISTHOS FLOAT NOT NULL,
	PRIMARY KEY(YAFM),
	FOREIGN KEY (YAFM) REFERENCES USERS(AFM));


CREATE TABLE RANTEVOU(
	RID BIGINT NOT NULL,
	RDATE TIMESTAMP NOT NULL,
	AFM_GIATROU BIGINT NOT NULL,
	AFM_PELATI BIGINT NOT NULL,
	PRIMARY KEY(RID),
	FOREIGN KEY (AFM_GIATROU) REFERENCES DOCTORS(DAFM),
	FOREIGN KEY (AFM_PELATI) REFERENCES PELATES(PAFM));
	
INSERT INTO USERS VALUES
 	('1010', 'Giannis', 'Giannakis', 'Male', '1999-01-10', 'Idomeneos 12', 'giannakis@giannis.com', '+306977113322'),
 	('1020', 'Maria', 'Maraki', 'Female', '1989-05-12', 'Leoforos 62 Mart 132', 'maraki@maria.com', '+306911332255'),
 	('1030', 'Giorgos', 'Giorgakis', 'Male', '1990-05-19', 'Chalepas 7', 'giorgakis@giorgos.com', '+306933220099'),
 	('1040', 'Andreas', 'Andreakis', 'Male', '1976-10-20', 'Kapodistria 44', 'andreakis@andreas.com', '+306922775511'),
 	('1050', 'Eleni', 'Elenaki', 'Female', '1988-12-18', 'Evimenidou 33', 'elenaki@eleni.com', '+306911993344'),
	('1060', 'Marios', 'Marakis', 'Male', '1990-02-11', 'Minwos 71', 'marakis@marios.com', '+306999121314'),
 	('1070', 'Giota', 'Gioataki', 'Female', '1992-10-30', 'Fragkakis 2', 'giotaki@giota.com', '+306988212223'),
 	('1080', 'Anna', 'Annaki', 'Female', '1978-12-08', 'Larisas 23', 'annaki@anna.com', '+306999113344'),
	('1090', 'Dimitris', 'Dimitrakis', 'Male', '1980-04-09', 'Koundourou 71', 'dimitrakis@dimitris.com', '+306922330099'),
 	('1100', 'Popi', 'Popaki', 'Female', '1966-10-20', 'Faliro 34', 'popaki@popi.com', '+306955227711'),
 	('1110', 'Nikos', 'Nikakis', 'Male', '1989-11-28', 'Akrothriou 123', 'nikakis@nikos.com', '+306999334400'),
	('1120', 'Vaso', 'Vasaki', 'Female', '1996-05-29', 'Miliaraki 12', 'vasaki@vaso.com', '+306912443987'),
 	('1130', 'Sofia', 'Sofaki', 'Female', '1979-12-20', 'Poluteniou 41', 'sofaki@sofia.com', '+306998765433'),
 	('1140', 'Antonis', 'Antonakis', 'Male', '1968-12-28', 'Marinas 96', 'antonakis@antonis.com', '+306933093344');
	
INSERT INTO DOCTORS VALUES
	('1010', 'Pathologos'),
	('1020', 'Xeirourgos'),
	('1030', 'Kardiologos'),
	('1040', 'Orthopedikos');


INSERT INTO PELATES VALUES
	('1050', 'Episthmonas'),
	('1060', 'Dhmosios Ypallhlos'),
	('1070', 'Idiotikos Ypallhlos'),
	('1080', 'Anergos');


INSERT INTO YPALLHLOI VALUES
	('1090', '2012-10-12', '990'),
	('1100', '2014-03-21', '875'),
	('1110', '2011-11-13', '1050'),
	('1120', '2020-05-04', '990');


INSERT INTO RANTEVOU VALUES
	('0001', '2022-03-28 09:00:00', '1010', '1080'),
	('0002', '2022-04-01 09:30:00', '1020', '1070'),
	('0003', '2022-05-12 11:00:00', '1030', '1060'),
	('0004', '2022-05-12 10:15:00', '1040', '1050');





 