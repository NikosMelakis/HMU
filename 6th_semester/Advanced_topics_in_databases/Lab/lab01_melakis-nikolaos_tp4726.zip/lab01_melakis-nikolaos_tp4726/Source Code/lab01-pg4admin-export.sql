--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

-- Started on 2022-03-15 21:46:16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 16384)
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- TOC entry 3348 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 16498)
-- Name: coments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coments (
    syg_mhnymatos character varying(30) NOT NULL,
    kod_mhnymatos integer NOT NULL,
    kod_sxoliou integer NOT NULL,
    suggrafeas_sxoliou character varying(30) NOT NULL,
    keimeno_sxoliou character varying(4000) NOT NULL,
    hmeromhnia date NOT NULL,
    CONSTRAINT coments_kod_mhnymatos_check CHECK ((kod_mhnymatos > 0)),
    CONSTRAINT coments_kod_sxoliou_check CHECK ((kod_sxoliou > 0))
);


ALTER TABLE public.coments OWNER TO postgres;

--
-- TOC entry 213 (class 1259 OID 16497)
-- Name: coments_kod_sxoliou_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coments_kod_sxoliou_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coments_kod_sxoliou_seq OWNER TO postgres;

--
-- TOC entry 3349 (class 0 OID 0)
-- Dependencies: 213
-- Name: coments_kod_sxoliou_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coments_kod_sxoliou_seq OWNED BY public.coments.kod_sxoliou;


--
-- TOC entry 215 (class 1259 OID 16518)
-- Name: likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.likes (
    onomaxeiristh character varying(30) NOT NULL,
    syg_mhnymatos character varying(30) NOT NULL,
    kod_mhnymatos integer NOT NULL,
    CONSTRAINT likes_kod_mhnymatos_check CHECK ((kod_mhnymatos > 0))
);


ALTER TABLE public.likes OWNER TO postgres;

--
-- TOC entry 212 (class 1259 OID 16478)
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    syg_mhnymatos character varying(30) NOT NULL,
    kod_mhnymatos integer NOT NULL,
    idiokthths_toixoy character varying(30) NOT NULL,
    periexomeno character varying(4000) NOT NULL,
    hmeromhnia date NOT NULL,
    CONSTRAINT messages_kod_mhnymatos_check CHECK ((kod_mhnymatos > 0))
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- TOC entry 211 (class 1259 OID 16477)
-- Name: messages_kod_mhnymatos_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_kod_mhnymatos_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_kod_mhnymatos_seq OWNER TO postgres;

--
-- TOC entry 3350 (class 0 OID 0)
-- Dependencies: 211
-- Name: messages_kod_mhnymatos_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_kod_mhnymatos_seq OWNED BY public.messages.kod_mhnymatos;


--
-- TOC entry 210 (class 1259 OID 16472)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    onomaxeiristh character varying(30) NOT NULL,
    onoma character varying(60) NOT NULL,
    eponymo character varying(120),
    genos character varying(20) NOT NULL,
    polh character varying(60),
    xora character varying(60) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 3180 (class 2604 OID 16501)
-- Name: coments kod_sxoliou; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coments ALTER COLUMN kod_sxoliou SET DEFAULT nextval('public.coments_kod_sxoliou_seq'::regclass);


--
-- TOC entry 3178 (class 2604 OID 16481)
-- Name: messages kod_mhnymatos; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN kod_mhnymatos SET DEFAULT nextval('public.messages_kod_mhnymatos_seq'::regclass);


--
-- TOC entry 3341 (class 0 OID 16498)
-- Dependencies: 214
-- Data for Name: coments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coments (syg_mhnymatos, kod_mhnymatos, kod_sxoliou, suggrafeas_sxoliou, keimeno_sxoliou, hmeromhnia) FROM stdin;
user03	1	1	user01	Kalo	2022-03-11
user01	3	2	user03	Euxaristo	2022-03-11
user04	4	3	user05	Kalhspera se olous	2022-02-27
user02	5	4	user04	Kalhspera	2022-02-27
user05	2	5	user04	Geia sas	2022-02-27
\.


--
-- TOC entry 3342 (class 0 OID 16518)
-- Dependencies: 215
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.likes (onomaxeiristh, syg_mhnymatos, kod_mhnymatos) FROM stdin;
user03	user01	3
user02	user01	3
user05	user02	5
user04	user02	5
user03	user02	5
\.


--
-- TOC entry 3339 (class 0 OID 16478)
-- Dependencies: 212
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (syg_mhnymatos, kod_mhnymatos, idiokthths_toixoy, periexomeno, hmeromhnia) FROM stdin;
user03	1	user05	Kalhspera	2022-03-14
user05	2	user05	Akougomai kala?	2022-03-14
user01	3	user05	Nai mia xara	2022-03-14
user04	4	user02	Kamia aporia?	2022-02-17
user02	5	user02	Ola entaxei, euxaristo	2022-02-27
\.


--
-- TOC entry 3337 (class 0 OID 16472)
-- Dependencies: 210
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (onomaxeiristh, onoma, eponymo, genos, polh, xora) FROM stdin;
user01	nikos	nikakis	male	Hrakleio	Greece
user02	giannis	giannakis	male	Athens	Greece
user03	maria	maraki	female	Thesaloniki	Greece
user04	paulos	paulakis	male	Patras	Greece
user05	popi	popaki	female	Chania	Greece
\.


--
-- TOC entry 3351 (class 0 OID 0)
-- Dependencies: 213
-- Name: coments_kod_sxoliou_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coments_kod_sxoliou_seq', 5, true);


--
-- TOC entry 3352 (class 0 OID 0)
-- Dependencies: 211
-- Name: messages_kod_mhnymatos_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_kod_mhnymatos_seq', 5, true);


--
-- TOC entry 3189 (class 2606 OID 16507)
-- Name: coments coments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coments
    ADD CONSTRAINT coments_pkey PRIMARY KEY (kod_sxoliou);


--
-- TOC entry 3187 (class 2606 OID 16486)
-- Name: messages syg_kod_mhnymatos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT syg_kod_mhnymatos PRIMARY KEY (syg_mhnymatos, kod_mhnymatos);


--
-- TOC entry 3191 (class 2606 OID 16523)
-- Name: likes syg_kod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT syg_kod_pkey PRIMARY KEY (onomaxeiristh, syg_mhnymatos, kod_mhnymatos);


--
-- TOC entry 3185 (class 2606 OID 16476)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (onomaxeiristh);


--
-- TOC entry 3195 (class 2606 OID 16513)
-- Name: coments coments_suggrafeas_sxoliou_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coments
    ADD CONSTRAINT coments_suggrafeas_sxoliou_fkey FOREIGN KEY (suggrafeas_sxoliou) REFERENCES public.users(onomaxeiristh);


--
-- TOC entry 3196 (class 2606 OID 16524)
-- Name: likes likes_onomaxeiristh_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_onomaxeiristh_fkey FOREIGN KEY (onomaxeiristh) REFERENCES public.users(onomaxeiristh);


--
-- TOC entry 3193 (class 2606 OID 16492)
-- Name: messages messages_idiokthths_toixoy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_idiokthths_toixoy_fkey FOREIGN KEY (idiokthths_toixoy) REFERENCES public.users(onomaxeiristh);


--
-- TOC entry 3192 (class 2606 OID 16487)
-- Name: messages messages_syg_mhnymatos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_syg_mhnymatos_fkey FOREIGN KEY (syg_mhnymatos) REFERENCES public.users(onomaxeiristh);


--
-- TOC entry 3194 (class 2606 OID 16508)
-- Name: coments syg_kod; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coments
    ADD CONSTRAINT syg_kod FOREIGN KEY (syg_mhnymatos, kod_mhnymatos) REFERENCES public.messages(syg_mhnymatos, kod_mhnymatos);


--
-- TOC entry 3197 (class 2606 OID 16529)
-- Name: likes syg_kod_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT syg_kod_fkey FOREIGN KEY (syg_mhnymatos, kod_mhnymatos) REFERENCES public.messages(syg_mhnymatos, kod_mhnymatos);


-- Completed on 2022-03-15 21:46:16

--
-- PostgreSQL database dump complete
--

