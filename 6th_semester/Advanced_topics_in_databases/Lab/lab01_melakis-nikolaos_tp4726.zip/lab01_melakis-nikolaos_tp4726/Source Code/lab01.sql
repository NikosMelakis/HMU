
Drop table IF EXISTS USERS cascade;

Drop table IF EXISTS MESSAGES cascade;

Drop table IF EXISTS COMENTS cascade;

Drop tabLE IF EXISTS LIKES cascade;

CREATE TABLE USERS (
    ONOMAXEIRISTH VARCHAR(30) NOT NULL,
    ONOMA VARCHAR(60) NOT NULL,
    EPONYMO VARCHAR(120),
    GENOS VARCHAR(20) NOT NULL,
    POLH VARCHAR(60),
    XORA VARCHAR(60) NOT NULL,
    PRIMARY KEY (ONOMAXEIRISTH)
);

CREATE TABLE MESSAGES (
    SYG_MHNYMATOS VARCHAR(30) NOT NULL,
    KOD_MHNYMATOS SERIAL,
    IDIOKTHTHS_TOIXOY VARCHAR(30) NOT NULL,
    PERIEXOMENO VARCHAR(4000) NOT NULL,
    HMEROMHNIA DATE NOT NULL,
    CHECK (KOD_MHNYMATOS > 0),
    FOREIGN KEY (SYG_MHNYMATOS) REFERENCES USERS(ONOMAXEIRISTH),
    FOREIGN KEY (IDIOKTHTHS_TOIXOY) REFERENCES USERS(ONOMAXEIRISTH),
    CONSTRAINT syg_kod_mhnymatos PRIMARY KEY (syg_mhnymatos, kod_mhnymatos)
);


CREATE TABLE COMENTS (
    SYG_MHNYMATOS VARCHAR(30) NOT NULL,
    KOD_MHNYMATOS INT NOT NULL,
    KOD_SXOLIOU SERIAL,
    SUGGRAFEAS_SXOLIOU VARCHAR(30) NOT NULL,
    KEIMENO_SXOLIOU VARCHAR(4000) NOT NULL,
    HMEROMHNIA DATE NOT NULL,
    CHECK (KOD_MHNYMATOS > 0),
    CHECK (KOD_SXOLIOU > 0),
    CONSTRAINT SYG_KOD FOREIGN KEY (SYG_MHNYMATOS, KOD_MHNYMATOS) REFERENCES MESSAGES (SYG_MHNYMATOS, KOD_MHNYMATOS),
    FOREIGN KEY (SUGGRAFEAS_SXOLIOU) REFERENCES USERS(ONOMAXEIRISTH),
    PRIMARY KEY (KOD_SXOLIOU)
);

CREATE TABLE LIKES (
    ONOMAXEIRISTH VARCHAR(30) NOT NULL,
    SYG_MHNYMATOS VARCHAR(30) NOT NULL,
    KOD_MHNYMATOS INT NOT NULL,
    CHECK (KOD_MHNYMATOS > 0),
    CONSTRAINT SYG_KOD_PKEY PRIMARY KEY (ONOMAXEIRISTH, SYG_MHNYMATOS, KOD_MHNYMATOS),
    FOREIGN KEY (ONOMAXEIRISTH) REFERENCES users(ONOMAXEIRISTH),
    CONSTRAINT SYG_KOD_FKEY FOREIGN KEY (SYG_MHNYMATOS, KOD_MHNYMATOS) REFERENCES messages (SYG_MHNYMATOS, KOD_MHNYMATOS)
);


INSERT INTO COMENTS(syg_mhnymatos, kod_mhnymatos, suggrafeas_sxoliou, keimeno_sxoliou, hmeromhnia)
VALUES
    ('user03', 1, 'user01', 'Kalo', '2022-03-11' ),
    ('user01', 3, 'user03', 'Euxaristo', '2022-03-11'),
    ('user04', 4, 'user05', 'Kalhspera se olous', '2022-02-27'),
    ('user02', 5, 'user04', 'Kalhspera', '2022-02-27'),
    ('user05', 2, 'user04', 'Geia sas', '2022-02-27');

INSERT INTO LIKES (onomaxeiristh, syg_mhnymatos,  kod_mhnymatos)
VALUES
    ('user03', 'user01', 3),
    ('user02', 'user01', 3),
    ('user05', 'user02', 5),
    ('user04', 'user02', 5),
    ('user03', 'user02', 5);

INSERT INTO MESSAGES (syg_mhnymatos, idiokthths_toixoy, periexomeno, hmeromhnia)
VALUES
    ('user03', 'user05', 'Kalhspera', '2022-03-14'),
    ('user05', 'user05', 'Akougomai kala?', '2022-03-14'),
    ('user01', 'user05', 'Nai mia xara', '2022-03-14'),
    ('user04', 'user02', 'Kamia aporia?', '2022-02-17'),
    ('user02', 'user02', 'Ola entaxei, euxaristo', '2022-2-27');

INSERT INTO USERS(onomaxeiristh, onoma, eponymo, genos, polh, xora)
VALUES
    ('user01', 'nikos', 'nikakis', 'male', 'Hrakleio', 'Greece'),
    ('user02', 'giannis', 'giannakis', 'male', 'Athens', 'Greece'),
    ('user03', 'maria', 'maraki', 'female', 'Thesaloniki', 'Greece'),
    ('user04', 'paulos', 'paulakis', 'male', 'Patras', 'Greece'),
    ('user05', 'popi', 'popaki', 'female', 'Chania', 'Greece');
	
