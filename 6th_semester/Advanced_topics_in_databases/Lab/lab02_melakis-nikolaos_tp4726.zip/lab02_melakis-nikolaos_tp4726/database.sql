Drop table IF EXISTS USERS cascade;
Drop table IF EXISTS MESSAGES cascade;
Drop table IF EXISTS COMENTS cascade;
Drop tabLe IF EXISTS LIKES cascade;
Drop table IF EXISTS TEAM cascade;
Drop table IF EXISTS MEMBERS cascade;
Drop table IF EXISTS MANAGES cascade;
Drop table IF EXISTS FOLLOWS cascade;

/* Δημιουργία Πίνακα {ΧΡΗΣΤΗΣ} */
CREATE TABLE USERS
(ONOMAXEIRISTH VARCHAR(30) NOT NULL,
ONOMA VARCHAR(60) NOT NULL,
EPONYMO VARCHAR(120),
GENOS VARCHAR(20) NOT NULL,
POLH VARCHAR(60),
XORA VARCHAR(60) NOT NULL,
PRIMARY KEY(ONOMAXEIRISTH));

/* Δημιουργία Πίνακα {ΜΗΝΥΜΑ} */
CREATE TABLE MESSAGES    
(SYG_MHNYMATOS VARCHAR(30) NOT NULL,
KOD_MHNYMATOS INT NOT NULL, 
IDIOKTHTHS_TOIXOY VARCHAR(30) NOT NULL,
PERIEXOMENO VARCHAR(4000) NOT NULL,
HMEROMHNIA DATE NOT NULL,
CHECK (KOD_MHNYMATOS > 0 ),
PRIMARY KEY(KOD_MHNYMATOS,SYG_MHNYMATOS),
FOREIGN KEY (SYG_MHNYMATOS) REFERENCES USERS(ONOMAXEIRISTH),
FOREIGN KEY (IDIOKTHTHS_TOIXOY) REFERENCES USERS(ONOMAXEIRISTH));

/* Δημιουργία Πίνακα {ΣΧΟΛΙΟ} */
CREATE TABLE COMENTS
(SYG_MHNYMATOS VARCHAR(30) NOT NULL,
KOD_MHNYMATOS INT NOT NULL,
KOD_SXOLIOU INT NOT NULL,
SUGGRAFEAS_SXOLIOU VARCHAR(30) NOT NULL,
KEIMENO_SXOLIOU VARCHAR(4000) NOT NULL,
HMEROMHNIA DATE NOT NULL,
CHECK (KOD_MHNYMATOS > 0 ),
CHECK (KOD_SXOLIOU > 0 ),
PRIMARY KEY (KOD_SXOLIOU, SYG_MHNYMATOS,KOD_MHNYMATOS,SUGGRAFEAS_SXOLIOU ),
FOREIGN KEY (SUGGRAFEAS_SXOLIOU) REFERENCES USERS(ONOMAXEIRISTH),
FOREIGN KEY (KOD_MHNYMATOS,SYG_MHNYMATOS) REFERENCES MESSAGES(KOD_MHNYMATOS,SYG_MHNYMATOS)
);

/* Δημιουργία Πίνακα {ΑΡΕΣΕΙ} */
CREATE TABLE LIKES
(ONOMAXEIRISTH VARCHAR(30) NOT NULL,
SYG_MHNYMATOS VARCHAR(30) NOT NULL,
KOD_MHNYMATOS INT NOT NULL,
CHECK (KOD_MHNYMATOS > 0 ),
PRIMARY KEY(ONOMAXEIRISTH,KOD_MHNYMATOS,SYG_MHNYMATOS),
FOREIGN KEY (ONOMAXEIRISTH) REFERENCES USERS(ONOMAXEIRISTH),
FOREIGN KEY (KOD_MHNYMATOS,SYG_MHNYMATOS) REFERENCES MESSAGES(KOD_MHNYMATOS,SYG_MHNYMATOS)
);

/* Δημιουργία Πίνακα {ΟΜΑΔΑ} */
CREATE TABLE TEAM(
ONOMA_OMADAS VARCHAR(30) NOT NULL,
PRIMARY KEY(ONOMA_OMADAS)
);

/* Δημιουργία Πίνακα {ΜΕΛΟΣ} */
CREATE TABLE MEMBERS(
ONOMA_OMADAS VARCHAR(30) NOT NULL,
ONOMAXEIRISTH VARCHAR(30) NOT NULL,
PRIMARY KEY(ONOMA_OMADAS,ONOMAXEIRISTH),
FOREIGN KEY(ONOMA_OMADAS) REFERENCES TEAM(ONOMA_OMADAS),
FOREIGN KEY(ONOMAXEIRISTH) REFERENCES USERS(ONOMAXEIRISTH)
);

/* Δημιουργία Πίνακα {ΔΙΑΧΕΙΡΙΖΕΤΑΙ} */
CREATE TABLE MANAGES(
ONOMA_OMADAS VARCHAR(30) NOT NULL,
ONOMADIAXEIRISTH VARCHAR(30) NOT NULL,
PRIMARY KEY(ONOMA_OMADAS,ONOMADIAXEIRISTH),
FOREIGN KEY(ONOMA_OMADAS) REFERENCES TEAM(ONOMA_OMADAS),
FOREIGN KEY(ONOMADIAXEIRISTH) REFERENCES USERS(ONOMAXEIRISTH)
);

/* Δημιουργία Πίνακα {ΑΚΟΛΟΥΘΕΙ} */
CREATE TABLE FOLLOWS(
HMEROMHNIA_DESMOY DATE NOT NULL,
ONOMA_AKOLOYTHOY VARCHAR(30) NOT NULL,
ONOMAXEIRISTH VARCHAR(30) NOT NULL,
PRIMARY KEY (ONOMA_AKOLOYTHOY,ONOMAXEIRISTH),
FOREIGN KEY(ONOMAXEIRISTH) REFERENCES USERS(ONOMAXEIRISTH),
FOREIGN KEY(ONOMA_AKOLOYTHOY) REFERENCES USERS(ONOMAXEIRISTH)
);


insert into USERS values ('BraveHeart','sakis','karpas','aren','aridea','ellada'),
('user1','alekos','karpas','aren','aridea','ellada'),
('johnny','giannis','gerolymos','aren','hrakleio','ellada');


insert into MESSAGES values ('BraveHeart','1234','BraveHeart','Kalhspera unboxholakia','2-11-2014'),
 ('user1','4512','BraveHeart','Thn kalhspera mou!','2-11-2023');


insert into COMENTS values ('BraveHeart','1234','1','johnny','Kalhspera ,pame oloi like stous uh','2-10-2011'),
('BraveHeart','1234','2','user1','Kalhspera ,spaste to chat','2-10-2011');


insert into LIKES values ('johnny','BraveHeart','1234');

insert into TEAM values ('Unboxholics'),('Movie Time');

insert into MEMBERS values ('Unboxholics','BraveHeart'),('Unboxholics','johnny'), ('Movie Time','user1'), ('Movie Time','johnny')  ;

insert into MANAGES values ('Unboxholics','BraveHeart'), ('Movie Time','user1');

insert into FOLLOWS values ('1-01-2012','user1','BraveHeart'),('1-02-2012','johnny','BraveHeart');



-- QUERIES GIA ASKHSH 2

-- 1)
SELECT * FROM USERS 
WHERE POLH='hrakleio' AND XORA='ellada';

-- 2)
SELECT *  FROM USERS, COMENTS 
WHERE XORA='ellada' AND POLH='hrakleio';

-- 3)
SELECT *  FROM USERS, COMENTS 
WHERE XORA!='ellada';

-- 4)
SELECT syg_mhnymatos, periexomeno, hmeromhnia  FROM MESSAGES
WHERE hmeromhnia in (SELECT MAX(hmeromhnia) from MESSAGES);

-- 5)
SELECT onoma_omadas, onomadiaxeiristh  FROM MANAGES;

-- 6)
SELECT onoma, eponymo, onomaxeiristh  FROM USERS, MANAGES
WHERE onomadiaxeiristh=onomaxeiristh;

-- 7)
SELECT syg_mhnymatos, kod_mhnymatos, periexomeno FROM MESSAGES
WHERE kod_mhnymatos in (SELECT MAX(kod_mhnymatos) from LIKES);

-- 8)
SELECT syg_mhnymatos, periexomeno, hmeromhnia  FROM MESSAGES
UNION  
SELECT suggrafeas_sxoliou, keimeno_sxoliou, hmeromhnia FROM COMENTS
ORDER BY hmeromhnia ASC;

-- 9)
SELECT suggrafeas_sxoliou, hmeromhnia FROM COMENTS
WHERE syg_mhnymatos in (SELECT ('BraveHeart') from MESSAGES);

-- 10)
SELECT * FROM USERS 
WHERE onomaxeiristh IN(SELECT onomaxeiristh FROM FOLLOWS);

-- 11)
SELECT MESSAGES.syg_mhnymatos, MESSAGES.kod_mhnymatos, COUNT(COMENTS.kod_sxoliou) AS PLITHOS_SXOLIWN FROM MESSAGES, COMENTS 
WHERE MESSAGES.kod_mhnymatos=COMENTS.kod_mhnymatos 
GROUP BY MESSAGES.syg_mhnymatos,MESSAGES.kod_mhnymatos;

-- 12)
SELECT USERS.onomaxeiristh, USERS.onoma, USERS.eponymo,  COUNT(FOLLOWS.hmeromhnia_desmoy) AS PLITHOS_AKOLOUTHWN FROM USERS, FOLLOWS 
WHERE USERS.onomaxeiristh=FOLLOWS.onomaxeiristh
GROUP BY USERS.onomaxeiristh,  USERS.onoma, USERS.eponymo
ORDER BY COUNT(FOLLOWS.hmeromhnia_desmoy) DESC 
limit 1;

