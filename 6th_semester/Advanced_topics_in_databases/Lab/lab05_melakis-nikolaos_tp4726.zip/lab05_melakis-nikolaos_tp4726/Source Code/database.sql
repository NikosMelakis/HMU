Drop table IF EXISTS USERS cascade;
Drop table IF EXISTS DOCTORS cascade;
Drop table IF EXISTS PELATES cascade;
Drop table IF EXISTS YPALLHLOI cascade;
Drop table IF EXISTS RANTEVOU cascade;
Drop table IF EXISTS THLEFWNA cascade;
Drop type if EXISTS GENDER cascade;
Drop type if EXISTS ADDRESS cascade;
Drop type if EXISTS EIDIKOTHTA cascade;


CREATE TYPE GENDER AS ENUM(
	'Male', 
	'Female');


CREATE TYPE ADDRESS AS(
	PERIFERIA VARCHAR(20),
	POLH VARCHAR(20),
	DIEYTHHNSH VARCHAR(20));


CREATE TYPE EIDIKOTHTA AS ENUM(
	'Pathologist', 
	'Urologist',
	'Microbiologist,',
	'Dermatologist',
	'Surgeon');


CREATE TABLE USERS(
	AFM BIGINT NOT NULL,
 	ONOMA VARCHAR(60) NOT NULL,
 	EPONYMO VARCHAR(120) NOT NULL,
 	FYLO  GENDER NOT NULL,
	BDAY DATE NOT NULL,
	DIEYTHHNSH ADDRESS NOT NULL,
	EMAIL VARCHAR(40) NOT NULL,
	PRIMARY KEY(AFM));


CREATE TABLE THLEFWNA(
	PHONESID SERIAL PRIMARY KEY,
	PHONES VARCHAR(20) NOT NULL,
	PHONESAFM BIGINT NOT NULL REFERENCES USERS(AFM));

CREATE TABLE DOCTORS(
	DAFM BIGINT NOT NULL,
	IDIOTHTA EIDIKOTHTA NOT NULL,
	PRIMARY KEY(DAFM),
	FOREIGN KEY (DAFM) REFERENCES USERS(AFM));


CREATE TABLE PELATES(
	PAFM BIGINT NOT NULL,
	ERGASIA VARCHAR(20) NOT NULL,
	PRIMARY KEY(PAFM),
	FOREIGN KEY (PAFM) REFERENCES USERS(AFM));
	
	
CREATE TABLE YPALLHLOI(
	YAFM BIGINT NOT NULL,
	XRON_PROSLHPSHS DATE NOT NULL,
	MISTHOS FLOAT NOT NULL,
	PRIMARY KEY(YAFM),
	FOREIGN KEY (YAFM) REFERENCES USERS(AFM));


CREATE TABLE RANTEVOU(
	RID BIGINT NOT NULL,
	RDATE TIMESTAMP NOT NULL,
	AFM_GIATROU BIGINT NOT NULL,
	AFM_PELATI BIGINT NOT NULL,
	AFM_YPALLHLOI BIGINT NOT NULL,
	PRIMARY KEY(RID),
	FOREIGN KEY (AFM_GIATROU) REFERENCES DOCTORS(DAFM),
	FOREIGN KEY (AFM_PELATI) REFERENCES PELATES(PAFM),
	FOREIGN KEY (AFM_YPALLHLOI) REFERENCES YPALLHLOI(YAFM));
	
INSERT INTO USERS VALUES
 	('1010', 'Giannis', 'Giannakis', 'Male', '1999-01-10', ('Krhths','Hrakleio','Idomeneos 12'), 'giannakis@giannis.com'),
 	('1020', 'Maria', 'Maraki', 'Female', '1989-05-12', ('Krhths','Hrakleio','Leoforos 62 Mart 132'), 'maraki@maria.com'),
 	('1030', 'Giorgos', 'Giorgakis', 'Male', '1990-05-19', ('Krhths','Chania','Chalepas 7'), 'giorgakis@giorgos.com'),
 	('1040', 'Andreas', 'Andreakis', 'Male', '1976-10-20', ('Attikhs','Athhna','Kapodistria 44'), 'andreakis@andreas.com'),
 	('1050', 'Eleni', 'Elenaki', 'Female', '1988-12-18', ('Krhths','Hrakleio','Evimenidou 33'), 'elenaki@eleni.com'),
	('1060', 'Marios', 'Marakis', 'Male', '1990-02-11', ('Krhths','Hrakleio','Minwos 71'), 'marakis@marios.com'),
 	('1070', 'Giota', 'Giotaki', 'Female', '1992-10-30', ('Krhths','Hrakleio','Fragkakis 2'), 'giotaki@giota.com'),
 	('1080', 'Anna', 'Annaki', 'Female', '1978-12-08', ('Peloponnisos','Kalamatas','Larisas 23'), 'annaki@anna.com'),
	('1090', 'Dimitris', 'Dimitrakis', 'Male', '1980-04-09', ('Thessalonikis','Chalkida','Koundourou 71'), 'dimitrakis@dimitris.com'),
 	('1100', 'Popi', 'Popaki', 'Female', '1966-10-20', ('Attikhs','Athhna','Faliro 34'), 'popaki@popi.com'),
 	('1110', 'Nikos', 'Nikakis', 'Male', '1989-11-28', ('Peloponnisos','Tripolh','Akrothriou 123'), 'nikakis@nikos.com'),
	('1120', 'Vaso', 'Vasaki', 'Female', '1996-05-29', ('Krhths','Shteia','Miliaraki 12'), 'vasaki@vaso.com'),
 	('1130', 'Sofia', 'Sofaki', 'Female', '1979-12-20', ('Krhths','Ierapetra','Poluteniou 41'), 'sofaki@sofia.com'),
 	('1140', 'Antonis', 'Antonakis', 'Male', '1968-12-28', ('Krhths','Chania','Marinas 96'), 'antonakis@antonis.com');


INSERT INTO THLEFWNA (PHONES, PHONESAFM) VALUES
 	('+306977113322', '1010'),
  	('+306911332255', '1020'),
	('+306933220099', '1030'),
  	('+306922775511', '1040'),
 	('+306911993344', '1050'),
 	('+306999121314', '1060'),
  	('+306988212223', '1070'),
  	('+306999113344', '1080'),
 	('+306922330099', '1090'),
  	('+306955227711', '1100'),
  	('+306999334400', '1110'),
 	('+306912443987', '1120'),
  	('+306998765433', '1130'),
  	('+306933093344', '1140');
	
	
INSERT INTO DOCTORS VALUES
	('1010', 'Pathologist'),
	('1020', 'Surgeon'),
	('1030', 'Urologist'),
	('1040', 'Dermatologist');


INSERT INTO PELATES VALUES
	('1050', 'Episthmonas'),
	('1060', 'Dhmosios Ypallhlos'),
	('1070', 'Idiotikos Ypallhlos'),
	('1080', 'Anergos');


INSERT INTO YPALLHLOI VALUES
	('1090', '2012-10-12', '990'),
	('1100', '2014-03-21', '875'),
	('1110', '2011-11-13', '1050'),
	('1120', '2020-05-04', '990');


INSERT INTO RANTEVOU VALUES
	('0001', '2022-03-28 09:00:00', '1010', '1080', '1090'),
	('0002', '2022-04-01 09:30:00', '1020', '1070', '1100'),
	('0003', '2022-05-12 11:00:00', '1030', '1050', '1110'),
	('0004', '2022-05-12 10:15:00', '1040', '1060', '1120'),
	('0005', '2022-05-14 10:30:00', '1030', '1080', '1090'),
	('0006', '2022-05-16 10:30:00', '1030', '1080', '1090'),
	('0007', '2022-05-17 10:30:00', '1030', '1060', '1120'),
	('0008', '2022-05-17 10:30:00', '1010', '1070', '1120'),
	('0009', '2022-05-22 09:30:00', '1020', '1050', '1100');

-- 1)
SELECT FYLO, COUNT(*) FROM USERS
GROUP BY FYLO;

-- 2)
SELECT ONOMA, EPONYMO FROM USERS, PELATES
WHERE(DIEYTHHNSH).PERIFERIA='Krhths' AND PAFM=AFM;

-- 3)
SELECT DAFM, IDIOTHTA, COUNT(RANTEVOU) AS RANTEVOU FROM USERS, DOCTORS, RANTEVOU
WHERE AFM_GIATROU=AFM AND DAFM=AFM
GROUP BY DAFM
ORDER BY COUNT(DAFM) DESC
LIMIT 1;

-- 4)
SELECT AFM_PELATI, ONOMA, EPONYMO, COUNT(AFM_PELATI) AS PEL_PATH_SUR FROM RANTEVOU, USERS
WHERE AFM_GIATROU IN(
	SELECT DAFM FROM DOCTORS WHERE (IDIOTHTA).EIDIKOTHTA='Pathologist' OR
	(IDIOTHTA).EIDIKOTHTA='Surgeon')
	AND AFM_PELATI=AFM
GROUP BY AFM_PELATI, ONOMA, EPONYMO
ORDER BY PEL_PATH_SUR DESC;

-- 5)
SELECT AFM_YPALLHLOI, ONOMA, EPONYMO, COUNT(AFM_YPALLHLOI) AS ARTH_RANT_PATH FROM RANTEVOU, USERS
WHERE AFM_GIATROU IN(
	SELECT DAFM FROM DOCTORS WHERE (IDIOTHTA).EIDIKOTHTA='Pathologist')
	AND AFM_YPALLHLOI=AFM
GROUP BY AFM_YPALLHLOI, ONOMA, EPONYMO
ORDER BY ARTH_RANT_PATH DESC
LIMIT 1;

-- 6)
SELECT AFM_GIATROU, ONOMA, EPONYMO, COUNT(AFM_PELATI) AS FEMALE_PELATES FROM RANTEVOU, USERS
WHERE AFM_PELATI IN(
	SELECT AFM FROM USERS WHERE (FYLO).GENDER='Female')
	AND AFM_GIATROU=AFM
GROUP BY AFM_GIATROU, ONOMA, EPONYMO
ORDER BY FEMALE_PELATES DESC
LIMIT 1;


