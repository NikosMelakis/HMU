
DROP TABLE IF EXISTS name_basics CASCADE;
DROP TABLE IF EXISTS title2_basics CASCADE;


CREATE TABLE title2_basics(
	TITLE2_BASICS_ID SERIAL PRIMARY KEY,
	tconst TEXT[] NOT NULL,
	titleType VARCHAR(60) NOT NULL,
	primaryTitle VARCHAR(60) NOT NULL,
	originalTitle VARCHAR(60) NOT NULL,
	isAdult INTEGER NOT NULL,
	startYear DATE NOT NULL,
	endYear DATE NOT NULL,
	runtimeMinutes DECIMAL NOT NULL,
	genres TEXT[] NOT NULL,
	averageRating DECIMAL NOT NULL,
	numVotes INTEGER NOT NULL,
	UNIQUE(tconst));

CREATE TABLE name_basics(
	NAME_BASICS_ID SERIAL PRIMARY KEY,
	nconst VARCHAR(20) NOT NULL,
	primaryName VARCHAR(60) NOT NULL,
	birthYear DATE NOT NULL,
	deathYear DATE NOT NULL,
	primaryProfession TEXT[] NOT NULL,
	knownForTitles TEXT[] NOT NULL REFERENCES title2_basics(tconst));


	
	
	