package localedatetest;

import java.text.ParseException;
import java.util.Locale;

/**
 *
 * @author Costis
 */
public class LocaleDateTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Locale loc = new Locale("en", "US");
        Locale loc=new Locale("el", "GR");
        String dateAsIs = "29/Μαρ/2022:00:46:38 +0300";
        java.text.DateFormat dfm = new java.text.SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss Z", loc);
        System.out.println("dateAsIs " + dateAsIs);
        java.util.Date a;
        try {
            a = dfm.parse(dateAsIs);

            java.sql.Timestamp ts1 = new java.sql.Timestamp(a.getTime());
            System.out.println("OK! Date parsed: " + ts1.toString());

        } catch (ParseException ex) {
            System.out.println("*** ERROR *** " + ex.getMessage());
        }
    }

}
