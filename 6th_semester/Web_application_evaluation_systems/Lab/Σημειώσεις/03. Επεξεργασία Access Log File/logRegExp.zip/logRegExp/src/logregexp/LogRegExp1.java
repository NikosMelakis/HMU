package logregexp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.*;

public class LogRegExp1 {

    public static void main(String argv[]) {
        FileReader myFile = null;
        BufferedReader buff = null;

        //String logEntryPattern = "^([\\d.]+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) ([\\d]+) [a-zA-Z0-9_ ]*(\\S+) [-]?[ ]?\\[([\\w:/]+\\s[+\\-]\\d{4})\\] \\\"(.+?)\\\" (\\d{3}) (\\S+) (\\d)+ (\\S+) \"(.+?)\\\" \"(.+?)\\\"";
String logEntryPattern="^([\\d.]+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) ([\\d]+) [a-zA-Z0-9_ ]*(\\S+) [-]?[ ]?\\[([\\w:/]+\\s[+\\-]\\d{4})\\] \\\"(.+?)\\\" (\\d{3}) (\\S+) ([\\d]+) (\\S+) \"(.+?)\\\" \"(.+?)\\\"";
        System.out.println("Using RE Pattern:");
        System.out.println(logEntryPattern);

        Pattern p = Pattern.compile(logEntryPattern);

        try {
            myFile = new FileReader("alf.log");
            buff = new BufferedReader(myFile);

            while (true) {
                String line = buff.readLine();
                if (line == null) {
                    break;
                }

                Matcher matcher = p.matcher(line);
                System.out.println("groups: " + matcher.groupCount());
                if (!matcher.matches()) {
                    System.err.println(line + matcher.toString());
                    return;
                }

                System.out.println("%a Remote IP Address     : " + matcher.group(1));
                System.out.println("%A Local IP Address      : " + matcher.group(2));
                System.out.println("%b Bytes sent            : " + matcher.group(3));
                System.out.println("%B Bytes sent            : " + matcher.group(4));
                System.out.println("%h Remote host name or IP: " + matcher.group(5));
                //System.out.println("%H Request Protocol      : " + matcher.group(7));
                System.out.println("%I Rem logic username  - : " + matcher.group(6));
                System.out.println("%m Requ Method           : " + matcher.group(7));
                System.out.println("%p Local Port            : " + matcher.group(8));
                System.out.println("%q Query String          : " + matcher.group(9));
                System.out.println("%r First Requ Line       : " + matcher.group(11));
                System.out.println("%s Status                : " + matcher.group(12));
                System.out.println("%t Date and Time         : " + matcher.group(10));                

                System.out.println("%r First Line or Requ    : " + matcher.group(11));

                System.out.println("%U requested URL         : " + matcher.group(13));
                System.out.println("%D time to process (ms)  : " + matcher.group(14));
                System.out.println("%S Session ID            : " + matcher.group(15));
                System.out.println("Agent                    : " + matcher.group(16));
                System.out.println("Referrer                 : " + matcher.group(17));                     
                
                
                
                

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                buff.close();
                myFile.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
