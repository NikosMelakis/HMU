package filereader;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ReadingFile {

    public static void main(String[] args) {
        FileReader myFile = null;
        BufferedReader buff = null;

//        String pattern = "^([\\d.]+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) ([\\d]+) [a-zA-Z0-9_ ]*(\\S+) [-]?[ ]?\\[([\\w:/]+\\s[+\\-]\\d{4})\\] \\\"(.+?)\\\" (\\d{3}) (\\S+) (\\d)+ (\\S+) \"(.+?)\\\" \"(.+?)\\\"";
//        String pattern = "^([\\d.]+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) ([\\d]+) [a-zA-Z0-9_ ]*(\\S+) [-]?[ ]?\\[([\\w:/]+\\s[+\\-]\\d{4})\\] \\\"(.+?)\\\" (\\d{3}) (\\S+) (\\d)+ (\\S+) \"(.+?)\\\" \"(.+?)\\\"";
        
//        String pattern="^([\\d.]+|[\\d:]+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) ([\\d]+) [a-zA-Z0-9_ ]*(\\S+) [-]?[ ]?\\[([\\w:/]+\\s[+\\-]\\d{4})\\] \\\"(.+?)\\\" (\\d{3}) (\\S+) ([\\d]+) (\\S+) \"(.+?)\\\" \"(.+?)\\\"";
        String pattern="^(\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) ([\\d]+) [a-zA-Z0-9_ ]*(\\S+) [-]?[ ]?\\[([\\w:/]+\\s[+\\-]\\d{4})\\] \\\"(.+?)\\\" (\\d{3}) (\\S+) ([\\d]+) (\\S+) \"(.+?)\\\" \"(.+?)\\\"";

        //String pattern="^(\\S+) (\\S+) (\\S+) \\[([\\w:/]+\\s[+\\-]\\d{4})\\] \\\"(.+?)\\\" (\\d+) (\\S+)";
        Pattern r = Pattern.compile(pattern);
        Matcher m;
        try {
            myFile = new FileReader("alf.log");
            //myFile=new FileReader("access.log");
            buff = new BufferedReader(myFile);

            while (true) {
                String line = buff.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
                m = r.matcher(line);
                if (m.find()) {
                    for (int j = 0; j <= m.groupCount(); j++) {                    
                        System.out.println("Found in group " + j + " value: >" + m.group(j) + "<");
                    }
                    System.out.println("---------------------------------------------------------");
                } else {
                    System.out.println("NO MATCH");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                buff.close();
                myFile.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
