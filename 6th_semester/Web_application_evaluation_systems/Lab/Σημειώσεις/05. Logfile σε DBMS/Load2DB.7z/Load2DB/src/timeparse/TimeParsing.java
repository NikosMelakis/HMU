package timeparse;

import java.text.ParseException;
import java.util.Locale;

/**
 *
 * @author costis
 */
public class TimeParsing {

    public static void main(String[] args) {
        String dateAsIs="11/Mar/2016:08:48:54 +0200";
        System.out.println("--->" + dateAsIs);
        // initialize a DateFormat 
        //java.text.DateFormat dfm = new java.text.SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss Z", new Locale("el", "GR") );
        java.text.DateFormat dfm = new java.text.SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss Z");
        dfm.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Athens"));
        System.out.println("dateAsIs " + dateAsIs);
        java.util.Date a;
        try {
            a = dfm.parse(dateAsIs);
            

            java.sql.Timestamp ts1 = new java.sql.Timestamp(a.getTime());
            System.out.println("timestamp: " + ts1.toString());         
            //rs.updateTimestamp("tDateAndTime", ts1); gia na mpei sti Database
            
            java.sql.Timestamp dt1 = new java.sql.Timestamp(a.getTime());
            System.out.println("Date: " + dt1.toString());         
            //rs.updateDate("tDateAndTime", ts1); gia na mpei sti Database            
            
            
            
            System.out.println("...");

        } catch (ParseException ex) {
            System.out.println("exception" + ex.getMessage());
        }
    }
}
