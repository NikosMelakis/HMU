package load2db;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Load2DB {

    public static void main(String[] args) {
        Connection con = null;
        Statement stmt = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            String msg = "The com.mysql.cj.jdbc.Driver is missing\n"
                    + "install and rerun the application";
            System.out.println(msg);
            System.exit(1);
        }

        // connect to db
        try {

            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "zoot");

            System.out.println("Inserting records into the table...");
            stmt = con.createStatement();

            String sql = "INSERT INTO student VALUES (0, 3588, 'Papadakis', 'Akis', 18)"; 
            stmt.executeUpdate(sql); // ektelei to sql statement pou prosthetei edw

        } catch (SQLException e) {
            String msg = "Error Connecting to Database:\n" + e.getMessage();
            System.out.println(msg);
        } finally { // oti anoigei prepei na kleinei
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null) 
                    con.close();
            } catch (SQLException se) {
                System.out.println("SQLException: " + se.getMessage());
            }
        }
    }
}


