drop databse if exists userdb;
create database userdb;


CREATE TABLE `student` (
`idstudent` int(11) NOT NULL AUTO_INCREMENT,
`am` int(11) DEFAULT NULL,
`lastname` varchar(45) DEFAULT NULL,
`firstname` varchar(45) DEFAULT NULL,
`age` int(11) DEFAULT NULL,
`arrivaltime` datetime DEFAULT NULL,
PRIMARY KEY (`idstudent`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


CREATE TABLE `log` (
`code` int(11) unsigned NOT NULL AUTO_INCREMENT,
`aRemoteIPAddress` char(50) DEFAULT NULL,
`ALocalIPAddress` char(50) DEFAULT NULL,
`bBytesSentOrDash` int(11) DEFAULT NULL,
`BBytesSent` int(11) DEFAULT NULL,
`hRemoteHostName` varchar(50) DEFAULT NULL,
`HRequestProtocol` char(20) DEFAULT NULL,
`lRemoteLogicalUsername` char(20) DEFAULT NULL,
`mRequestMethod` char(20) DEFAULT NULL,
`pLocalPort` int(11) DEFAULT NULL,
`qQueryString` varchar(200) DEFAULT NULL,
`rFirstLineOfRequest` varchar(300) DEFAULT NULL,
`sHTTPStatusCode` varchar(50) DEFAULT NULL,
`SUserSessionID` char(32) NOT NULL,
`tDateAndTime` datetime NOT NULL,
`uRemoteUserAuthenticated` char(60) DEFAULT NULL,
`URequestedURLPath` varchar(120) DEFAULT NULL,
`vLocalServerName` varchar(60) DEFAULT NULL,
`DMillisToProcess` int(11) DEFAULT NULL,
`TSecondsToProcess` int(11) DEFAULT NULL,
`ICurrentReqThreadName` varchar(100) DEFAULT NULL,
`isbot` tinyint(1) DEFAULT NULL,
`bot_string` varchar(50) DEFAULT NULL,
PRIMARY KEY (`code`),
UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=97842 DEFAULT CHARSET=utf8;