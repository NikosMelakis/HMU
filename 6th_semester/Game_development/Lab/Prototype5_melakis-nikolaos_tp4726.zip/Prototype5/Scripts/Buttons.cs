using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Buttons : MonoBehaviour
{
    // Start is called before the first frame update
    private Button button;
    private Game_Manager gameManager; 

    public int difficulty;

    void Start()
    {
        button=GetComponent<Button>();
        button.onClick.AddListener(SetDifficulty);
        gameManager=GameObject.Find("Game_Manager").GetComponent<Game_Manager>();
    }

    void SetDifficulty()
    {
        Debug.Log(gameObject.name+" was clicked");
        gameManager.StartGame(difficulty);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    
}
