using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Game_Manager : MonoBehaviour
{
    // Start is called before the first frame update
    public List<GameObject> targets;
    public GameObject[] targets_array;
    private float spawnRate=1.0f;
    
    private int score;
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI GameOverText;

    public bool isGameActive;
    public Button restartbutton;

    public GameObject titleScreen;
    void Start()
    {
        
    }

    public void StartGame (int difficulty) {
        StartCoroutine(SpawnTarget());
        score=0;
        UpdateScore(0);
        isGameActive=true;
        titleScreen.gameObject.SetActive(false);
        spawnRate/=difficulty;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator SpawnTarget(){
        while(isGameActive) {
            yield return new WaitForSeconds(spawnRate);
            int index=Random.Range(0,targets.Count);
            Instantiate(targets[index]);
            
        }
    }

    public void UpdateScore (int scoreToAdd) {
        score+=scoreToAdd;
        scoreText.text="Score: "+score;
    }

     public void GameOver () {
      GameOverText.gameObject.SetActive(true);
      restartbutton.gameObject.SetActive(true);
      isGameActive=false;
      
  }

  public void RestartGame () {
      SceneManager.LoadScene(SceneManager.GetActiveScene().name);
  }

  
}
