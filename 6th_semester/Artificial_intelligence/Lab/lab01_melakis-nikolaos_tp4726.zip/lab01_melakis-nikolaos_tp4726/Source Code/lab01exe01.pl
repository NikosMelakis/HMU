arxikh_katastash([3,3,0,0,boatLeft]).
telikh_katastash([0,0,3,3,boatRight]).

%Telesths01 phgaine(1,1,right)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=1, IA1==KA1, ID1==KD1,
    IA2 is IA1-1,
    KA2 is KA1-1,
    ID2 is ID1+1,
    KD2 is KD1+1.

%Telesths02 phgaine(0,2,right)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=KA1, IA1==KA1, ID1==KD1,
    IA2 is IA1,
    KA2 is KA1-2,
    ID2 is ID1,
    KD2 is KD1+2.

%Telesths03 phgaine(2,0,right)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=2, IA1>=KA1, (IA1>=KA1; ID1==0),
    IA2 is IA1-2,
    KA2 is KA1, (IA2>=KA2; IA2==0),
    ID2 is ID1+2,
    KD2 is KD1.

%Telesths04 phgaine(0,1,right)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=KA1, ID1>=KD1,
    IA2 is IA1,
    KA2 is KA1-1,
    ID2 is ID1,
    KD2 is KD1+1.

%Telesths05 phgaine(1,0,right)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=1, IA1>=KA1, (ID1>=KD1; ID1==0),
    IA2 is IA1-1,
    KA2 is KA1,
    ID2 is ID1+1,
    KD2 is KD1.


%Telesths06 phgaine(1,1,left)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=1, IA1==KA1, ID1==KD1,
    IA2 is IA1+1,
    KA2 is KA1+1,
    ID2 is ID1-1,
    KD2 is KD1-1.

%Telesths07 phgaine(0,2,left)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=KA1, IA1==KA1, ID1==KD1,
    IA2 is IA1,
    KA2 is KA1+2,
    ID2 is ID1,
    KD2 is KD1-2.

%Telesths08 phgaine(2,0,left)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=2, IA1>=KA1, (IA1>=KA1; ID1==0),
    IA2 is IA1+2,
    KA2 is KA1, (IA2>=KA2; IA2==0),
    ID2 is ID1-2,
    KD2 is KD1.

%Telesths09 phgaine(0,1,left)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=KA1, ID1>=KD1,
    IA2 is IA1,
    KA2 is KA1+1,
    ID2 is ID1,
    KD2 is KD1-1.

%Telesths10 phgaine(1,0,left)
efarmogh_telesth([(IA1, KA1), (ID1, KD1), boatLeft], [(IA2, KA2), (ID2, KD2), boatRight]):-
    IA1>=1, IA1>=KA1, (ID1>=KD1; ID1==0),
    IA2 is IA1+1,
    KA2 is KA1,
    ID2 is ID1-1,
    KD2 is KD1.


monopati(X, Y, Monopati) :-
    monopati1(X, Y, [X], Monopati).

monopati1(X, X, Monopati, Monopati) :-
    telikh_katastash(X).

monopati1(X, Z, Monopati, Teliko_monopati) :-
    efarmogh_telesth(X, Y),
    + member(Y, Monopati),
    append(Monopati, [Y], Neo_monopati),
    monopati1(Y, Z, Neo_monopati, Teliko_monopati).



%monopati([3,3,0,0,boatLeft]., [0,0,3,3,boatRight]., Path).