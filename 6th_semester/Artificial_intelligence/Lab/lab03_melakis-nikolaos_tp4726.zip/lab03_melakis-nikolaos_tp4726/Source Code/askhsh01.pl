:-
    op(600, xfy,[\]).


add-end-diff-lists(Elem, DiffList, EndDiffList, NewDiffList, EndNewDiffList):-
	EndDiffList=[Elem|EndNewDiffList],
	NewDiffList=DiffList.

%add-end-diff-lists(1,[a,b,c,d|EndDiffList],EndDiffList,NewDiffList,EndNewDiffList).