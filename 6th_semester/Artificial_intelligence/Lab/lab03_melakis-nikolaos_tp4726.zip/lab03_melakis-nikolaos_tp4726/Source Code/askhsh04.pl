sentence-->
    noun_phrase(Num), verb_phrase(Num).

noun_phrase(Num)-->
    article, noun(Num).

verb_phrase(Num)-->
    verb(Num), noun_phrase(_Anything); verb(Num).

article-->
    [a];[the];[].

noun(singular)-->
    [Word], {noun_lexicon(Word, _X)}.

noun(plural)-->
    [Word], {noun_lexicon(_X, Word)}.

verb(singular)-->
    [Word], {verb_lexicon(W,_X,_Y), name(W, L1),
    append(L1, "s", L2), name(Word, L2)}.

verb(plural)-->
    [Word], {verb_lexicon(Word,_X,_Y)}.

%Lexico

noun_lexicon(dog, dogs).
noun_lexicon(cat, cats).
noun_lexicon(boy, boys).
noun_lexicon(girl, girls).

verb_lexicon(chase, chases, chases).
verb_lexicon(see, saw, seen).
verb_lexicon(say, said, said).
verb_lexicon(believe, believed, believed).


%sentence([the,dog, chases,cats],[]).
%sentence([the,dog, chase, cats],[]).
%sentence(S, []).