sentence(InputPhrase, OutputPhrase):-
    noun_phrase(InputPhrase, TempPhrase), 
    verb_phrase(TempPhrase, OutputPhrase).

noun_phrase(InputPhrase, OutputPhrase):-
    (article(InputPhrase, TempPhrase), noun(TempPhrase, OutputPhrase)).

noun(InputPhrase, OutputPhrase):-
    (InputPhrase=[dog|OutputPhrase]; InputPhrase=[cat|OutputPhrase];
        InputPhrase=[boy|OutputPhrase]; InputPhrase=[girl|OutputPhrase]).

verb_phrase(InputPhrase, OutputPhrase):-
    (verb(InputPhrase, OutputPhrase); 
    verb(InputPhrase, TempPhrase), noun_phrase(TempPhrase, OutputPhrase)).

verb(InputPhrase, OutputPhrase):-
    (InputPhrase=[chased|OutputPhrase]; InputPhrase=[saw|OutputPhrase];
        InputPhrase=[said|OutputPhrase]; InputPhrase=[believe|OutputPhrase]).

article(InputPhrase, OutputPhrase):-
    (InputPhrase=[the|OutputPhrase]; InputPhrase=[a|OutputPhrase];
        InputPhrase=OutputPhrase).


%sentence([the, cat, saw, the, dog],[]).
%sentence([the, saw, cat, the, dog],[]).
%sentence(S, []).