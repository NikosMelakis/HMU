np -->
    noun(_,_); 
    (adjective(Gender,Num), noun(Gender, Num));
    (article(Gender,Num), noun(Gender,Num));
    (article(Gender,Num), adjective(Gender,Num),  noun(Gender,Num)).


article(αρσ,0)-->[ένας];[ο].
article(θηλ,0)-->[μία];[η];[τη].
article(θηλ,4)-->[τις].
article(ουδ,0)-->[ένα];[το];[στο].

noun(Gender,Num)-->[Word], {check_noun(Word,Gender,Num)}.
adjective(Gender,Num)-->[Word], {check_adj(Word,Gender,Num)}.


/*Noun Check*/
check_noun(Thema,Gender,Num):-
	Katal = '-',
	((noun(_, Gender, _,[[Thema,_], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,Thema], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,_], [Thema,_]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4);
	(noun(_, Gender, _,[[_,_], [_,Thema]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4)).

check_noun(Noun,Gender,Num):-
	atom_codes(Noun,Ncodes),
	append(Lthema,[X1], Ncodes),
	Lkatal = [X1],
	atom_codes(Thema, Lthema),
	atom_codes(Katal,Lkatal),
	((noun(_, Gender, _,[[Thema,_], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,Thema], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,_], [Thema,_]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4);
	(noun(_, Gender, _,[[_,_], [_,Thema]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4)).

check_noun(Noun,Gender,Num):-
	atom_codes(Noun,Ncodes),
	append(Lthema,[X1,X2], Ncodes),
	Lkatal = [X1,X2],
	atom_codes(Thema, Lthema),
	atom_codes(Katal,Lkatal),
	((noun(_, Gender, _,[[Thema,_], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,Thema], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,_], [Thema,_]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4);
	(noun(_, Gender, _,[[_,_], [_,Thema]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4)).
	
check_noun(Noun,Gender,Num):-
	atom_codes(Noun,Ncodes),
	append(Lthema,[X1,X2,X3], Ncodes),
	Lkatal = [X1,X2,X3],
	atom_codes(Thema, Lthema),
	atom_codes(Katal,Lkatal),
	((noun(_, Gender, _,[[Thema,_], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,Thema], [_,_]], _, [_,_], A6), nounEnding(A6, _, Enikos, _), nth0(Num,Enikos,Katal));
	(noun(_, Gender, _,[[_,_], [Thema,_]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4);
	(noun(_, Gender, _,[[_,_], [_,Thema]], _, [_,_], A6), nounEnding(A6, _, _, Plith), nth0(Num1,Plith,Katal), Num is Num1+4)).
	

/*Adj Check*/

check_adj(Adj,Gender,Num):-
	atom_codes(Adj,Acodes),
	append(Lthema,[X1], Acodes),
	Lkatal = [X1],
	atom_codes(Thema, Lthema),
	atom_codes(Katal,Lkatal),
	noun(_, _, Thema, [_,_,_], A6),
	endingAdj(A6, [ [Male1,Male2], [Female1,Female2], [Neutral1,Neutral2] ]),
	((nth0(Num,Male1,Katal),Gender = 'αρσ');
	(nth0(Num1,Male2,Katal),Gender = 'αρσ', Num is Num1+4);
	(nth0(Num,Female1,Katal),Gender = 'θηλ');
	(nth0(Num1,Female2,Katal),Gender = 'θηλ', Num is Num1+4);
	(nth0(Num,Neutral1,Katal),Gender = 'ουδ');
	(nth0(Num1,Neutral2,Katal),Gender = 'ουδ', Num is Num1+4)).

check_adj(Adj,Gender,Num):-
	atom_codes(Adj,Acodes),
	append(Lthema,[X1,X2], Acodes),
	Lkatal = [X1,X2],
	atom_codes(Thema, Lthema),
	atom_codes(Katal,Lkatal),
	noun(_, _, Thema, [_,_,_], A6),
	endingAdj(A6, [ [Male1,Male2], [Female1,Female2], [Neutral1,Neutral2] ]),
	((nth0(Num,Male1,Katal),Gender = 'αρσ');
	(nth0(Num1,Male2,Katal),Gender = 'αρσ', Num is Num1+4);
	(nth0(Num,Female1,Katal),Gender = 'θηλ');
	(nth0(Num1,Female2,Katal),Gender = 'θηλ', Num is Num1+4);
	(nth0(Num,Neutral1,Katal),Gender = 'ουδ');
	(nth0(Num1,Neutral2,Katal),Gender = 'ουδ', Num is Num1+4)).
	
check_adj(Adj,Gender,Num):-
	atom_codes(Adj,Acodes),
	append(Lthema,[X1,X2,X3], Acodes),
	Lkatal = [X1,X2,X3],
	atom_codes(Thema, Lthema),
	atom_codes(Katal,Lkatal),
	noun(_, _, Thema, [_,_,_], A6),
	endingAdj(A6, [ [Male1,Male2], [Female1,Female2], [Neutral1,Neutral2] ]),
	((nth0(Num,Male1,Katal),Gender = 'αρσ');
	(nth0(Num1,Male2,Katal),Gender = 'αρσ', Num is Num1+4);
	(nth0(Num,Female1,Katal),Gender = 'θηλ');
	(nth0(Num1,Female2,Katal),Gender = 'θηλ', Num is Num1+4);
	(nth0(Num,Neutral1,Katal),Gender = 'ουδ');
	(nth0(Num1,Neutral2,Katal),Gender = 'ουδ', Num is Num1+4)).
	
check_adj(Adj,Gender,Num):-
	atom_codes(Adj,Acodes),
	append(Lthema,[X1,X2,X3,X4], Acodes),
	Lkatal = [X1,X2,X3,X4],
	atom_codes(Thema, Lthema),
	atom_codes(Katal,Lkatal),
	noun(_, _, Thema, [_,_,_], A6),
	endingAdj(A6, [ [Male1,Male2], [Female1,Female2], [Neutral1,Neutral2] ]),
	((nth0(Num,Male1,Katal),Gender = 'αρσ');
	(nth0(Num1,Male2,Katal),Gender = 'αρσ', Num is Num1+4);
	(nth0(Num,Female1,Katal),Gender = 'θηλ');
	(nth0(Num1,Female2,Katal),Gender = 'θηλ', Num is Num1+4);
	(nth0(Num,Neutral1,Katal),Gender = 'ουδ');
	(nth0(Num1,Neutral2,Katal),Gender = 'ουδ', Num is Num1+4)).





/*Nouns*/

noun(κοινό,αρσ,ισοσυλ, [[ναύτ,ναύτ], [ναύτ,ναυτ]],[παροξύτονη,παροξύτονη], [ης,ες], maleNounEnding01).
noun(κοινό,αρσ,ισοσυλ, [[νικητ,νικητ], [νικητ,νικητ]], [οξύτονη, οξύτονη], [ής,ές], maleNounEnding02).
noun(κοινό,αρσ,ανισοσυλ, [[μανάβ,μανάβ], [μανάβηδ,μανάβηδ]], [παροξύτονη,προπαροξύτονη], [ης,ες], maleNounEnding03).

noun(κοινό,θηλ,ισοσυλ, [[καρδι,καρδι],[καρδι,καρδι]], [οξύτονη, οξύτονη], [α,ές], femaleNounEnding01).
noun(κοινό,θηλ,ισοσυλ, [[θάλλασσ,θάλασσ], [θάλασσ,θαλασσ]], [προπαροξύτονη,προπαροξύτονη], [α,ες], femaleNounEnding02).

noun(κοινό,ουδ, ισοσυλ, [[παιδ,παιδ],[παιδ,παιδ]], [οξύτονη,οξύτονη], [ί, ά], neutralNounEnding01).
noun(κοινό,ουδ, ανισοσυλ, [[κύμα, κύματ], [κύματ,κυμάτ]], [παροξύτονη,προπαροξύτονη], [α,α], neutralNounEnding02).
noun(κοινό,ουδ, ανισοσυλ, [[όνομα,ονόματ], [ονόματ,ονομάτ]], [προπαροξύτονη,προπαροξύτονη], [α,α], neutralNounEnding02).


nounEnding(maleNounEnding01, αρσ-ισοσύλαβα-σε-ης, [ης,η,η,η],[ες,ών,ες,ες]).
nounEnding(maleNounEnding02, αρσ-ισοσύλαβα-σε-ής, [ής,ή,ή,ή],[ές,ών,ές,ές]).
nounEnding(maleNounEnding03, αρσ-ανισοσύλαβα-σε-ης, [ης,η,η,η],[ες,ων,ες,ες]).

nounEnding(femaleNounEnding01, θηλ-ισοσύλαβα-σε-ά, [ά,άς,ά,ά],[ές,ών,ές,ές]).
nounEnding(femaleNounEnding02, θηλ-ισοσύλαβα-σε-α, [α,ας,α,α],[ες,ών,ες,ες]).

nounEnding(neutralNounEnding01, ουδ-ισοσύλαβα-σε-ί, [ί,ιού,ί,ί],[ιά,ιών,ιά,ιά]).
nounEnding(neutralNounEnding02, ουδ-ανισοσύλαβα-σε-α, [-,ος,-,-],[α,ων,α,α]).



/*Adjectives*/

adjective(ισο_οξύτονη,καλ,[ός, ή, ό], adjEnding01).
adjective(ισο_παροξύτονη,ωραί,[ος, α, ο], adjEnding02).
adjective(ανισο_παροξύτονη,πεισματάρ,[ης, η, η], adjEnding03).

endingAdj(adjEnding01,[[[ός, ού, ό, έ], [οί, ών, ούς, οί]], 
                            [[ή, ής, ή, ή], [ές, ών, ές, ές]],
                                [[ό, ού, ό, ό], [ά, ών, ά, ά]]]).
endingAdj(adjEnding02,[[[ος, ου, ο, ε], [οι, ων, ους, οι], 
                            [α, ας, α, α], [ες, ων, ες, ες],
                                [ο, ου, ο, ο], [α, ων, α, α]]]).
endingAdj(adjEnding03,[[[ης,η,η,η],[ ηδες,ηδων,ηδες,ηδες]], 
                        [[α,ας,α,α],[ες,_,ες,ες]], 
                            [[ικο,ικου,ικο,ικο],[ικα,ικων,ικα,ικα]]]).





