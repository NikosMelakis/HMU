
package assignement;


public class Init {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new project();
    }
    
}
