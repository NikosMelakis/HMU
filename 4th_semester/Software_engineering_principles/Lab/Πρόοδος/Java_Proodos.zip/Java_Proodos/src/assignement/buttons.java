/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignement;

import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author babis
 */
public class buttons extends JPanel {
    public JButton buttonclear= new JButton("Clear");
    public JButton buttonregister= new JButton("Register");
    public JButton buttonexit= new JButton("Exit");
    public buttons(){
        makeButtons();
    }
    public void makeButtons(){
        this.add(buttonclear);
        this.add(buttonregister);
        this.add(buttonexit);
    }
}
