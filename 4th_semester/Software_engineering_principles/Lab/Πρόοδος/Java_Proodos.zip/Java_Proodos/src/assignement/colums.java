/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignement;

import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author babis
 */
public class colums extends JPanel{
    public JPanel RightPanel= new JPanel(new GridLayout(4,2));
    public JPanel col2= new JPanel(new GridLayout(4,2));
    public JLabel ladress=new JLabel("Adress:");
    public JLabel lgender=new JLabel("Gender:");
    public JTextField fadress=new JTextField("");
    public JTextField  fgender=new JTextField("");
    public JLabel lusername= new JLabel("*Username:");
    public JLabel lpassword= new JLabel("*Password:");
    public JLabel lemail= new JLabel("*Email:");
    public JTextField fusername=new JTextField("");
    public JPasswordField fpassword=new JPasswordField("");
    public JTextField femail=new JTextField("");
    public JLabel lFirstName= new JLabel("*FirstName:");
    public JLabel lLastName= new JLabel("*LastName");
    public JLabel lage= new JLabel("Age:");
    public JTextField fFirstName=new JTextField("");
    public JTextField fLastName=new JTextField("");
    public JTextField fage=new JTextField("");
    public colums(){
        init();
    }
    public void init(){
        this.setLayout(new GridLayout(0,2,1,1));
        makeCols();
    }
    
    public void makeCols(){
        RightPanel.add(lusername);RightPanel.add(fusername);
        RightPanel.add(lpassword);RightPanel.add(fpassword);
        RightPanel.add(lemail);RightPanel.add(femail);
        RightPanel.add(ladress);RightPanel.add(fadress);
        this.add(RightPanel);
        col2.add(lFirstName);col2.add(fFirstName);
        col2.add(lLastName);col2.add(fLastName);
        col2.add(lage);col2.add(fage);
        col2.add(lgender);col2.add(fgender);
        this.add(col2);
        
    }
        public void clearAll(){
        this.fusername.setText("");
        this.fpassword.setText("");
        this.femail.setText("");
        this.fFirstName.setText("");
        this.fLastName.setText("");
        this.fage.setText("");
        this.fadress.setText("");
        this.fgender.setText("");
    }
        public void checkEmpty(){
           if(this.fusername.getText().equals("")){
               JOptionPane.showMessageDialog(null,"Username is Empty", "Empty Field",JOptionPane.ERROR_MESSAGE);
           }
           else if(this.fpassword.getPassword().length == 0){
               
               JOptionPane.showMessageDialog(null,"Password is Empty", "Empty Field",JOptionPane.ERROR_MESSAGE);
           }
           else if(this.femail.getText().equals("")){
               
               JOptionPane.showMessageDialog(null,"Email is Empty", "Empty Field",JOptionPane.ERROR_MESSAGE);
           }
           else if(this.fFirstName.getText().equals("")){
               
               JOptionPane.showMessageDialog(null,"First Name is Empty", "Empty Field",JOptionPane.ERROR_MESSAGE);
           }
           else if(this.fLastName.getText().equals("")){
               
               JOptionPane.showMessageDialog(null,"Last Name is Empty", "Empty Field",JOptionPane.ERROR_MESSAGE);
           }
           else{
               JOptionPane.showMessageDialog(
    null, 
    "Register Success", 
    "Welcome",
    JOptionPane.INFORMATION_MESSAGE);
               clearAll();
           }
    }
}
