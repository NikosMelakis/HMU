package assignement;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.ERROR_MESSAGE;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class project extends JFrame{
    public JPanel panel= new JPanel();
    public buttons Buttonspanel= new buttons();

    public JLabel label=new JLabel("<html><font color='red'>Fields with asterisk(*) are mandatory</font></html>");

    public colums centerPanel= new colums();
    
    
    public project(){
        initComp();
    }
    public void initComp(){
        Buttonspanel.buttonclear.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
           centerPanel.clearAll();
        }
        });
        Buttonspanel.buttonexit.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
           dispose();
        }
        });
        Buttonspanel.buttonregister.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
           centerPanel.checkEmpty();
        }
        });
        this.setTitle("Register");
        this.setSize(500,200);
        
        this.add(centerPanel);
        this.add(label, BorderLayout.NORTH);
        this.add(centerPanel,BorderLayout.CENTER);
        this.add(Buttonspanel,BorderLayout.SOUTH);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }


    
    
}
