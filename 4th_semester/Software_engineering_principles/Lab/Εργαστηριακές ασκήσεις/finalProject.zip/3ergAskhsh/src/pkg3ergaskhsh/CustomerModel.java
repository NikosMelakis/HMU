package pkg3ergaskhsh;


public class CustomerModel {
    private String lastname;
    private String firstname;
    private String afm;
    private String telephone;
    private int idcustomer;

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String name) {
        this.lastname = name;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getAfm() {
        return afm;
    }

    public void setAfm(String afm) {
        this.afm = afm;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public int getIdcustomer() {
        return idcustomer;
    }

    public void setIdcustomer(int idcustomer) {
        this.idcustomer = idcustomer;
    }

    public void updateCustomer(String lastname, String firstname, String afm, String telephone, int idcustomer) {
        this.lastname = lastname;
        this.firstname = firstname;
        this.afm = afm;
        this.telephone = telephone;
        this.idcustomer = idcustomer;
    }
    
    public CustomerModel(String lastname, String firstname, String afm, String telephone, int idcustomer) {
        this.lastname = lastname;
        this.firstname = firstname;
        this.afm = afm;
        this.telephone = telephone;
        this.idcustomer = idcustomer;
    }

    public CustomerModel() {
        
    }
    
}
