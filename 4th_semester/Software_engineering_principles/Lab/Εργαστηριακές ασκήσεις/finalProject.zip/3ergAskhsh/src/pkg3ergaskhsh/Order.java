package pkg3ergaskhsh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class Order extends JDialog {

    public Order(JFrame fr) {
        super(fr, "PlaceOrder", true);
        connect2DB();
        initCompo();

    }

    private void initCompo() {
        jpan = new JPanel(new GridLayout(6, 2));

        lcust = new JLabel("Customer:", JLabel.RIGHT);
        linv = new JLabel("Inventory Item:", JLabel.RIGHT);
        lip = new JLabel("Item Price:", JLabel.RIGHT);
        lqu = new JLabel("Quantity:", JLabel.RIGHT);
        ltp = new JLabel("Total Price:", JLabel.RIGHT);

        cb = new JComboBox<>();
        cb.setModel(new OrderMod(con));
        cb.setSelectedIndex(0);

        ib = new JComboBox<>();
        ib.setModel(new OrderMod2(con));
        ib.setSelectedIndex(0);
        ib.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshLabel();
            }
        });

        fip = new JTextField();
        fip.setEditable(false);
        fqu = new JTextField("1");
        fqu.setEditable(false);
        ftp = new JTextField();
        ftp.setEditable(false);

        form = new JPanel(new BorderLayout());

        bb = new JPanel(new FlowLayout());

        al = new JButton("Add Line");
        Object[] row = new Object[5];
        al.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                row[0] = ordersModel.getIdOrder();
                row[1] = customerModel.getLastname();
                row[2] = inventoryModel.getCategory();
                row[3] = inventoryModel.getDescripiton();
                row[4] = inventoryModel.getPrice();
                tablemodel.addRow(row);

                form2DB();
                updateTable();
            }
        });
        dl = new JButton("Delete Line");
        dl.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DeleteRow();
            }
        });

        form2 = new JPanel(new BorderLayout());

        texit = new JToolBar();
        texit.setFloatable(false);
        bexit = new JButton("Exit");
        bexit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        bb.add(al);
        bb.add(dl);

        jpan.add(lcust);
        jpan.add(cb);
        jpan.add(linv);
        jpan.add(ib);
        jpan.add(lip);
        jpan.add(fip);
        jpan.add(lqu);
        jpan.add(fqu);
        jpan.add(ltp);
        jpan.add(ftp);

        texit.add(bexit);
        add(texit, BorderLayout.SOUTH);
        form.add(bb, BorderLayout.SOUTH);
        form.add(jpan);

        ot = new JTable();
        tablemodel = (DefaultTableModel) ot.getModel();
        Object[] columns = {"Order Id", "Customer", "Category", "Description", "Price"};
        tablemodel.setColumnIdentifiers(columns);
        ot.setModel(tablemodel);
        sp = new JScrollPane(ot);
        updateTable();

        form2.add(sp);
        splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, form, form2);
        add(splitPane);
        pack();

    }

    private void connect2DB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            String msg = "The com.mysql.cj.jdbc.Driver is missing\n"
                    + "install and rerun the application";
            JOptionPane.showMessageDialog(this, msg, this.getTitle(), JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inv?useSSL=false", "root", "Lad21123");
        } catch (SQLException e) {
            String msg = "Error Connecting to Database:\n" + e.getMessage();
            JOptionPane.showMessageDialog(this, msg, this.getTitle(), JOptionPane.ERROR_MESSAGE);
        }

    }

    private void refreshLabel() {
        fip.setText(String.valueOf(price));
        ftp.setText(String.valueOf(price));
    }

    private void form2DB() {
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String values = String.format("VALUES(%d, %d, %d, %d)",
                    customerModel.getIdcustomer(), inventoryModel.getIdinv(), 1,
                    inventoryModel.getPrice());
            String query = "INSERT INTO orders (custid,invid,quantity,price) " + values;
            stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void updateTable() {
        Object[] row = new Object[5];
        for (int i = ot.getRowCount() - 1; i >= 0; i--) {
            tablemodel.removeRow(i);
        }
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String query = " SELECT * FROM orders, customer, inventory "
                    + "WHERE orders.custid=customer.idcustomer "
                    + "AND orders.invid=idinv "
                    + "ORDER BY idOrder;";
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                row[0] = rs.getInt("idOrder");
                row[1] = rs.getString("lastname");
                row[2] = rs.getString("category");
                row[3] = rs.getString("description");
                row[4] = rs.getString("price");
                tablemodel.addRow(row);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
    }

    private void DeleteRow(){
          int i = ot.getSelectedRow();
                String id = tablemodel.getValueAt(i, 0).toString();
                try {
                    String sql = "DELETE  FROM `inv`.`orders` WHERE (`idOrder` = '" + id + "')";
                    stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    stmt.execute(sql);
                    JOptionPane.showMessageDialog(rootPane, "Delete Success");
               
                if (i >= 0) {
                    tablemodel.removeRow(i);
                } else {
                    System.out.println("Delete Error");
                }
                }catch (Exception e){
                    System.out.println(e.toString());
                }
    }
    
    private JComboBox<String> cb, ib;
    private JTextField fip, fqu, ftp;
    private JButton al, dl, bexit;
    private JLabel lcust, linv, lip, lqu, ltp;
    private JToolBar texit;
    private JSplitPane splitPane;
    private JTable ot;
    private DefaultTableModel tablemodel;
    private JScrollPane sp;
    private JPanel jpan, bb, form, form2;
    private Connection con;
    private Statement stmt;
    private ResultSet rs;

    public static int price;
    public static CustomerModel customerModel = new CustomerModel();
    public static InventoryModel inventoryModel = new InventoryModel();
    public static OrdersModel ordersModel = new OrdersModel();
}
