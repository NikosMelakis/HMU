package pkg3ergaskhsh;

import java.sql.*;
import javax.swing.DefaultComboBoxModel;

public class OrderMod extends DefaultComboBoxModel<String> {

    public OrderMod(Connection con) {
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            String query = "SELECT * FROM customer";
            rs = stmt.executeQuery(query);
        } catch (SQLException e) {
            System.out.println("ComboModel4: " + e.getMessage());
        }
    }

    @Override
    public String getElementAt(int index) {
        String lstn = null;
        try {
            rs.absolute(index + 1);
            lstn = rs.getString("lastname") + ", " + rs.getString("firstname") + ", "
                    + rs.getInt("idcustomer");
            
            Order.customerModel.updateCustomer(rs.getString("lastname"), rs.getString("firstname"), rs.getString("afm"), 
                                               rs.getString("telephone"), rs.getInt("idcustomer"));
            
        } catch (SQLException e) {
            System.out.println("getElementAt(): " + e.getMessage());
        }
        return lstn;
    }

    @Override
    public int getSize() {
        int cnt = 0;
        try {
            rs.last();
            cnt = rs.getRow();
        } catch (SQLException ex) {
            System.out.println("getSize(): " + ex.getMessage());
        }
        return cnt;
    }

    public int getIdCustAt(int index) {
        int idCust = 0;
        try {
            rs.absolute(index + 1);
            idCust = rs.getInt("idcustomer");
        } catch (SQLException e) {
            System.out.println("getElementAt(): " + e.getMessage());
        }
        return idCust;
    }
    private Statement stmt;
    private ResultSet rs;
}
