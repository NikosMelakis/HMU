package pkg3ergaskhsh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Customer extends JDialog {

    public Customer(JFrame fr) {
        super(fr, "Customer", true);
        initCompo();
        connect2DB();
        prepareForm();
    }

    private void initCompo() {
        tb = new JToolBar();
        tb.setFloatable(false);
        cc = new JPanel(new FlowLayout());
        bFirst = new JButton("First");
        bFirst.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doFirst();
            }
        });
        bPrev = new JButton("Previous");
        bPrev.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doPrevious();
            }
        });
        bNext = new JButton("Next");
        bNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doNext();
            }
        });
        bLast = new JButton("Last");
        bLast.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doLast();
            }
        });
        bAdd = new JButton("Add");
        bAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doAdd();
            }
        });
        bMod = new JButton("Modify");
        bMod.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doModify();
            }
        });
        bDel = new JButton("Delete");
        bDel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doDelete();
            }
        });
        bOk = new JButton("Ok");
        bOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doOK();
            }
        });
        bCanc = new JButton("Cancel");
        bCanc.setEnabled(false);
        bCanc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doCancel();
            }
        });
        bClose = new JButton("Close");
        bClose.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doClose();
            }
        });

        tb.add(bFirst);
        tb.add(bPrev);
        tb.add(bNext);
        tb.add(bLast);
        tb.add(bAdd);
        tb.add(bMod);
        tb.add(bDel);
        tb.add(bOk);
        tb.add(bCanc);
        cc.add(bClose);

        form = new JPanel(new BorderLayout());
        fp = new JPanel(new GridLayout(5, 2));

        lid = new JLabel("ID:", JLabel.RIGHT);
        lln = new JLabel("LastName:", JLabel.RIGHT);
        lfn = new JLabel("FirstName:", JLabel.RIGHT);
        lafm = new JLabel("AFM:", JLabel.RIGHT);
        lphone = new JLabel("Telephone:", JLabel.RIGHT);

        tid = new JTextField();
        tln = new JTextField();
        tfn = new JTextField();
        tafm = new JTextField();
        tphone = new JTextField();

        fp.add(lid);
        fp.add(tid);
        fp.add(lln);
        fp.add(tln);
        fp.add(lfn);
        fp.add(tfn);
        fp.add(lafm);
        fp.add(tafm);
        fp.add(lphone);
        fp.add(tphone);

        form.add(fp);
        add(tb, BorderLayout.NORTH);
        add(form);
        add(cc, BorderLayout.SOUTH);
        pack();
    }

    private void connect2DB() {
        //tsekarei an exoume to driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            String msg = "The com.mysql.cj.jdbc.Driver is missing\n"
                    + "install and rerun the application";
            JOptionPane.showMessageDialog(this, msg, this.getTitle(), JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        // sundesh vashs
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inv?useSSL=false", "root", "Lad21123");
        } catch (SQLException e) {
            String msg = "Error Connecting to Database:\n" + e.getMessage();
            JOptionPane.showMessageDialog(this, msg, this.getTitle(), JOptionPane.ERROR_MESSAGE);
        }
    }

    private void prepareForm() {
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String query = "SELECT * FROM customer";
            rs = stmt.executeQuery(query);

            if (rs.first()) {
                data2Form();
                current = 1;
            } else {
                current = 0;
            }

            tid.setEditable(false);
            tln.setEditable(false);
            tfn.setEditable(false);
            tafm.setEditable(false);
            tphone.setEditable(false);
            bOk.setEnabled(false);

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void doFirst() {
        try {
            if (rs.first()) {
                data2Form();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void doPrevious() {
        try {
            if (!rs.isFirst()) {
                if (rs.previous()) {
                    data2Form();
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void doNext() {
        try {
            if (!rs.isLast()) {
                if (rs.next()) {
                    data2Form();
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void doLast() {
        try {
            if (rs.last()) {
                data2Form();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void doAdd() {
        mode = 0;
        if (current > 0) {
            try {
                current = rs.getInt(1);
            } catch (SQLException e) {
                System.out.println("doAdd: " + e.getMessage());
            }
        }

        tln.setEditable(true);
        tfn.setEditable(true);
        tafm.setEditable(true);
        tphone.setEditable(true);

        space2Form();
        bOk.setEnabled(true);
        bCanc.setEnabled(true);
    }

    private void doModify() {
        mode = 1;
        if (current > 0) {
            try {
                current = rs.getInt(1);
            } catch (SQLException e) {
                System.out.println("doAdd: " + e.getMessage());
            }
        }

        tln.setEditable(true);
        tfn.setEditable(true);
        tafm.setEditable(true);
        tphone.setEditable(true);

        bOk.setEnabled(true);
        bCanc.setEnabled(true);
    }

    private void data2Form() {
        try {
            tid.setText(String.valueOf(rs.getInt("idcustomer")));
            tln.setText(rs.getString("lastname"));
            tfn.setText(rs.getString("firstname"));
            tafm.setText(rs.getString("afm"));
            tphone.setText(rs.getString("telephone"));
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void space2Form() {
        tid.setText(null);
        tln.setText(null);
        tfn.setText(null);
        tafm.setText(null);
        tphone.setText(null);
    }

    private void form2DB() {
        try {
            if (mode == 0) {
                rs.moveToInsertRow();
            }

            rs.updateString("lastname", tln.getText());
            rs.updateString("firstname", tfn.getText());
            rs.updateString("afm", tafm.getText());
            rs.updateString("telephone", tphone.getText());

            if (mode == 0) {
                rs.insertRow();
            } else {
                rs.updateRow();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void doDelete() {
        String id = tid.getText();
        try {
            String sql = "DELETE  FROM `inv`.`customer` WHERE (`idcustomer` = '" + id + "')";
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.execute(sql);
            JOptionPane.showMessageDialog(rootPane, "Delete Success");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e);
        }
        space2Form();

    }

    private void doOK() {
        form2DB();
        if (mode == 0) {
            doLast();
        }
        current += 1;
        tid.setEditable(false);
        tln.setEditable(false);
        tfn.setEditable(false);
        tafm.setEditable(false);
        tphone.setEditable(false);
        bOk.setEnabled(false);
        bCanc.setEnabled(false);
    }

    private void doCancel() {
        if (current > 0) {
            try {
                doFirst();
                while (current != rs.getInt(1)) {
                    doNext();
                }
                data2Form();
            } catch (SQLException e) {
                System.out.println("doCancel: " + e.getMessage());
            }
        }
        tid.setEditable(false);
        tln.setEditable(false);
        tfn.setEditable(false);
        tafm.setEditable(false);
        tphone.setEditable(false);
        bOk.setEnabled(false);
        bCanc.setEnabled(false);
    }

    private void doClose() {
        closeJDBC(rs, stmt, con);
        System.exit(0);
    }

    public void closeJDBC(ResultSet resultSet, Statement statement, Connection connection) {
        if (resultSet != null) {
            try {
                if (!resultSet.isClosed()) {
                    resultSet.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (statement != null) {
            try {
                if (!statement.isClosed()) {
                    statement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                if (!connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private Connection con;
    private Statement stmt;
    private ResultSet rs;
    private JTextField tid, tln, tfn, tafm, tphone;
    private JLabel lid, lln, lfn, lafm, lphone;
    private JPanel form, fp, cc;
    private JButton bFirst, bPrev, bNext, bLast, bAdd, bMod, bDel, bOk, bCanc, bClose;
    private JToolBar tb;

    private int current = 0;
    private int mode = 0;
}
