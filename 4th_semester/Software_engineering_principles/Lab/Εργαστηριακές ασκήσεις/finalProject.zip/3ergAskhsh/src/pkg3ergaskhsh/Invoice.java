package pkg3ergaskhsh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;

public class Invoice extends JDialog {

    public Invoice(JFrame fr) {
        super(fr, "Print Invoice", true);
        connect2DB();
        initCompo();
    }

    private void initCompo() {
        jpan = new JPanel(new GridLayout(1, 1));
        linv = new JLabel("Invoice For Customer: ", JLabel.RIGHT);

        cb = new JComboBox<>();
        cb.setModel(new OrderMod(con));
        cb.setSelectedIndex(0);

        bb = new JPanel(new FlowLayout());

        bp = new JButton("Print Invoice");
        bp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DoPrint();
            }
        });

        bb.add(bp);

        jpan.add(linv);
        jpan.add(cb);

        add(jpan);
        add(bb, BorderLayout.SOUTH);
        pack();

    }

    private void connect2DB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            String msg = "The com.mysql.cj.jdbc.Driver is missing\n"
                    + "install and rerun the application";
            JOptionPane.showMessageDialog(this, msg, this.getTitle(), JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inv?useSSL=false", "root", "Lad21123");
        } catch (SQLException e) {
            String msg = "Error Connecting to Database:\n" + e.getMessage();
            JOptionPane.showMessageDialog(this, msg, this.getTitle(), JOptionPane.ERROR_MESSAGE);
        }
    }

    private void DoPrint() {
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String query = "SELECT * FROM orders, customer, inventory "
                    + "WHERE orders.custid=customer.idcustomer "
                    + "AND orders.invid=idinv "
                    + "AND orders.custid="
                    + Order.customerModel.getIdcustomer() + ";";
            rs = stmt.executeQuery(query);
            System.out.println("For Customer ID: "+Order.customerModel.getIdcustomer());
            System.out.println("  Customer Name: "+Order.customerModel.getLastname()+" "+Order.customerModel.getFirstname());
            System.out.println("==================================================================");
            System.out.println("Order  Categiry             Description        Quantity   Price");
            System.out.println("==================================================================");
            while (rs.next()) {
                int id = rs.getInt("idOrder");
                String category = rs.getString("category");
                String description = rs.getString("description");
                String quantity = rs.getString("quantity");
                String price = rs.getString("price");

                System.out.println("  "+id+"  "+category+"      "+description+"             "+quantity+"        "+price);
                 
            }
            System.out.println("==================================================================");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private ResultSet rs;
    private Statement stmt;
    private JComboBox<String> cb;
    private JButton bp;
    private JLabel linv;
    private JPanel jpan, bb;
    private Connection con;
}
