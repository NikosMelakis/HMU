package pkg3ergaskhsh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Menu extends JFrame {

    public Menu() {
        super("Invoice Application 2021");
        initCompo();
        d1 = new Customer(this);
        d2 = new Order(this);
        d3 = new Inventory(this);
        d4 = new ReportCustomer(this);
        d5 = new ReportInventory(this);
        d6 = new Invoice(this);
    }

    private void initCompo() {
        jf = new JPanel();
        jf.setPreferredSize(new Dimension(300, 100));
        mb = new JMenuBar();
        mnuf = new JMenu("Files");
        mnuo = new JMenu("Order");
        mnur = new JMenu("Reports");
        mnuh = new JMenu("Help");

        finv = new JMenuItem("Inventory");
        finv.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                d3.setVisible(true);
            }
        });
        fcust = new JMenuItem("Customers");
        fcust.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                d1.setVisible(true);
            }
        });
        fexit = new JMenuItem("Exit");
        fexit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        oplace = new JMenuItem("Place Order");
        oplace.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                d2.setVisible(true);
            }
        });
        rcusto = new JMenuItem("Customers");
        rcusto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                d4.setVisible(true);
            }
        });
        rinv = new JMenuItem("Inventory");
        rinv.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                d5.setVisible(true);
            }
        });
        rinvoice = new JMenuItem("INVOICE");
        rinvoice.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                d6.setVisible(true);
            }
        });
        habout = new JMenuItem("About");
        habout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(rootPane, "Created By Antonios Ladianos!!");
            }
        });

        mb.add(mnuf);
        mnuf.add(finv);
        mnuf.add(fcust);
        mnuf.add(fexit);
        mb.add(mnuo);
        mnuo.add(oplace);
        mb.add(mnur);
        mnur.add(rcusto);
        mnur.add(rinv);
        mnur.add(rinvoice);
        mb.add(mnuh);
        mnuh.add(habout);
        add(jf);
        setJMenuBar(mb);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }

    public static void main(String[] args) {
        new Menu().setVisible(true);
    }

    private JPanel jf;
    private JMenuBar mb;
    private JMenu mnuf, mnuo, mnur, mnuh;
    private JMenuItem finv, fcust, fexit, oplace, rcusto, rinv, rinvoice, habout;
    private Customer d1;
    private Order d2;
    private Inventory d3;
    private ReportCustomer d4;
    private ReportInventory d5;
    private Invoice d6;
}
