package pkg3ergaskhsh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReportInventory extends JDialog {

    public ReportInventory(JFrame fr) {
        super(fr, "Print Inventory", true);
        initCompo();
    }

    private void initCompo() {
        p = new JPanel(new FlowLayout());
        p.setPreferredSize(new Dimension(300, 100));
        b = new JButton("Print Inventory");
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DoPrint();
            }
        });

        p.add(b);

        add(p, BorderLayout.SOUTH);
        pack();
    }

    private void DoPrint() {
          try {
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inv?useSSL=false", "root", "Lad21123");
         
         Statement stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery("SELECT * FROM inventory");
        
         
         while (rs.next()) {
            int id = rs.getInt("idinv");
            String desc = rs.getString("description");
            String category = rs.getString("category");
            int quantity= rs.getInt("quantity");
            int price= rs.getInt("price");
            System.out.println("-------------------------------------------------------------------------------------------");
            System.out.println("Code    description             category                   quantity             Telephone");
            System.out.println(id+"       "+   desc+"              "+  category+"                     "+quantity +"          "+price);
            
            System.out.println("--------------------------------------------------------------------------------------------");
         }
         
         
      } catch(SQLException e) {
         System.out.println("SQL exception occured" + e);
      }
     }
    

    private JPanel p;
    private JButton b;
}
