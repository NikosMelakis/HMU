package pkg3ergaskhsh;

public class InventoryModel {
    private int idinv;
    private String category;
    private String descripiton;
    private int price;
    private int quantity;

    public int getIdinv() {
        return idinv;
    }

    public void setIdinv(int idinv) {
        this.idinv = idinv;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescripiton() {
        return descripiton;
    }

    public void setDescripiton(String descripiton) {
        this.descripiton = descripiton;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
   
    public void updateInventory(int idinv, String category, String descripiton, int price, int quantity) {
        this.idinv = idinv;
        this.category = category;
        this.descripiton = descripiton;
        this.price = price;
        this.quantity = quantity;
    }
    
    public InventoryModel(int idinv, String category, String descripiton, int price, int quantity) {
        this.idinv = idinv;
        this.category = category;
        this.descripiton = descripiton;
        this.price = price;
        this.quantity = quantity;
    }

    public InventoryModel() {
    }
    
}
