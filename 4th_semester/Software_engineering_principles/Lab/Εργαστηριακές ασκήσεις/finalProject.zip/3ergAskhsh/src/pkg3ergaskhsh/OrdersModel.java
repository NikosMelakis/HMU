package pkg3ergaskhsh;

public class OrdersModel {
    private int idOrder;
    private int custid;
    private int invid;
    private int quantity;
    private int price;

    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    public int getCustid() {
        return custid;
    }

    public void setCustid(int custid) {
        this.custid = custid;
    }

    public int getInvid() {
        return invid;
    }

    public void setInvid(int invid) {
        this.invid = invid;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void updateOrders(int idOrder, int custid, int invid, int quantity, int price) {
        this.idOrder = idOrder;
        this.custid = custid;
        this.invid = invid;
        this.quantity = quantity;
        this.price = price;
    }
    
    public OrdersModel(int idOrder, int custid, int invid, int quantity, int price) {
        this.idOrder = idOrder;
        this.custid = custid;
        this.invid = invid;
        this.quantity = quantity;
        this.price = price;
    }

    public OrdersModel() {
    }

 
    
}
