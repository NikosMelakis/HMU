package pkg3ergaskhsh;

import java.sql.*;
import javax.swing.DefaultComboBoxModel;

public class OrderMod2 extends DefaultComboBoxModel<String> {

    public OrderMod2(Connection con) {
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String query = "SELECT * FROM inventory";
            rs = stmt.executeQuery(query);
        } catch (SQLException e) {
            System.out.println("OrderMod2: " + e.getMessage());
        }
    }

    @Override
    public String getElementAt(int index) {
        String lstn = null;
        try {
            rs.absolute(index + 1);
            lstn = rs.getString("category") + ", " + rs.getString("description") + ", " + rs.getInt("price")
                    + ", " + rs.getInt("idinv");
            
            Order.price = rs.getInt("price");
            
            Order.inventoryModel.updateInventory(rs.getInt("idinv"), rs.getString("category"),
                                                 rs.getString("description"), rs.getInt("price"), rs.getInt("quantity"));
        } catch (SQLException e) {
            System.out.println("getElementAt(): " + e.getMessage());
        }
        return lstn;
    }

    @Override
    public int getSize() {
        int cnt = 0;

        try {
            rs.last();
            cnt = rs.getRow();
        } catch (SQLException ex) {
            System.out.println("getSize(): " + ex.getMessage());
        }
        return cnt;
    }

    private Statement stmt;
    private ResultSet rs;
}
