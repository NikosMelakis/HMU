package proodos;

import javax.swing.*;
import java.awt.*;

public class FormPanel extends JPanel {

    public FormPanel() {
        setLayout(new GridLayout(4, 4));
        initComponents();
    }

    private void initComponents() {
        luser = new JLabel("*Username: ", JLabel.RIGHT);
        lfn = new JLabel("*First Name: ", JLabel.RIGHT);        
        lpass = new JLabel("*Password: ", JLabel.RIGHT);
        lln = new JLabel("*Last name: ", JLabel.RIGHT);        
        lemail = new JLabel("*E-mail: ", JLabel.RIGHT);
        lage = new JLabel("Age: ", JLabel.RIGHT);
        ltel = new JLabel("Telephone: ", JLabel.RIGHT);
        laddr = new JLabel("Address: ", JLabel.RIGHT);

        tuser = new JTextField();
        tfn = new JTextField();
        tpass = new JTextField();
        tln = new JTextField();
        temail = new JTextField();
        tage = new JTextField();
        ttel = new JTextField();
        taddr = new JTextField();

        add(luser);
        add(tuser);
        add(lfn);
        add(tfn);
        add(lpass);
        add(tpass);
        add(lln);
        add(tln);
        add(lemail);
        add(temail);
        add(lage);
        add(tage);
        add(ltel);
        add(ttel);
        add(laddr);
        add(taddr);
    }

    public JTextField getTuser() {
        return tuser;
    }

    public JTextField getTfn() {
        return tfn;
    }

    public JTextField getTpass() {
        return tpass;
    }

    public JTextField getTln() {
        return tln;
    }

    public JTextField getTemail() {
        return temail;
    }

    public JTextField getTage() {
        return tage;
    }

    public JTextField getTtel() {
        return ttel;
    }

    public JTextField getTaddr() {
        return taddr;
    }

    private JLabel     luser, lfn, lpass, lln, lemail, lage, ltel, laddr;
    private JTextField tuser, tfn, tpass, tln, temail, tage, ttel, taddr;
}