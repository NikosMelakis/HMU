package proodos;

import java.awt.event.*;

public class ExitListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent ae) {
        System.exit(0);
    }
}