package proodos;

import javax.swing.*;
import java.awt.*;

public class CentralPanel extends JPanel {

    public CentralPanel(JFrame f) {
        this.f=f;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        fp = new FormPanel();
        bp = new ButtonPanel((FormPanel) fp, f);
        infoLabel = new JLabel("<html><font color=red>Fields with asterisk(*) are mandatory</font></html>", JLabel.CENTER);
        add(infoLabel, BorderLayout.NORTH);
        add(fp);
        add(bp, BorderLayout.SOUTH);

    }

    private JLabel infoLabel;
    private JPanel fp, bp;
    private JFrame f;
}
