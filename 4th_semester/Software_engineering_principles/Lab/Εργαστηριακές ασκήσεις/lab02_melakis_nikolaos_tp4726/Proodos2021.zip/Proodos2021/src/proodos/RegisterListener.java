package proodos;

import javax.swing.*;
import java.awt.event.*;

public class RegisterListener implements ActionListener {

    public RegisterListener(JFrame f, JTextField tuser, JTextField tfn, JTextField tpass, JTextField tln, JTextField temail, JTextField tage, JTextField ttel, JTextField taddr) {
        this.f=f;
        this.tuser = tuser;
        this.tfn = tfn;
        this.tpass = tpass;
        this.tln = tln;
        this.temail = temail;
        this.tage = tage;
        this.ttel = ttel;
        this.taddr = taddr;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (tuser.getText().trim().isEmpty()) {   
//      if (tuser.getText().isBlank()) 
            JOptionPane.showMessageDialog(f, "You have to enter a Username!", "Input Error", JOptionPane.ERROR_MESSAGE);
        } else if (tfn.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(f, "You have to enter a First Name!", "Input Error", JOptionPane.ERROR_MESSAGE);
        } else if (tpass.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(f, "You have to enter a Password!", "Input Error", JOptionPane.ERROR_MESSAGE);
        } else if (tln.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(f, "You have to enter a Last Name!", "Input Error", JOptionPane.ERROR_MESSAGE);
        } else if (temail.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(f, "You have to enter an Email!", "Input Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(f, "Registration complete!", "Message", JOptionPane.INFORMATION_MESSAGE);
            tuser.setText(null);
            tfn.setText(null);
            tpass.setText(null);
            tln.setText(null);
            temail.setText(null);
            tage.setText(null);
            ttel.setText(null);
            taddr.setText(null);
        }
    }

    private JTextField tuser, tfn, tpass, tln, temail, tage, ttel, taddr;
    private JFrame f;
}
