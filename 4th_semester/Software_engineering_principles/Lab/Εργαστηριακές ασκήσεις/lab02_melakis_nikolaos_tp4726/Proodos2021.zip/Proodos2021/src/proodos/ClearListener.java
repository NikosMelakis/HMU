package proodos;

import javax.swing.*;
import java.awt.event.*;

public class ClearListener implements ActionListener {

    public ClearListener(JTextField tuser, JTextField tfn, JTextField tpass, JTextField tln, JTextField temail, JTextField tage, JTextField ttel, JTextField taddr) {
        this.tuser=tuser;
        this.tfn=tfn;
        this.tpass=tpass;
        this.tln=tln;
        this.temail=temail;
        this.tage=tage;
        this.ttel=ttel;
        this.taddr=taddr;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        tuser.setText(null);
        tfn.setText(null);
        tpass.setText(null);
        tln.setText(null);
        temail.setText(null);
        tage.setText(null);
        ttel.setText(null);
        taddr.setText(null);
    }
    
    private JTextField tuser, tfn, tpass, tln, temail, tage, ttel, taddr;   
}
