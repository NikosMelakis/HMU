package proodos;

public class MainClass{

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RegistrationFrame().setVisible(true);
            }
        });
    }
}