package proodos;

import javax.swing.*;

public class ButtonPanel extends JPanel {
    public ButtonPanel(FormPanel fp, JFrame f){
        this.fp=fp;
        this.f=f;
        initComponents();
    }
    
    private void initComponents(){
        btnClr = new JButton("Clear");
        btnClr.addActionListener(new ClearListener(fp.getTuser(), fp.getTfn(), fp.getTpass(), fp.getTln(), fp.getTemail(), fp.getTage(), fp.getTtel(), fp.getTaddr()));        
        btnReg = new JButton("Register");
        btnReg.addActionListener(new RegisterListener(f, fp.getTuser(), fp.getTfn(), fp.getTpass(), fp.getTln(), fp.getTemail(), fp.getTage(), fp.getTtel(), fp.getTaddr()));
        btnExit = new JButton("Exit");
        btnExit.addActionListener(new ExitListener());
        add(btnClr);
        add(btnReg);        
        add(btnExit);       
    }
    
    private JButton btnReg, btnExit, btnClr;
    private FormPanel fp; 
    private JFrame f;
}
