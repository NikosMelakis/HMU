package proodos;

import javax.swing.*;

public class RegistrationFrame extends JFrame {
    
    public RegistrationFrame(){
        super("Register");
        initComponents();
    }
    
    private void initComponents() {        
        add(new CentralPanel(this));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }
}