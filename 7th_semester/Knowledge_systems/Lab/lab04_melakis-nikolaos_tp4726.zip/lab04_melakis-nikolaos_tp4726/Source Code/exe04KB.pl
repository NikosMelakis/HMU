%Knownledge Base for exe04
%rule(Rid, values(Fever, Cough, Perspiration, Hemoptysis), RF, RP).

rule_flu(A):-
    Prior=0.5,
    LS=1.8,
    O_Flu is Prior/(1- Prior),
    O_H_Flu is LS*O_Flu,
    A is (O_H_Flu)/(1+O_Flu).

rule_pneumonia(A):-
    Prior=0.5,
    LS=1.2,
    O_pneumonia is Prior/(1- Prior),
    O_H_pneumonia is LS*O_pneumonia,
    A is (O_H_pmeumonia)/(1+O_pmeumonia).


rule(rid1, values(yes, no, no, no), RF, RP):-
    LN=0.6,
    rule_flu(Prior),
    O_Flu is Prior/(1-Prior),
    O_H_Flu is LN * O_Flu,
    RF is (O_H_Flu)/(1+O_H_Flu),
    RP is 1- RF.

rule(rid2, values(yes, yes, no, no), RF, RP):-
    LS=1.2,
    rule_pneumonia(Prior),
    O_pneumonia is Prior/(1-Prior),
    O_H_pneumonia is LN * O_pneumonia,
    RP is (O_H_pneumonia)/(1+O_H_pneumonia),
    RF is 1- RP.

rule(rid3, values(yes, no, yes, no), RF, RP):-
    LN=0.8,
    rule_flu(Prior),
    O_Flu is Prior/(1-Prior),
    O_H_Flu is LN * O_Flu,
    RF is (O_H_Flu)/(1+O_H_Flu),
    RP is 1- RF.


rule(rid4, values(yes, yes, no, yes), RF, RP):-
    LS=2.7,
    rule_pneumonia(Prior),
    O_pneumonia is Prior/(1-Prior),
    O_H_pneumonia is LN * O_pneumonia,
    RP is (O_H_pneumonia)/(1+O_H_pneumonia),
    RF is 1- RP.

rule(rid5, values(yes, no, yes, no), RF, RP):-
    LN=0.8,
    rule(rid1,_,Prior,_),
    O_Flu is Prior/(1-Prior),
    O_H_Flu is LN * O_Flu,
    RF is (O_H_Flu)/(1+O_H_Flu),
    RP is 1- RF.

rule(rid6, values(yes, yes, no, yes), RF, RP):-
    LS=2.7,
    rule(rid2,_,Prior,_),
    O_pneumonia is Prior/(1-Prior),
    O_H_pneumonia is LN * O_pneumonia,
    RP is (O_H_pneumonia)/(1+O_H_pneumonia),
    RF is 1- RP.