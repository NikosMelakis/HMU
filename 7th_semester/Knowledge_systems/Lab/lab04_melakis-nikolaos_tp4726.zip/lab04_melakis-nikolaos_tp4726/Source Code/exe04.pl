%Nikolaos Melakis TP4726
%Ergasthrio 4 Erwthsh 4 


:- include('exe04KB.pl').                                   %Loading KB

%Source Code
begin:-
    write('MAIN MENU (Type 1 or 2)'), nl,                   %Main Menu
    write('1| Diagnosis'), nl,
    write('2| Exit'), nl,
    read(Start), nl,
    launch(Start).

launch(1):-                                                 
    main.
launch(2):-
    closed.
launch(X):-
    write('Wrong Input! Try again.'), nl, nl,               %Escape in case of any other input exept 1 or 2.
    begin.

closed:-
    write('--Program Terminated--').                        %Program Closes


main:-
    write('Does the patient have fever? (yes/no)'), nl,
    read(Fever),
    write('Does the patient cough? (yes/no)'), nl,
    read(Cough),    
    write('Does the patient hava perspiration? (yes/no)'), nl,
    read(Perspiration),    
    write('Does the patient have hemoptysis? (yes/no)'), nl,
    read(Hemoptysis),
    rule(Rid, values(Fever, Cough, Perspiration, Hemoptysis), RF, RP),
    write('Patient propability to have a flu is '), format('~2f%~n', [RF*100]),
    write('Patient propability to have a pneumonia is '), format('~2f%~n', [RP*100]), nl, 
    begin.

%Transcript
% ?- begin.
% MAIN MENU (Type 1 or 2)
% 1| Diagnosis
% 2| Exit
% |: 1.

% Does the patient have fever? (yes/no)
% |: yes.
% Does the patient cough? (yes/no)
% |: no.
% Does the patient hava perspiration? (yes/no)
% |: no.
% Does the patient have hemoptysis? (yes/no)
% |: no.
% Patient propability to have a flu is 84.38%
% Patient propability to have a pneumonia is 15.62%

% MAIN MENU (Type 1 or 2)
% 1| Diagnosis
% 2| Exit
% |: 1.

% Does the patient have fever? (yes/no)
% |: yes.
% Does the patient cough? (yes/no)
% |: no.
% Does the patient hava perspiration? (yes/no)
% |: yes.
% Does the patient have hemoptysis? (yes/no)
% |: no.
% Patient propability to have a flu is 87.80%
% Patient propability to have a pneumonia is 12.20%

% MAIN MENU (Type 1 or 2)
% 1| Diagnosis
% 2| Exit
% |: 2.

% --Program Terminated--