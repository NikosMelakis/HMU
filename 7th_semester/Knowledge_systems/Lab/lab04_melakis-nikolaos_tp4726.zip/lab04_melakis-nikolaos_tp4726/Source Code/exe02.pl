%Nikolaos Melakis TP4726
%Ergasthrio 4 Erwthsh 2 

%Source Code
begin:-
    write('MAIN MENU (Type 1 or 2)'), nl,                   %Main Menu
    write('1| Start Program'), nl,
    write('2| Exit'), nl,
    read(Start), nl,
    launch(Start).

launch(1):-                                                 %Actions depending on users input
    select_course.
launch(2):-
    closed.
launch(X):-
    write('Wrong Input! Try again.'), nl, nl,               %Escape in case of any other input despite the options
    begin.

closed:-
    write('--Program Terminated--').                        %Program Closes


select_course:-
    write('Select a course: (Type 1/2/3 or 4)'), nl,        %Choosing course
    write('1| AI'), nl,
    write('2| System Knownledge'), nl,
    write('3| Logic Programming'), nl,
    write('4| Return Main Menu'), nl,
    read(Course), nl,
    course_select(Course).

course_select(1):-                                          %Actions depending on users input
    ai.
course_select(2):-
    sk.
course_select(3):-
    lp.
course_select(4):-
    begin.
course_select(X):-
    write('Wrong Input! Try again'), nl,                    %Escape in case of any other input despite the options
    select_course.

ai:-
    write('Artificial Inteligence'), nl,                    %ai menu for rates 
    write('Type rate of male students(%): '), nl,
    read(M),
    write('Type rate of female students(%): '), nl,
    read(F),
    write('Type success rate of male students(%): '), nl,
    read(Mp),
    write('Type success rate of female students(%): '), nl,
    read(Fp),
    bayes_calc(M, F, Mp, Fp).

sk:-
    write('System Knownledge'), nl,                         %sk menu for rates 
    write('Type rate of male students(%): '), nl,
    read(M),
    write('Type rate of female students(%): '), nl,
    read(F),
    write('Type success rate of male students(%): '), nl,
    read(Mp),
    write('Type success rate of female students(%): '), nl,
    read(Fp),
    bayes_calc(M, F, Mp, Fp).

lp:-
    write('Logic Programming'), nl,                         %lp menu for rates 
    write('Type rate of male students(%): '), nl,
    read(M),
    write('Type rate of female students(%): '), nl,
    read(F),
    write('Type success rate of male students(%): '), nl,
    read(Mp),
    write('Type success rate of female students(%): '), nl,
    read(Fp),
    bayes_calc(M, F, Mp, Fp).


bayes_calc(M, F, Mp, Fp):-                                          %Calc the probability function
    write('Propability to be a male student that passed is: '),     %Equation for propability to be a male student that passed 
    PMp is ((M*Mp)/((M*Mp)+(F*Fp)))*100,                            %P(A1|B)=(P(A1)*P(B|A1)) / ((P(A1)*P(B|A1)) + (P(A2)*P(B|A2)))          %The above type in prolog follows as shown on the left
    format('~2f%~n', [PMp]),                                                          
    write('Propability to be a female student that passed is: '),   %Equation for propability to be a male student that passed 
    PFp is ((F * Fp) / ((M * Mp) + (F * Fp)))*100,                  %P(A2|B)=(P(A2)*P(B|A2)) / ((P(A1)*P(B|A1)) + (P(A2)*P(B|A2)))           %The above type in prolog follows as      
    format('~2f%~n', [PFp]),                      
    select_course.                                                  %Return to course selection

%Transcript
% ?- begin.
% MAIN MENU (Type 1 or 2)
% 1| Start Program
% 2| Exit
% |: 1.

% Select a course: (Type 1/2/3 or 4)
% 1| AI
% 2| System Knownledge
% 3| Logic Programming
% 4| Return Main Menu
% |: 2.

% System Knownledge
% Type rate of male students(%): 
% |: 60.
% Type rate of female students(%): 
% |: 40.
% Type success rate of male students(%): 
% |: 40.
% Type success rate of female students(%): 
% |: 30.
% Propability to be a male student that passed is: 66.67%
% Propability to be a female student that passed is: 33.33%
% Select a course: (Type 1/2/3 or 4)
% 1| AI
% 2| System Knownledge
% 3| Logic Programming
% 4| Return Main Menu
% |: 4.

% MAIN MENU (Type 1 or 2)
% 1| Start Program
% 2| Exit
% |: 2.

% --Program Terminated--
% true .