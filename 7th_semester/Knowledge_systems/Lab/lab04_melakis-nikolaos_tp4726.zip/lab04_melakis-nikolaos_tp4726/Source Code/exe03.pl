%Nikolaos Melakis TP4726
%Ergasthrio 4 Erwthsh 3 


%Source Code
%Main Menu
begin:-
    write('MAIN MENU (Type 1 or 2)'), nl,                   
    write('1| Start Program'), nl,
    write('2| Exit'), nl,
    read(Start), nl,
    launch(Start).

launch(1):-                                                 
    main.
launch(2):-
    closed.
launch(X):-
    write('Wrong Input! Try again.'), nl, nl,               %Escape in case of any other input exept 1 or 2.
    begin.

closed:-
    write('--Program Terminated--').                        %Program Closes

main:-
    write('Type P(H): '), nl,
    read(Ph),
    PnotH is 1 - Ph,
    write('Type P(E|H): '), nl,
    read(Peh),
    write('Type P(E|notH): '), nl,
    read(PenotH),
    Phe is ((Peh * Ph)/((Peh*Ph)+(PenotH*PnotH)))*100,
    write('Probability a patient with no flavor to have covid is: '), format('~2f%~n', [Phe]),
    write('Do you have new inputs? (Type 1/2)'), nl,
    write('1| Yes'), nl,
    write('2| No'), nl,
    read(Ans), nl,
    act(Ans).

act(1):-
    main.
act(2):-
    closed.


%Transcript
% ?- begin.
% MAIN MENU (Type 1 or 2)
% 1| Start Program
% 2| Exit
% |: 1.

% Type P(H): 
% |: 0.35.
% Type P(E|H): 
% |: 0.7.
% Type P(E|notH): 
% |: 0.05.
% Probability a patient with no flavor to have covid is: 88.29%
% Do you have new inputs? (Type 1/2)
% 1| Yes
% 2| No
% |: 2.

% --Program Terminated--