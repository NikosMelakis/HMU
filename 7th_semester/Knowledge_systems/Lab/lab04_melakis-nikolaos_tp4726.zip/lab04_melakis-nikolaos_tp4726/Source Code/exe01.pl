%Nikolaos Melakis TP4726
%Ergasthrio 4 Erwthsh 1 


%Source Code
begin:-
    write('PROGRAM TO CALCULATE WORKERS PERCENT IN CRETE BASED ON DEPARTMENTS (Type 1 or 2)'), nl,                    %Menu
    write('1| Start Program'), nl,
    write('2| Exit'), nl,
    read(Start), nl,
    launch(Start).

launch(1):-                                                 %Actions depending on users input
    pop.
launch(2):-
    closed.
launch(X):-
    write('Wrong Input! Try again.'), nl, nl,               %Escape in case of any other input exept 1 or 2.
    begin.

closed:-
    write('--Program Terminated--').                        %Program Closes

pop:-
    write('POPULATION IN CRETE'), nl,                       %Typing population of crete menu
    write('Type Population for Chania: '), nl,
    read(CHQpop), CHQ is (CHQpop * 0.25), 
    write('Type Population for Rethymno: '), nl,
    read(RTHpop), RTH is (RTHpop * 0.13),
    write('Type Population for Heraklion: '), nl,
    read(HERpop), HER is (HERpop * 0.50),
    write('Type Population for Lasithi: '), nl,
    read(LASpop), LAS is (LASpop * 0.12),
    CretePop is CHQpop+RTHpop+HERpop+LASpop,
    write('Population in Crete is: '), write(CretePop), nl, nl,


    write('Select a department: (Type 1/2/3 or 4)'), nl,    %Choosing working field to analyze the statistics
    write('1| Tourism'), nl,
    write('2| Education'), nl,
    write('3| Informatics'), nl,
    write('4| Agriculture'), nl,
    write('5| Return to Menu'), nl,
    read(Dept), nl,
    choice(Dept, CHQ, CHQpop, RTH, RTHpop, HER, HERpop, LAS, LASpop).

choice(1, CHQ, CHQpop, RTH, RTHpop, HER, HERpop, LAS, LASpop):-
    write('Percent of workers in Tourism'), nl,                        %Typing percent of workers in crete menu
    write('Type percent for Chania(%): '), nl,
    read(CHQper), CHQper1 is (CHQper * 0.1),
    write('Type percent for Rethymno(%): '), nl,
    read(RTHper),RTHper1 is (RTHper * 0.1),
    write('Type percent for Heraklion(%): '), nl,
    read(HERper), HERper1 is (HERper * 0.1),
    write('Type percent for Lasithi(%): '), nl,
    read(LASper), LASper1 is (LASper * 0.1),
    CHQresult is (CHQ * CHQper1)*0.00001,
    RTHresult is (RTH * RTHper1)*0.00001,
    HERresult is (HER * HERper1)*0.00001,
    LASresult is (LAS * LASper1)*0.00001,
    CreteResult is (CHQresult+RTHresult+HERresult+LASresult),
    write('The departments results in Crete is: '), format('~2f%~n', [CreteResult]), nl,
    retry.

choice(2, CHQ, CHQpop, RTH, RTHpop, HER, HERpop, LAS, LASpop):-
    write('Percent of workers in Education'), nl,                        %Typing percent of workers in crete menu
    write('Type percent for Chania(%): '), nl,
    read(CHQper), CHQper1 is (CHQper * 0.1),
    write('Type percent for Rethymno(%): '), nl,
    read(RTHper),RTHper1 is (RTHper * 0.1),
    write('Type percent for Heraklion(%): '), nl,
    read(HERper), HERper1 is (HERper * 0.1),
    write('Type percent for Lasithi(%): '), nl,
    read(LASper), LASper1 is (LASper * 0.1),
    CHQresult is (CHQ * CHQper1)*0.00001,
    RTHresult is (RTH * RTHper1)*0.00001,
    HERresult is (HER * HERper1)*0.00001,
    LASresult is (LAS * LASper1)*0.00001,
    CreteResult is (CHQresult+RTHresult+HERresult+LASresult),
    write('The departments results in Crete is: '), format('~2f%~n', [CreteResult]), nl,
    retry.

choice(3, CHQ, CHQpop, RTH, RTHpop, HER, HERpop, LAS, LASpop):-
    write('Percent of workers in Informatics'), nl,                        %Typing percent of workers in crete menu
    write('Type percent for Chania(%): '), nl,
    read(CHQper), CHQper1 is (CHQper * 0.1),
    write('Type percent for Rethymno(%): '), nl,
    read(RTHper),RTHper1 is (RTHper * 0.1),
    write('Type percent for Heraklion(%): '), nl,
    read(HERper), HERper1 is (HERper * 0.1),
    write('Type percent for Lasithi(%): '), nl,
    read(LASper), LASper1 is (LASper * 0.1),
    CHQresult is (CHQ * CHQper1)*0.00001,
    RTHresult is (RTH * RTHper1)*0.00001,
    HERresult is (HER * HERper1)*0.00001,
    LASresult is (LAS * LASper1)*0.00001,
    CreteResult is (CHQresult+RTHresult+HERresult+LASresult),
    write('The departments results in Crete is: '), format('~2f%~n', [CreteResult]), nl,
    retry.

choice(4, CHQ, CHQpop, RTH, RTHpop, HER, HERpop, LAS, LASpop):-
    write('Percent of workers in Agriculture'), nl,                        %Typing percent of workers in crete menu
    write('Type percent for Chania(%): '), nl,
    read(CHQper), CHQper1 is (CHQper * 0.1),
    write('Type percent for Rethymno(%): '), nl,
    read(RTHper),RTHper1 is (RTHper * 0.1),
    write('Type percent for Heraklion(%): '), nl,
    read(HERper), HERper1 is (HERper * 0.1),
    write('Type percent for Lasithi(%): '), nl,
    read(LASper), LASper1 is (LASper * 0.1),
    CHQresult is (CHQ * CHQper1)*0.001,
    RTHresult is (RTH * RTHper1)*0.001,
    HERresult is (HER * HERper1)*0.001,
    LASresult is (LAS * LASper1)*0.001,
    CreteResult is (CHQresult+RTHresult+HERresult+LASresult),
    write('The departments results in Crete is: '), format('~2f%~n', [CreteResult]), nl,
    retry.

choice(5, CHQ, CHQpop, RTH, RTHpop, HER, HERpop, LAS, LASpop):-
    begin.

choice(X, CHQ, CHQpop, RTH, RTHpop, HER, HERpop, LAS, LASpop):-
    write('Wrong Input! Try Again.'), nl, nl,
    pop.

retry:-
    write('Do you have new inputs? (yes/no)'), nl,
    read(Ans),
    retrying(Ans).

retrying(yes):-
    pop.

retrying(no):-
    closed.

retrying(X):-
    write('Wrong Input! Try again.'), nl, nl,               %Escape in case of any other input exept 1 or 2.
    retry.




?- begin.
PROGRAM TO CALCULATE WORKERS PERCENT IN CRETE BASED ON DEPARTMENTS (Type 1 or 2)
1| Start Program
2| Exit
|: 1.

POPULATION IN CRETE
Type Population for Chania: 
|: 150000.
Type Population for Rethymno: 
|: 75000.
Type Population for Heraklion: 
|: 300000.
Type Population for Lasithi: 
|: 60000.
Population in Crete is: 585000

Select a department: (Type 1/2/3 or 4)
1| Tourism
2| Education
3| Informatics
4| Agriculture
5| Return to Menu
|: 3.

Percent of workers in Informatics
Type percent for Chania(%): 
|: 20.
Type percent for Rethymno(%): 
|: 13.
Type percent for Heraklion(%): 
|: 30.
Type percent for Lasithi(%): 
|: 12.
The departments results in Crete is: 5.46%

Do you have new inputs? (yes/no)
|: no.
--Program Terminated--