%Nikolaos Melakis TP4726
%Ergasia 5

%What the code does

%Creates or load an RDF to memory
%Adds new elements in RDF
%Delete elements from RDF
%Preview the whole RDF
%Saves all changes and exiting


%Note
%When creating a new rdf file the name is createdNow.rdf
%When inserting new data in rdf the rdf name is data.rdf
%---------------------------------

%Source Code

%Dynamic integer num
:- dynamic(atom_number/1).

%Libraries for RDF
:-use_module(library(rdf)).
:-use_module(library(semweb/rdf_db)). 
:-use_module(library(semweb/rdf_http_plugin)).
:-use_module(library(semweb/turtle)).

%Libraries for Web
:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_error)).
:- use_module(library(http/html_write)).
:- use_module(library(http/http_client)).


%HTML Pages
:- http_handler('/', webForm, []).                          %Main Page
:- http_handler('/loadCreate', loadCreate, []).             %Load create RDF page
:- http_handler('/load', load, []).                         %Handler to load RDF
:- http_handler('/create', create, []).                     %Handler to create RDF
:- http_handler('/importValues', importValues, []).         %Add new values in RDF
:- http_handler('/addData', addData, []).                   %Handler to add the data
:- http_handler('/seeAll', seeAll, []).                     %Page to print all RDF data
:- http_handler('/seeIssued', seeIssued, []).               %Page to print only spirometry<5
:- http_handler('/deleteFromGraph', deleteFromGraph, []).   %Delete a triple from graph
:- http_handler('/deleteData', deleteData, []).             %Handler to delete data
:- http_handler('/exit', exit, []).                         %Save and Exit 


%Setting preefered localohost port
:- server(8008).

server(Port) :-
    http_server(http_dispatch, [port(Port)]).

webForm(_Request) :-
    reply_html_page(
        title('TP4726'),                %Title
    [
        h3([],[                         %Webpage Header
            'Main Menu'
        ]),
        p([],[                          %Webpage Paragraph
            'OPTIONS'
        ]),
        form([action='/loadCreate'],    %Main Menu Form
            [ 
                p([], input([name=loadCreate, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Load/Create RDF'], [])) 
            ]
        ),
        form([action='/importValues'],  
            [ 
                p([], input([name=importValues, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Import New Lab Values'], [])) 
            ]
        ),
        form([action='/seeAll'],  
            [ 
                p([], input([name=seeAll, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='See All Lab Values'], [])) 
            ]
        ),
        form([action='/seeIssued'],  
            [ 
                p([], input([name=seeIssued, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='See Issued Lab Values'], [])) 
            ]
        ),
        form([action='/deleteFromGraph'],  
            [ 
                p([], input([name=deleteFromGraph, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Delete From Graph'], [])) 
            ]
        ),
        form([action='/exit'], 
            [ 
                p([], input([name=exit, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Save And Exit'], [])) 
            ]
        )
    ]
).

%Load Create RDF 
loadCreate(_Request):-
    reply_html_page(
        title('TP4726'),            %Title
    [
        h3([],[                     %Webpage Header
            'RDF Options'
        ]),
        p([],[                      %Webpage Paragraph
            ''
        ]),
        form([action='/load'],      %Load Create RDF Menu
            [ 
                p([], input([name=loadCreate, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Load RDF'], [])) 
            ]
        ),
        form([action='/create'],  
            [ 
                p([], input([name=importValues, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Create RDF'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        )
    ]
).

%Load RDF
load(_Request):-    
    reply_html_page(
        title('TP4726'),            %Title
    [
        h3([],[                     %Webpage Header
            'RDF Loaded'
        ]),
        p([],[                      %Webpage Paragraph
            ''
        ]),
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        )
    ]
    ),
    rdfLoad.

rdfLoad:-
    rdf_load('/Users/nikos-melakis/Desktop/data.rdf').


%Create RDF
create(_Request):-    
    reply_html_page(
        title('TP4726'),            %Title
    [
        h3([],[                     %Webpage Header
            'RDF Created'
        ]),
        p([],[                      %Webpage Paragraph
            ''
        ]),
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        )
    ]
    ),
    rdfCreate.

rdfCreate:-
    rdf_save('/Users/nikos-melakis/Desktop/createdNow.rdf').


%Import Values In RDF Menu
importValues(_Request):-
    reply_html_page(
        title('TP4726'),            %Title
    [
        h3([],[                     %Webpage Header
            'Add New Data in the RDF'
        ]),
        p([],[                      %Webpage Paragraph
            ''
        ]),
        form([action='/addData', method='POST'], 
            [ 
                p([], [
                label([for=name],'Full Name '),
                input([name=name, type=textarea, placeholder='e.g. John Doe', style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px; margin: 0px 0px 0px 60px', required])
                ]),
                p([], [
                label([for=spirometryDate],'Spirometry Date '),
                input([name=spirometryDate, type=textarea, placeholder='e.g. 21-12-2022', style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px; margin: 0px 0px 0px 22px', required])
                ]),
                p([], [
                label([for=spirometry],'Spirometry Number '),
                input([name=spirometry, type=number, placeholder='e.g. 6', style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px; margin: 0px 0px 0px 0px', required])
                ]),
                p([], input([name=submit, type=submit, style='background-color: #fff; background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px', value='Add'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        )
    ]
).

%Adding The Data in RDF and Returning Message
addData(Request):-
    reply_html_page(
        title('TP4726'), 
        [
        h3([],[                    %Webpage Header
            'RDF Importing...'
        ]),
        p([],[                     %Webpage Paragraph
            'Data successfully added!'
        ]),
        form([action='/importValues', method='POST'], 
            [ 
                p([], input([name=submit, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px', value='Add New Data'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        )
        ]
    ), 
    member(method(post), Request), !, 
    http_read_data(Request, Data, []),
	format('<p><h3>', []),
    addDataToRDF(Data.name, Data.spirometryDate, Data.spirometry).

addDataToRDF(Name, SpirometryDate, Spirometry):-
    rdf_assert(Name, spirometryDate, SpirometryDate),
    rdf_assert(Name, spirometry, Spirometry),
    rdf_save('/Users/nikos-melakis/Desktop/data.rdf').

%See All Data 
seeAll(_Request):-
    reply_html_page(
        title('TP4726'),            %Title
    [
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        ),
        h3([],[                     %Webpage Header
            'All RDF Data'
        ])
    ]
    ),
    showAll.

showAll:-
    rdf_load('/Users/nikos-melakis/Desktop/data.rdf'),
    bagof([X,Y,Z],rdf(X,Y,Z),L),
    write(L).


%See All Issued Data With Spirometry<5
seeIssued(_Request):-
    reply_html_page(
        title('TP4726'),            %Title
    [
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        ),
        h3([],[                     %Webpage Header
            'Issued RDF Data'
        ])
    ]
    ),
    rdfIssued.

rdfIssued:-
    rdf_load('/Users/nikos-melakis/Desktop/data.rdf'),
    bagof([X,Y,Z],rdf(X,Y,Z),L),
    atom_number(Y), Y<5,
    write(X).


%Delete Data from Graph
deleteFromGraph(_Request):-
    reply_html_page(
        title('TP4726'),            %Title
    [
        h3([],[                     %Webpage Header
            'Delete Data From RDF'
        ]),
        p([],[                      %Webpage Paragraph
            ''
        ]),
        form([action='/deleteData', method='POST'], 
            [ 
                p([], [
                label([for=name],'Type Full Name '),
                input([name=name, type=textarea, placeholder='e.g. John Doe', style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px; margin: 0px 0px 0px 5px', required])
                ]),
                p([], input([name=submit, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px', value='Delete'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        )
    ]
).


deleteData(Request):-
    reply_html_page(
        title('TP4726'),            %Title
    [
        h3([],[                     %Webpage Header
            'Deleting...'
        ]),
        p([],[                      %Webpage Paragraph
            ''
        ]),
        form([action='/deleteFromGraph'], 
            [
                p([], input([name=submit, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; padding: 5px', value='Delete Another'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=menu, type=submit, style='background-color: #fff; border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Main Menu'], [])) 
            ]
        )
    ]
    ),
    member(method(post), Request), !, 
    http_read_data(Request, Data, []),
	format('<p><h3>', []),
    deleteDataRDF(Data.name).

deleteDataRDF(Name):-
    rdf_retractall(Name, Y, Z),
    rdf_save('/Users/nikos-melakis/Desktop/data.rdf').



%Close Program
exit(_Request):-
    reply_html_page(
        title('TP4726'),            %Title
    [
        h3([],[                     %Webpage Header
            'Program Closing...'
        ]),
        p([],[                      %Webpage Paragraph
            'Applying Changes And Terminating The Program'
        ])
    ]
    ),
    closeProgram.

closeProgram:-
    rdf_save('/Users/nikos-melakis/Desktop/data.rdf').