%Nikolaos Melakis TP4726

:-
    dynamic_rule/3,
    dynamic xcounter/1.

:-
    include('KB.pl').

begin:-
    write('Main Menu Options (Type 1/2/3): '), nl,
    write('1. Problem diagnosis.'), nl,
    write('2. Update the KS.'), nl,
    write('3. Exit.'), nl,
    read(Option), nl,
    options(Option).

options(1):-
    diagnosis.
options(2):-
    update.
options(3):-
    closed.
options(X):-
    write('Wrong Input! Try again.'), nl,
    begin.

closed:-
    write('--Programm Ended--').

diagnosis:- 
    write('Are there any lab values? (yes/no): '),nl , 
    read(Data),
    ((Data=yes , write('Give Saturation in dissolved oxygen (%): ') ,nl, read(Saturation_in_dissolved_oxygen) ,(
        (Saturation_in_dissolved_oxygen>=20, rule(Rule,(Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer));
        (write('Has NO3? (yes/no): '),nl , read(Has_NO3) , rule(Rule,(Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer)
    )));
    (Data = no , write('Existence of red oligochaetes (no/few/many): '),nl , read(Existence_of_red_oligochaetes) , (
        ((Existence_of_red_oligochaetes=many ; Existence_of_red_oligochaetes=few) , rule(Rule,(Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer)); 
        (Existence_of_red_oligochaetes = no ,write('Existence of sediments (black/dark/light): '),nl , read(Existance_of_sediments), (
            (Existance_of_sediments = light , write('What is the press substrate (regular/medium/large): '),nl , read(Press_substrate), (
                (Press_substrate = regular , write('Does the water smells bad? (yes/no): '),nl, read(Water_smell), 
                    rule(Rule,(Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer) ); 
                (rule(Rule,(Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer)) 
            ));
            (write('Does H2S exists? (yes/no): '),nl, read(Existence_H2S) , (
                (Existence_H2S=no , write('Does CH4 exists? (yes/no): '),nl,read(Existance_CH4) ,
                    rule(Rule,(Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer)); 
                (rule(Rule,(Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer)
            ))
        ))
    )))),
    write(Answer), nl,
    begin.

update:-
    write('Knowledge Base UPDATE {Menu}. (Type 1/2/3/4): '), nl,
    write('1. Delete a rule.'), nl,
    write('2. Add a new rule.'), nl,
    write('3. Modify an existing rule.'), nl,
    write('4. Save.'), nl,
    write('5. Return to Main Menu.'), nl,
    read(KbOption), nl,
    kboption(KbOption).

kboption(1):-
    write('Type the ruleId of the rule you want to delete: '), nl,
    read(RuleID), nl,
    retractall(rule(Ruleid,(_,_,_,_,_,_,_,_,_,_))), nl,
    write('Rule was successfully deleted!'), nl,
    update.

kboption(2):-
    write('Type new rule id: '), nl,
    read(RuleID), nl,
    write('Type rule data like: (Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer'),nl,           
    read(Data), nl,
    write('Give rule answer: '), nl,
    read(Answer), nl,
    assertz((rule(rid(RuleID),Data):- Answer)), nl,
    write('New rule was successfully added!'), nl,
    update.

kboption(3):-
    write('Type the ruleId of the rule you want to modify: [rule id remains the same]'), nl,
    read(RuleID), nl,
    write('Type rule data like: (Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer'), nl,
    read(Data), nl,
    write('Give rule answer'), nl,
    read(Answer), nl,
    assertz((rule(rid(RuleID),Data):- Answer)), nl,
    write('New rule was successfully added!'), nl,
    update.

assert_new([H|[H1|T1]]):-
    asserta(rule(H,H1)).

kboption(4):-
    tell('C:/Users/nick_/Documents/KB2.pl'),
    retractall(rule),
    listing(rule),
    told,
    write('Changes successfully saved!'), nl,
    update.

kboption(5):-
    begin.

kboption(X):-
    write('Wrong input! Try again.'), nl,
    update.