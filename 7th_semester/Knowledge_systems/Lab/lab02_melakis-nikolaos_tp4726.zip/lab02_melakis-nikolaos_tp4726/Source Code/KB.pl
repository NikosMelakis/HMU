
%1
rule(rid(1),(yes,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer):- 
    Saturation_in_dissolved_oxygen>=20, 
    Answer='No anoxia problem.'.

%2
rule(rid(2),(yes,Saturation_in_dissolved_oxygen,yes,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer):- 
    Saturation_in_dissolved_oxygen<20, 
    Answer='Severe anoxia problem.'.

%3
rule(rid(3),(yes,Saturation_in_dissolved_oxygen,no,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer):- 
    Saturation_in_dissolved_oxygen<20, 
    Answer='Very severe anoxia problem.'.

%4
rule(rid(4),(no,Saturation_in_dissolved_oxygen,Has_NO3,many,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer):- 
    Answer='Medium anoxia problem'.

%5
rule(rid(5),(no,Saturation_in_dissolved_oxygen,Has_NO3,few,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell),Answer):- 
    Answer='Very severe anoxia problem.'.

%6
rule(rid(6),(no,Saturation_in_dissolved_oxygen,Has_NO3,no,light,Existence_H2S,Existance_CH4,normal,no),Answer):- 
    Answer='No anoxia problem.'.

%7
rule(rid(7),(no,Saturation_in_dissolved_oxygen,Has_NO3,no,light,Existence_H2S,Existance_CH4,normal,yes),Answer):- 
    Answer='Medium anoxia problem.'.

%8
rule(rid(8),(no,Saturation_in_dissolved_oxygen,Has_NO3,no,light,Existence_H2S,Existance_CH4,_,Water_smell),Answer):- 
    Answer='No anoxia problem.'.

%9
rule(rid(9),(no,Saturation_in_dissolved_oxygen,Has_NO3,no,_,no,no,Press_substrate,Water_smell),Answer):- 
    Answer='Severe anoxia problem.'.

%10
rule(rid(10),(no,Saturation_in_dissolved_oxygen,Has_NO3,no,_,no,yes,Press_substrate,Water_smell),Answer):- 
    Answer='Very severe anoxia problem.'.

%11
rule(rid(11),(no,Saturation_in_dissolved_oxygen,Has_NO3,no,_,yes,Existance_CH4,Press_substrate,Water_smell),Answer):- 
    Answer='Very severe anoxia problem.'.