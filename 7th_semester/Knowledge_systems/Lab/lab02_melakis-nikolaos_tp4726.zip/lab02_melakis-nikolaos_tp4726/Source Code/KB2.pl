rule(rid(12), ((yes,_,_,_,_,_,_,_,_),_)) :-
        edited2.
rule(rid(1), ((no,_,_,_,_,_,_,_,_),_)) :-
        rid1moded.

rule(rid(1), (yes,A,_,_,_,_,_,_,_), B) :-
        A>=20,
        B='No anoxia problem.'.
rule(rid(2), (yes,A,yes,_,_,_,_,_,_), B) :-
        A<20,
        B='Severe anoxia problem.'.
rule(rid(3), (yes,A,no,_,_,_,_,_,_), B) :-
        A<20,
        B='Very severe anoxia problem.'.
rule(rid(4), (no,_,_,many,_,_,_,_,_), A) :-
        A='Medium anoxia problem'.
rule(rid(5), (no,_,_,few,_,_,_,_,_), A) :-
        A='Very severe anoxia problem.'.
rule(rid(6), (no,_,_,no,light,_,_,normal,no), A) :-
        A='No anoxia problem.'.
rule(rid(7), (no,_,_,no,light,_,_,normal,yes), A) :-
        A='Medium anoxia problem.'.
rule(rid(8), (no,_,_,no,light,_,_,_,_), A) :-
        A='No anoxia problem.'.
rule(rid(9), (no,_,_,no,_,no,no,_,_), A) :-
        A='Severe anoxia problem.'.
rule(rid(10), (no,_,_,no,_,no,yes,_,_), A) :-
        A='Very severe anoxia problem.'.
rule(rid(11), (no,_,_,no,_,yes,_,_,_), A) :-
        A='Very severe anoxia problem.'.

