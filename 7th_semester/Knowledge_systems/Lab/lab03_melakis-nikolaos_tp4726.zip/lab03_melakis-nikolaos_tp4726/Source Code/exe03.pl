%Nikolaos Melakis Tp41326
%Erwthma 3

:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_error)).
:- use_module(library(http/html_write)).
:- use_module(library(http/http_client)).

:- http_handler('/', web_form, []).
:- http_handler('/diagnosis', diagnosisa, []).
:- http_handler('/update', updatea, []).
:- http_handler('/diagnosisresults', diagnosisr, []).
:- http_handler('/deleterule', deleterulea, []).
:- http_handler('/deletingrule', deletingrulea, []).
:- http_handler('/addrule', addrulea, []).
:- http_handler('/addingrule', addingrulea, []).
:- http_handler('/modifyrule', modifyrulea, []).
:- http_handler('/modifyingrule', modifyingrulea, []).
:- http_handler('/save', savea, []).
:- http_handler('/saving', savinga, []).

:- consult('KB.pl').
:- server(8008).

server(Port) :-
    http_server(http_dispatch, [port(Port)]).

:- server(8008).

web_form(_Request) :-
    reply_html_page(
        title('KS | Main Menu'),   % title
    [
        h2([],[                    % webpage header
            'Knowledge System | Main Menu'
        ]),
        p([],[                     % webpage paragraph
            'OPTIONS'
        ]),
        form([action='/diagnosis'],  % main menu form
            [ 
                p([], input([name=diagnosis, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Diagnonis'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=update, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Update'], [])) 
            ]
        )
    ]
).

diagnosisa(_Request):-
    reply_html_page(
    title('KS | Diagmosis Menu'),   % title
    [
        h2([],[                     % webpage header
            'Knowledge System | Diagnosis Menu'
        ]), 
        p([],[                      % webpage paragraph
            'DIAGNOSIS VALUES'  
        ]),
        form([action='/diagnosisresults', method='POST'],  % form to enter values for diagnosis
            [
            p([], [ label([for=labvals],'Lab values '), 
            select([id=labvals,name=labvals, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'], [option(yes),option(no)])]),

            p([], [ label([for=saturation],'Saturation '),
            input([id=saturation,name=saturation, type=number, placeholder='e.g. 25', style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'])]),

            p([], [ label([for=hasno3],'Has NO3 '),
            select([id=hasno3,name=hasno3, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'],[option(yes),option(no)])]),

            p([], [ label([for=oligochaetes],'Oligochaetes '), 
            select([id=oligochaetes,name=oligochaetes, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'],[option(no),option(few),option(many)])]),

            p([], [ label([for=sediments],'Sediments '), 
            select([id=sediments,name=sediments, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'],[option(black),option(dark),option(light)])]),

            p([], [ label([for=hash2s],'Has H2S '),
            select([id=hash2s,name=hash2s, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'],[option(yes),option(no)])]),

            p([], [ label([for=hasch4],'Has CH4 '),
            select([id=hasch4,name=hasch4, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'],[option(yes),option(no)])]),

            p([], [ label([for=substrate],'Press Substrate '), 
            select([id=substrate,name=substrate, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'],[option(regular),option(medium),option(large)])]),

            p([], [ label([for=swater],'Water smell '), 
            select([id=swater,name=swater, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'],[option(yes),option(no)])]),

            p([], input([name=submit, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Submit'], []))
        ]
        ),
        form([action='/'],   
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Main Menu'], []))        % button to return to main page
            ]
        )
    ] 
).



diagnosisr(Request):-
    member(method(post), Request), !, % getting the data from the diagnosis form 
    http_read_data(Request, Data, []),  % reading data
    checkDia(Data.labvals, Data.saturation, Data.hasno3, Data.oligochaetes, Data.sediments, Data.hash2s, Data.hasch4, Data.substrate, Data.swater). % rgetting data values
    checkDia(LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell):-
        createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList), 
        dia(DataList, Ans),  % getting the answer based on data selected
    
    reply_html_page(
        title('Results'),
        [p([],Ans)],  % printing the answer
        form([action='/diagnosis'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='New Check'], [])) 
            ]
        ) 
    ). 

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case1 labvals=yes, saturation>=20
    LabVals=yes,
    atom_number(Saturation, Sat),
    Sat>=0,
    DataList=[LabVals, saturation, Sat].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case2 labvals=yes, saturation<20 & N03=yes || NO3=n
    LabVals=yes,
    atom_number(Saturation, Sat),
    Sat>=0,
    DataList=[LabVals, saturation, Sat, HasNO3].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case3 labvals=n, Oligochaetes=n, sediments=back || sediments==dark, H2S=yes
    LabVals=no,
    Oligochaetes=no,
    Sediments=black,
    HasH2S=yes,
    DataList=[LabVals, Oligochaetes, Sediments, HasH2S].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case3 labvals=n, Oligochaetes=n, sediments=back || sediments==dark, H2S=yes
    LabVals=no,
    Oligochaetes=no,
    Sediments=dark,
    HasH2S=yes,
    DataList=[LabVals, Oligochaetes, Sediments, HasH2S].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case4 labvals=n, Oligochaetes=n, sediments=back || sediments==dark, H2S=no, CH4=yes
    LabVals=no,
    Oligochaetes=no,
    Sediments=dark,
    HasH2S=no,
    HasCH4=yes,
    DataList=[LabVals, Oligochaetes, Sediments, HasH2S, HasCH4].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case4 labvals=n, Oligochaetes=n, sediments=back || sediments==dark, H2S=no, CH4=yes
    LabVals=no,
    Oligochaetes=no,
    Sediments=black,
    HasH2S=no,
    HasCH4=yes,
    DataList=[LabVals, Oligochaetes, Sediments, HasH2S, HasCH4].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case5 labvals=n, Oligochaetes=n, sediments=back || sediments==dark, H2S=n, CH4=n
    LabVals=no,
    Oligochaetes=no,
    Sediments=black,
    HasH2S=no,
    HasCH4=no,
    DataList=[LabVals, Oligochaetes, Sediments, HasH2S, HasCH4].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case5 labvals=n, Oligochaetes=n, sediments=back || sediments==dark, H2S=n, CH4=n
    LabVals=no,
    Oligochaetes=no,
    Sediments=dark,
    HasH2S=no,
    HasCH4=no,
    DataList=[LabVals, Oligochaetes, Sediments, HasH2S, HasCH4].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case6 labvals=n, Oligochaetes=n, sediments=light, substrate=medium || substrate=large
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=medium,
    DataList=[LabVals, Oligochaetes, Sediments, Substrate].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case6 labvals=n, Oligochaetes=n, sediments=light, substrate=medium || substrate=large
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=large,
    DataList=[LabVals, Oligochaetes, Sediments, Substrate].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case7 labvals=n, Oligochaetes=n, sediments=light, substrate=regular, WaterSmell=n
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=regular,
    WaterSmell=no,
    DataList=[LabVals, Oligochaetes, Sediments, Substrate, WaterSmell].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case8 labvals=n, Oligochaetes=n, sediments=light, substrate=regular, WaterSmell=yes
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=regular,
    WaterSmell=yes,
    DataList=[LabVals, Oligochaetes, Sediments, Substrate, WaterSmell].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case9 labvals=n, Oligochaetes=few
    LabVals=no,
    Oligochaetes=few,
    DataList=[LabVals, Oligochaetes].

createDataList([LabVals, Saturation, HasNO3, Oligochaetes, Sediments, HasH2S, HasCH4, Substrate, WaterSmell], DataList):-   % case13 labvals=n, Oligochaetes=many
    LabVals=no,
    Oligochaetes=many,
    DataList=[LabVals, Oligochaetes].

dia(DataList, Ans):-    % Getting the answer based on the data selected & the rules in KB
    rule(DataList, Ans).

updatea(_Request):-
    reply_html_page(
    title('KS | Update Menu'),   % title
    [
        h2([],[
            'Knowledge System | Update Menu'    % webpage header
        ]),
        p([],[                                  % webpage paragraph
            'OPTIONS'
        ]),
        form([action='/deleterule'],            % action to go to del a rule menu
            [ 
                p([], input([name=deleterule, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Delete a rule'], [])) 
            ]
        ),
        form([action='/addrule'],               % action to go to add a rule menu
            [ 
                p([], input([name=addrule, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Add a new rule'], [])) 
            ]
        ),
        form([action='/modifyrule'],            % action to go to modify a rule menu
            [ 
                p([], input([name=modifyrule, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Modify an existing rule'], [])) 
            ]
        ),
        form([action='/save'],                  % action to go to save a rule menu
            [   
                p([], input([name=save, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Save'], [])) 
            ]
        ),
        form([action='/'],                      % action to go main menu
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Main Menu'], [])) 
            ]
        )
    ]
).



deleterulea(_Request):-
    reply_html_page(
        title('KS | Delete a Rule'),    % title
        [
        h2([],[
            'Knowledge System | Delete a rule menu'    % webpage header
        ]),
        p([],[                                  % webpage paragraph
            'OPTIONS'
        ]),
        form([action='/deletingrule'],            % action to go to delete a rule menu
            [ 
                p([], input([name=deletingrule, type=deletingrule, placeholder='Rule ID', style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'], [])),
                
                p([], input([name=deletebutton, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Delete Rule'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        )
    ]
).

deletingrulea(_Request):-
    reply_html_page(
    title('Knowledge System | Delete a rule menu'),     % title
    [    
        p([],[                                  
            'Rule successfully deleted!'    % printing succession
        ]),   
        form([action='/deleterule'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Delete another rule'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return Main Menu'], [])) 
            ]
        )
    ]
). 

addrulea(_Request):-
    reply_html_page(
        title('KS | Add a Rule'),    % title
        [
        h2([],[
            'Knowledge System | Add a rule menu'    % webpage header
        ]),
        p([],[                                  % webpage paragraph
            'OPTIONS'
        ]),
        form([action='/addingrule'],            % action to go to add a rule menu
            [ 
                p([], input([name=ruleid, type=ruleid, placeholder='Rule ID', style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'], [])),

                p([], input([name=ruledata, type=ruledata, placeholder='Rule Data', style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'], [])),
                
                p([], input([name=deletebutton, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Add Rule'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        )
    ]
).

addingrulea(_Request):-
    reply_html_page(
    title('Knowledge System | Add a rule menu'),     % title
    [    
        p([],[                                  
            'Rule successfully added!'    % printing succession
        ]),   
        form([action='/addrule'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Add another rule'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return Main Menu'], [])) 
            ]
        )
    ]
). 

modifyrulea(_Request):-
    reply_html_page(
        title('KS | Modify a Rule'),    % title
        [
        h2([],[
            'Knowledge System | Modify a rule menu'    % webpage header
        ]),
        p([],[                                  % webpage paragraph
            'OPTIONS'
        ]),
        form([action='/modifyingrule'],            % action to go to modify a rule menu
            [ 
                p([], input([name=ruleid, type=ruleid, placeholder='Rule ID', style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'], [])),

                p([], input([name=ruledata, type=ruledata, placeholder='Rule Data', style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px'], [])),
                
                p([], input([name=deletebutton, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Modify Rule'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        )
    ]
).

modifyingrulea(_Request):-
    reply_html_page(
    title('Knowledge System | Modify a rule menu'),     % title
    [    
        p([],[                                  
            'Rule successfully modified!'    % printing succession
        ]),   
        form([action='/modifyrule'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Modify another rule'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        ),
        form([action='/'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return Main Menu'], [])) 
            ]
        )
    ]
). 

savea(_Request):-
    reply_html_page(
        title('KS | Save a Rule'),    % title
        [
        h2([],[
            'Knowledge System | Save a rule menu'    % webpage header
        ]),
        p([],[                                  % webpage paragraph
            'OPTIONS'
        ]),
        form([action='/saving'],            % action to go to save a rule menu
            [   
                p([], input([name=deletebutton, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Save Changes'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        ),
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        )
    ]
).

savinga(_Request):-
    reply_html_page(
    title('Knowledge System | Save a rule menu'),     % title
    [    
        p([],[                                  
            'Changes successfully saved!'    % printing succession
        ]),   
        form([action='/update'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return to Update Menu'], [])) 
            ]
        ),
                form([action='/'], 
            [ 
                p([], input([name=mainmenu, type=submit, style='border: 1px #000 solid; border-radius: 5px; width: 13%; margin: 5px; padding: 5px', value='Return Main Menu'], [])) 
            ]
        )
    ]
). 