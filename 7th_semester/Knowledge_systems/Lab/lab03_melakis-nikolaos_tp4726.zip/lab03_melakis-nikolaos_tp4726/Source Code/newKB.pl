rule([LabVals, HasNO3], Ans):-
    LabVals=yes, 
    HasNO3=yes,
    Ans = 'Severe anoxia problem.', !. 

rule([LabVals, HasNO3], Ans):-
    LabVals=yes, 
    HasNO3=no,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=black;Sediments=dark,
    HasH2S=yes,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S, HasCH4], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=black;Sediments=dark,
    HasH2S=no,
    HasCH4=yes,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S, HasCH4], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=black;Sediments=dark,
    HasH2S=no,
    HasCH4=no,
    Ans = 'Severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, Substrate], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=medium;Substrate=large,
    Ans = 'No anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, Substrate], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=regular,
    WaterSmell=no,
    Ans = 'No anoxia problem.', !.

rule([LabVals, Oligochaetes, Sediments, Substrate], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=regular,
    WaterSmell=yes,
    Ans = 'Medium anoxia problem.', !.

rule([LabVals, Oligochaetes, Sediments, HasH2S], Ans):-
    LabVals=no,
    Oligochaetes=few,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S], Ans):-
    LabVals=no,
    Oligochaetes=many,
    Ans = 'Medium anoxia problem.', !. 
