%Nikolaos Melakis Tp4726
%Erwthma 1

:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_error)).
:- use_module(library(http/html_write)).
:- use_module(library(http/http_client)).

:- http_handler('/', web_form, []).
:- http_handler('/trinomial', trinomiala, []).

server(8008) :-
    http_server(http_dispatch, [port(8008)]).



web_form(_Request) :-
    reply_html_page(
        title('Trinomial'),   % title
    [
        form([action='/trinomial', method='POST'], 
            [ 
                p([], [
                label([for=a],''),
                input([name=a, type=textarea, placeholder='Value for a', style='border: 1px #000 solid; border-radius: 5px; padding: 5px', required])
                ]),
                p([], [
                label([for=b],''),
                input([name=b, type=textarea, placeholder='Value for b', style='border: 1px #000 solid; border-radius: 5px; padding: 5px', required])
                ]),
                p([], [
                label([for=c],''),
                input([name=c, type=textarea, placeholder='Value for a', style='border: 1px #000 solid; border-radius: 5px; padding: 5px', required])
                ]),
                p([], input([name=submit, type=submit, style='border: 1px #000 solid; border-radius: 5px; padding: 5px', value='SUBMIT'], [])) 
            ]
        )
    ]
).



trinomiala(Request) :-
    reply_html_page(
        title('Trinomial2'), []), 
        member(method(post), Request), !, 
        http_read_data(Request, Data, []),
	format('<p><h3>', []),
    check_trinomial(Data.a,Data.b,Data.c).


check_trinomial(A1,B1,C1):- 											      % trinomial equations
    atom_number(A1,A),												 
    atom_number(B1,B),
    atom_number(C1,C),
    (
        (
            (A=0, B=0, C=0, write('Identity.'), nl,                            % case1a  a=0, b=0, c=0
            write('Degenerate trinomial.'), nl) ; 	

            (A=0, B=0, C\=0, write('Imposible equation.'), nl,                 % case1b a=0, b=0, c!=0
            write('Degenerate trinomial.'), nl)
        );
            (A=0, B\=0,                                                       % case2 a=0, b!=0
            Result is (- C/B), 
            write('One root for this equation: X= '), 
            write(Result), nl);

            (A\=0, C=0,                                                       % case3 a!=0, c=0
            Result is (- B/A), 
            write('One root for this equation: '), nl,
            write('X1 = '), 
            write(Result), nl,
            write('AND X2=0'), nl);

    (                                                                   
        ( 
            (A\=0, B\=0, C\=0,                                               % case4a a!=0, b!=0, c!=0
            Dis is ((B*B) -(4*A*C)),
            Dis>=0,                                                          % Distinctive>=0
            Diakrinousa is sqrt(Dis), 
            Result1 is ((-B + Diakrinousa) / (2*A)), 
            Result2 is ((-B - Diakrinousa) / (2*A)), 

            write('Two roots for this equation. '), nl,
            write('X1 = '), 
            write(Result1), nl,
            write('AND X2= '), 
            write(Result2), nl);

            (A\=0, B\=0, C\=0,       % Migadikes rizes
            Dis is ((B*B) -(4*A*C)), 
            Dis<0,                                                          % Distinctive<0
            write('Two complex roots for this equation.'), nl)
        );
        (
            (A\=0, C\=0,                                                    % case4a a!=0, c!=0 
            Dis is ((B*B) -(4*A*C)),
            Dis>=0,                                                         % Distinctive>=0
            Diakrinousa is sqrt(Dis),
            Result1 is ((-B + Diakrinousa) / (2*A)),
            Result2 is ((-B - Diakrinousa) / (2*A)),

            write('Two roots for this equation. '), nl,
            write('X1 = '), 
            write(Result1), nl,
            write('AND X2= '),  
            write(Result2), nl);

            (A\=0, C\=0, 
            Dis is ((B*B) -(4*A*C)), 
            Dis<0,                                                           % Distinctive<0
            write('Two complex roots for this equation.'), nl)
        )   
    )
).