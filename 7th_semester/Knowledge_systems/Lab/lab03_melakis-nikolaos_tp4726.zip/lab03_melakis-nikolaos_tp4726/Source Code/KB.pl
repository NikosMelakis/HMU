rule([LabVals, Sat, Saturation], Ans):-
    LabVals=yes,
    Sat=saturation,
    Saturation>=20,
    Ans = 'No anoxia problem.', !. 

rule([LabVals, Sat, Saturation, HasNO3], Ans):-
    LabVals=yes,
    Sat=saturation,
    Saturation<20,
    HasNO3=yes,
    Ans = 'Severe anoxia problem.', !. 

rule([LabVals, Sat, Saturation, HasNO3], Ans):-
    LabVals=yes, 
    Sat=saturation,
    Saturation<20,
    HasNO3=no,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=black,
    HasH2S=yes,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=dark,
    HasH2S=yes,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S, HasCH4], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=black,
    HasH2S=no,
    HasCH4=yes,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S, HasCH4], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=dark,
    HasH2S=no,
    HasCH4=yes,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S, HasCH4], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=black,
    HasH2S=no,
    HasCH4=no,
    Ans = 'Severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, HasH2S, HasCH4], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=dark,
    HasH2S=no,
    HasCH4=no,
    Ans = 'Severe anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, Substrate], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=medium,
    Ans = 'No anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, Substrate], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=large,
    Ans = 'No anoxia problem.', !. 

rule([LabVals, Oligochaetes, Sediments, Substrate, WaterSmell], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=regular,
    WaterSmell=no,
    Ans = 'No anoxia problem.', !.

rule([LabVals, Oligochaetes, Sediments, Substrate, WaterSmell], Ans):-
    LabVals=no,
    Oligochaetes=no,
    Sediments=light,
    Substrate=regular,
    WaterSmell=yes,
    Ans = 'Medium anoxia problem.', !.

rule([LabVals, Oligochaetes], Ans):-
    LabVals=no,
    Oligochaetes=few,
    Ans = 'Very severe anoxia problem.', !. 

rule([LabVals, Oligochaetes], Ans):-
    LabVals=no,
    Oligochaetes=many,
    Ans = 'Medium anoxia problem.', !. 
