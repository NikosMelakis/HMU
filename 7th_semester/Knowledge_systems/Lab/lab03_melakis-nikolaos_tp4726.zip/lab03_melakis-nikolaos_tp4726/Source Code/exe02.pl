%Nikolaos Melakis Tp4726
%Erwthma 2

:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_error)).
:- use_module(library(http/html_write)).
:- use_module(library(http/http_client)).

:- http_handler('/', web_form, []).
:- http_handler('/parenthesis', parenthesisa, []).

server(8008) :-
    http_server(http_dispatch, [port(8008)]).

web_form(_Request) :-
    reply_html_page(
        title('Parenthesis'),   % title
    [
        p([],[
            'Parethensis equality checker'
        ]),
        form([action='/parenthesis', method='POST'], 
            [ 
                p([], [
                label([for=parenthesis],''),
                input([name=parenthesis, type=textarea, placeholder='Type something like: (())', style='border: 1px #000 solid; border-radius: 5px; padding: 5px', required])
                ]),
                p([], input([name=submit, type=submit, style='border: 1px #000 solid; border-radius: 5px; padding: 5px', value='SUBMIT'], [])) 
            ]
        )
    ]
).

empty_stack([]).          % emptying stack if has leftovers 

parenthesisa(Request) :-
    reply_html_page(
        title('Parenthesis Answer'), []), 
        member(method(post), Request), !, 
        http_read_data(Request, Data, []),
	format('<p><h3>', []),
    check_equality(Data.parenthesis).


check_equality(S):-
    name(S, [H|T]),           % computing list to numbers
    check(T, [H]).

    check([], S):-            % checking for empty list
        empty_stack(S),
        write('Parenthesis left and right are equaly typed.');
            write('Parenthesis left and right not equaly typed.').

    check([H|T], [H|T1]):-    % importing elements to empty stack
        push([H|T1], H, R),  
        check(T, R).       

    check([H|T], [H1|T1]):-   % importing/exporting elements to/from empty stack depending on whether or not elements matches with users input
        H \= H1,     
        pop([H1|T1], R),
        check(T, R).
    
    push(Q,S, [S|Q]).            
    pop([H|T], T). 