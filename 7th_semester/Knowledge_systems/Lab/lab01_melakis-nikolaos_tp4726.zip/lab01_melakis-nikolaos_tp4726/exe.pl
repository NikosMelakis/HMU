%Nikolaos Melakis TP4726
%main-rule rule(rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existance_of_red_oligochaetes,Existance_of_sediments,Existance_H2S,Existance_CH4,Press_substrace,Water_smell,Answer).

begin:- write('Are there any lab values? (yes/no): '),nl , 
        read(Data),
        ((Data=yes , write('Give Saturation in dissolved oxygen (%): ') ,nl, read(Saturation_in_dissolved_oxygen) ,(
            (Saturation_in_dissolved_oxygen>=20, rule(Rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer) );
            (write('Has NO3? (yes/no): '),nl , read(Has_NO3) , rule(Rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer) 
        )));
        (Data = no , write('Existence of red oligochaetes (no/few/many): '),nl , read(Existence_of_red_oligochaetes) , (
            ((Existence_of_red_oligochaetes = many ; Existence_of_red_oligochaetes = few) , rule(Rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer)); 
            (Existence_of_red_oligochaetes = no ,write('Existence of sediments (black/dark/light): '),nl , read(Existance_of_sediments), (
                (Sedi = light , write('What is the press substrate (regular/medium/large): '),nl , read(Press_substrate), (
                    (Press_substrate = regular , write('Does the water smells bad? (yes/no): '),nl, read(Water_smell), 
                        rule(Rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer) ); 
                    (rule(Rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer)) 
                ) );
                (write('Does H2S exists? (yes/no): '),nl, read(Existence_H2S) , (
                    (Existence_H2S=no , write('Does CH4 exists? (yes/no): '),nl,read(Existance_CH4) ,
                        rule(Rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer)); 
                    (rule(Rule,Data,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer)
                ))
            ) )
        )))),write(Answer).




%1
rule(rule1,yes,Saturation_in_dissolved_oxygen,Has_NO3,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer):- 
    Saturation_in_dissolved_oxygen>=20, 
    Answer='No anoxia problem.'.

%2
rule(rule2,yes,Saturation_in_dissolved_oxygen,yes,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer):- 
    Saturation_in_dissolved_oxygen<20, 
    Answer='Severe anoxia problem.'.

%3
rule(rule3,yes,Saturation_in_dissolved_oxygen,no,Existence_of_red_oligochaetes,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer):- 
    Saturation_in_dissolved_oxygen<20, 
    Answer='Very severe anoxia problem.'.

%4
rule(rule4,no,Saturation_in_dissolved_oxygen,Has_NO3,many,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer):- 
    Answer='Medium anoxia problem'.

%5
rule(rule5,no,Saturation_in_dissolved_oxygen,Has_NO3,few,Existance_of_sediments,Existence_H2S,Existance_CH4,Press_substrate,Water_smell,Answer):- 
    Answer='Very severe anoxia problem.'.

%6
rule(rule6,no,Saturation_in_dissolved_oxygen,Has_NO3,no,light,Existence_H2S,Existance_CH4,normal,no,Answer):- 
    Answer='No anoxia problem.'.

%7
rule(rule7,no,Saturation_in_dissolved_oxygen,Has_NO3,no,light,Existence_H2S,Existance_CH4,normal,yes,Answer):- 
    Answer='Medium anoxia problem.'.

%8
rule(rule8,no,Saturation_in_dissolved_oxygen,Has_NO3,no,light,Existence_H2S,Existance_CH4,_,Water_smell,Answer):- 
    Answer='No anoxia problem.'.

%9
rule(rule9,no,Saturation_in_dissolved_oxygen,Has_NO3,no,_,no,no,Press_substrate,Water_smell,Answer):- 
    Answer='Severe anoxia problem.'.

%10
rule(rule10,no,Saturation_in_dissolved_oxygen,Has_NO3,no,_,no,yes,Press_substrate,Water_smell,Answer):- 
    Answer='Very severe anoxia problem.'.

%11
rule(rule11,no,Saturation_in_dissolved_oxygen,Has_NO3,no,_,yes,Existance_CH4,Press_substrate,Water_smell,Answer):- 
    Answer='Very severe anoxia problem.'.