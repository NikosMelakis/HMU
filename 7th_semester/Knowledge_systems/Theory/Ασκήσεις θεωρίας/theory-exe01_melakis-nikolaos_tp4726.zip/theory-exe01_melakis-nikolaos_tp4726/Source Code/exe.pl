%Nikolaos Melakis TP4726
%rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer).
%to start the program the proper way type the word "start." and follow the instruction on the menu

start:-
    write('MAIN MENU (Type 1 or 2 to continue)'), nl,
    write('1. To start the Knowledge Base.'), nl,
    write('2. To close the program.'), nl,
    read(Option),
    chose(Option).

chose(1):-
    write('Program Starting...'), nl,
    sound_check.
chose(2):-
    terminate.
chose(X):-
    write('Wrong Input! Try again.'), nl,
    start.

sound_check:- 
        write('Is there a sound problem? (yes/no): '), nl,
        read(Sound),
        ((Sound=yes, write('Is the sound card detected? (yes/no): '), nl, read(Sound_card_detect), (
            (Sound_card_detect=yes, write('Is the sound card damaged/missing? (yes/no): '), nl, read(Sound_dam_miss), (
                (Sound_dam_miss=yes, rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer));
                    rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer)));
            (Sound_card_detect=no, write('Do you see a driver warning (yes/no): '), nl, read(Driver_warn), (
                (Driver_warn=yes, rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer)));
                        (rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer))
            )
        ));
        (Sound=no, write('Is the sound scratchy? (yes/no): '), nl, read(Scratchy_sound), (
            (Scratchy_sound=yes, write('Does the speaker or the mic work? (yes/no): '), nl, read(Speaker_mic_work), (
                (Speaker_mic_work=yes, rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer));
                    rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer));
            (Scratchy_sound=no, rule(Rid,(Sound, Sound_card_detect, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer))))
        )
        ),
        write(Answer), nl,
        write('Procedure completed.'), nl,
        start.

terminate:-
    write('--Program Terminated--').


%Knowledge Base
%1
rule(rid1,(yes, yes, yes, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer):-
    Answer='Replace sound card.'.
%2
rule(rid2,(yes, yes, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer):-
    Answer='Check connection point.'.
%3
rule(rid3,(yes, no, Sound_dam_miss, yes, Scratchy_sound, Speaker_mic_work), Answer):-
    Answer='Install Driver.'.
%4
rule(rid4,(yes, no, Sound_dam_miss, Driver_warn, Scratchy_sound, Speaker_mic_work), Answer):-
    Answer='Driver conflict.'.
%5
rule(rid5,(no, Sound_card_detect, Sound_dam_miss, Driver_warn, yes, yes), Answer):-
    Answer='Check sound cable.'.
%6
rule(rid6,(no, Sound_card_detect, Sound_dam_miss, Driver_warn, yes, Speaker_mic_work), Answer):-
    Answer='Connect cable.'.
%7
rule(rid7,(no, Sound_card_detect, Sound_dam_miss, Driver_warn, no, Speaker_mic_work), Answer):-
    Answer='No problem.'.