
Το πρόγραμμα χτίστηκε με το intelliJ IDEA CE με JDK 17. 
Πραγματοποιήθηκαν και λειτουργούν πλήρως όλα τα ζητούμενα. 
Ανοίγεται το πρόγραμμα με το IDEA και αφού γίνει το configure για το JDΚ κάνετε run με current file και όλα θα δουλέψουν κατέυχήν. 

Σε περίπτωση κάποιου προβλήματος επικοινωνήστε στο nick_melakis@yahoo.gr


Ενδεικτικά δίνεται η δομή του JSON array για να σας διευκολύνει στη μέθοδο put και update.

For Users

{
    "username": "JohnDoe00",
    "password": "johnspwd",
    "fName": "John",
    "lName": "Doe",
    "address": "RandomStreet",
    "city": "RandomCity",
    "postcode": 70100,
    "country": "Greece",
    "phoneNum": 6980808080,
    "birthDate": "2022-12-25",
    "gender": "Male"
}

For Trips

{
    "fromCity": "Heraklion",
    "toCity": "Athens",
    "fromDate": "2022-10-05",
    "toDate": "2022-10-10"
}


