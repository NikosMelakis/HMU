package com.nikosmelakis.restapi.Controller;


import com.nikosmelakis.restapi.Models.Trip;
import com.nikosmelakis.restapi.Models.User;
import com.nikosmelakis.restapi.Repo.TripRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.nikosmelakis.restapi.Repo.UserRepo;
import org.springframework.web.bind.annotation.*;
import java.lang.String;

import java.util.List;
import java.util.Optional;

@RestController
public class ApiControllers {


    @Autowired
    private UserRepo userRepo;
    @Autowired
    private TripRepo tripRepo;

    //---- Message on screen on http://localhost:8080 ----//
    @GetMapping(value = "/")
    public String getPage(){
        return "REST API | Nikolaos Melakis TP4726";
    }

    //---- Start of user api controller ----//

    //---- returns on http://localhost:8080/api/v1/users ----//
    @GetMapping(value = "/api/v1/users")
    public List<User> getUsers(){
        return userRepo.findAll();
    }


    @PostMapping(value = "/api/v1/users")
    public String saveUser(@RequestBody User user){
        userRepo.save(user);
        return "User successfully saved!";
    }

    //---- returns on http://localhost:8080/api/v1/users/{userId} selected user with specific id
    //     e.g. http://localhost:8080/api/v1/users/1 after first put on database ----//
    @GetMapping(value = "/api/v1/users/{userId}")
    public Optional<User> getUser(@PathVariable long userId){
        User getUser=userRepo.findById(userId).get();
        return userRepo.findById(userId);
    }
    @PutMapping(value = "/api/v1/users/{userId}")
    public String updateUser(@PathVariable long userId, @RequestBody User user){
        User updatedUser=userRepo.findById(userId).get();
        updatedUser.setUsername(user.getUsername());
        updatedUser.setPassword(user.getPassword());
        updatedUser.setfName(user.getfName());
        updatedUser.setlName(user.getlName());
        updatedUser.setAddress(user.getAddress());
        updatedUser.setCity(user.getCity());
        updatedUser.setPostcode(user.getPostcode());
        updatedUser.setCountry(user.getCountry());
        updatedUser.setPhoneNum(user.getPhoneNum());
        updatedUser.setBirthDate(user.getBirthDate());
        updatedUser.setGender(user.getGender());
        userRepo.save(updatedUser);
        return "User info successfully updated!";
    }

    @DeleteMapping(value = "/api/v1/users/{userId}")
    public String deleteUser(@PathVariable long userId){
        User deleteUser=userRepo.findById(userId).get();
        userRepo.delete(deleteUser);
        return "User with id "+userId+" successfully deleted!";
    }

    //---- End of user api controller ----//




    //---- Start of trip api controller ----//

    //---- returns on http://localhost:8080/api/v1/trips ----//
    @GetMapping(value = "/api/v1/trips")
    public List<Trip> getTrips(){
        return tripRepo.findAll();
    }

    @PostMapping(value = "/api/v1/trips")
    public String saveTrip(@RequestBody Trip trip){
        tripRepo.save(trip);
        return "Trip successfully saved!";
    }

    //---- returns on http://localhost:8080/api/v1/trips/{tripId} selected user with specific id
    //     e.g. http://localhost:8080/api/v1/trips/1 after first put on database ----//
    @GetMapping(value = "/api/v1/trips/{tripId}")
    public Optional<Trip> getTrip(@PathVariable long tripId){
        Trip getTrip=tripRepo.findById(tripId).get();
        return tripRepo.findById(tripId);
    }

    @PutMapping(value = "/api/v1/trips/{tripId}")
    public String updateTrip(@PathVariable long tripId, @RequestBody Trip trip){
        Trip udateTrip=tripRepo.findById(tripId).get();
        udateTrip.setFromCity(trip.getFromCity());
        udateTrip.setToCity(trip.getToCity());
        udateTrip.setFromDate(trip.getFromDate());
        udateTrip.setToDate(trip.getToDate());
        tripRepo.save(udateTrip);
        return "Trip info successfully updated!";
    }

    @DeleteMapping(value = "/api/v1/trips/{tripId}")
    public String deleteTrip(@PathVariable long tripId){
        Trip deleteTrip=tripRepo.findById(tripId).get();
        tripRepo.delete(deleteTrip);
        return "Trip with id "+tripId+" successfully deleted!";
    }
}