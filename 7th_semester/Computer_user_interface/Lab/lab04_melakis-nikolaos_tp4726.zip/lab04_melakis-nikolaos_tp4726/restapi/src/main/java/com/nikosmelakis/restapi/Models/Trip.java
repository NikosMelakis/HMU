package com.nikosmelakis.restapi.Models;

import jakarta.persistence.*;
import java.util.Date;

//---- Creating trip entity to import on mySql
@Entity
public class Trip {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long tripId;

    @Column
    private String fromCity;

    @Column
    private String toCity;

    @Column
    private Date fromDate;

    @Column
    private Date toDate;

    public long getTripId() {
        return tripId;
    }

    public void setTripId(long tripId) {
        this.tripId = tripId;
    }

    public String getFromCity() {
        return fromCity;
    }

    public void setFromCity(String fromCity) {
        this.fromCity = fromCity;
    }

    public String getToCity() {
        return toCity;
    }

    public void setToCity(String toCity) {
        this.toCity = toCity;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }
}
