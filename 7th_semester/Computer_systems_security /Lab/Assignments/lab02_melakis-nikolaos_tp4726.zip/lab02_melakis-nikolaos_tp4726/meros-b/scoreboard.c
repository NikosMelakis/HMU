#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <pwd.h>

#define BILLION  1000000000L;
        
char *getenv(const char *name);

int main( int argc, char** argv ){
        struct timespec start, stop;
        double accum;
        char *pathvar;

        struct passwd *p;
        uid_t  uid;
        srand(time(0));

        // getting time to start with clock gettime 
        if( clock_gettime( CLOCK_REALTIME, &start) == -1 ) {
            perror( "clock gettime" );
            return EXIT_FAILURE;
        }

        // generate the random number with srand
        int num = (rand() % (100)) + 1;
        
        //get the username
        pathvar = getenv("USER"); 

        //stop timing
        if( clock_gettime( CLOCK_REALTIME, &stop) == -1 ) {
            perror( "clock gettime" );
        return EXIT_FAILURE;
        }

        //calculate the total time
        accum = ( stop.tv_sec - start.tv_sec )
            + (double)( stop.tv_nsec - start.tv_nsec )
                / (double)BILLION;

        

        // Printing the final results on terminal
        printf( "\nTIME (IN NANOSEC): %.2lf", accum * 1000000000 );
        printf("\nRANDOM NUMBER: %d ", num);
        if ((p = getpwuid(uid = geteuid())) == NULL)
            perror("getpwuid() error");
        else 
            printf("\nUSER  : %s",       p->pw_name);

        printf("\nNICKNAME: %s\n", pathvar);
        return EXIT_SUCCESS;
}
