Στο παραδειγμα εκτελεσης, για το scoreboard, αν θεσουμε το setuid bit, δημιουργουμε το προνομιο μονο ο οποιος  χρηστης κανει χρηση του κωδικα,
να το κανει με τα δικαιωματα του ιδιοκτητη του scoreboard.

Αρα λοιπον, οποιος τρεξει το scoreboard , θα το τρεξει σαν δημιουργος.

Π.χ οταν ο χρηστης 1 δημιουργησει (κανει compile) το εκτελεσιμο scoreboard, και επειτα
δωσει την εντολη chmod o+s (θα θεσει το setuid bit) και επειτα chmod+x (για το κανει εκτελεσιμο)

Επειτα ΟΠΟΙΟΣ χρηστης τρεξει το scoreboard, ΘΑ ΤΟ ΚΑΝΕΙ ΣΑΝ ΧΡΗΣΤΗΣ 1. (θα καταγραφονται δηλαδη τα στοιχεια του χρηστη 1). 

ΑΝ ΘΕΛΕΙ Ο XΡΗΣΤΗΣ 1 (ο δημιουργος) να προστατεψει καποια σημεια του κωδικα του πρεπει να το κανει με το seteuid

πχ

main (int argc, char * argv [])
  {
    /* Saves the different UIDs */
    e_uid_initial = geteuid ();           ///ΕΔΩ ΠΑΙΡΝΟΥΜΕ ΤΟ UID TOY ΔΗΜΙΟΥΡΓΟΥ ΠΧ. USER1
    r_uid = getuid ();                    //ΕΔΩ ΕΙΝΑΙ ΤΟ ΙD TOY ΧΡΗΣΤΗ ΠΟΥ ΕΚΤΕΛΕΙ (ΔΕΝ ΕΙΝΑΙ ΑΝΑΓΚΗ ΝΑ ΕΙΝΑΙ Ο USER1)

    /* limits access rights to the ones of the 
     * user launching the program */
    seteuid (r_uid);                  //ΕΔΩ ΚΑΝΕΙ ΣΕΤ Ο ΧΡΗΣΤΗΣ ΠΟΥ ΕΚΤΕΛΕΙ ΤΗΝ ΕΦΑΡΜΟΓΗ (ΠΧ. Ο ΧΡΗΣΤΗΣ 2) ΜΕ ΤΟ ΔΙΚΟ ΤΟΥ ID
    ...
    privileged_function (); //ΟΤΑΝ ΚΛΗΘΕΙ ΑΥΤΗ Η ΣΥΝΑΡΤΗΣΗ ΜΟΝΟ Ο ΧΡΗΣΤΗΣ ΕΝΑ ΕΧΕΙ ΔΙΚΑΙΩΜΑ ΝΑ ΕΚΤΕΛΕΣΕΙ ΤΟΝ ΚΩΔΙΚΑ ΜΕΣΑ ΣΕ ΑΥΤΗΝ
    ...
  }
  
  void
  privileged_function (void)
  {
    /* Gets initial privileges back */
    seteuid (e_uid_initial); // ΜΟΝΟ ΣΤΟΝ ΔΗΜΙΟΥΡΓΟ ΜΠΟΡΕΙ ΝΑ ΛΕΙΤΟΥΡΓΗΣΕΙ ΑΥΤΟ ,OI AΛΛΟΙ ΘΑ ΠΑΡΟΥΝ PERMISSION DENIED.
    ...
    /* Portion needing privileges */
    ...
    /* Back to the rights of the runner */
    seteuid (r_uid); // ΕΠΙΣΤΡΕΦΕΙ ΤΟ ΕΛΕΓΧΟ ΣE ΠΙΘΑΝΑ ΑΛΛΟ USER (PX USER2)
  }  
 

παρατηρησεις

1) ΤΑ USER PERMISSIONS ΔΕΝ ΛΕΙΤΟΥΡΓΟΥΝ ΣΤΟ WINDOWS 10 WSL (LINUX IN WINDOWS)


 