#!/bin/bash
#1)
#plaintext encoding
./huffcode -i plaintext -o compressed_plaintext 
filename="huffcode.c"

#2)
#conf huffcode weights and encoding becomes encyrption using caecar algorith with key value 3
addition="int i=0; if(i=0;i<plj++){buf[j]=buf[j]+3;}"
if [[ $addition!="" && $replace!="" ]]; then
    sed "153s/.*/$addition/" $filename > new_huffcode.c
fi

./huffcode -i compressed_plaintext -o encyrped_compressed_plaintext

