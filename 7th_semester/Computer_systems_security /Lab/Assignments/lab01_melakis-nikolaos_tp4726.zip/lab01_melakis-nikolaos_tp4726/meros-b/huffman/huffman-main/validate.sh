#!/bin/bash
#1)
#plaintext encoding
./huffcode -i plaintext -o compressed_plaintext 
filename="huffcode.c"

#2)
#conf huffcode weights and encoding becomes encyrption using caecar algorith with key value 3
addition="int i=0; if(i=0;i<plj++){buf[j]=buf[j]+3;}"
if [[ $addition!="" && $replace!="" ]]; then
    sed "210s/.*/$addition/" $filename > new_huffcode.c
fi

./huffcode -d -i compressed_plaintext > original_plaintext
diff plaintext original_plaintext